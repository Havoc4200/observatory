# Changelog

## 0.2.1 — Theme overhaul

- The theme set is replaced by a curated collection of seven: **Mission Control** (new default), Midnight Ops, Arctic,
  Cyber Grid, OLED Black, Retro Terminal and Solar. The old themes (observatory, observatory-light, oled, cyberpunk,
  retro-green, retro-amber, nebula, nord) have been removed. Saved theme names map automatically to the closest new theme.
- The themes share one set of colour roles (surfaces, text, brand, ok / warn / crit / info, action, chart scales).
  Every screen now uses those roles. The hard-coded terminal colours that broke the light theme are gone from Docker,
  Storage, Network, Processes, Alerts, Analytics, Settings and the dashboard.
- Usage charts only turn amber or red once a value crosses the warning or critical threshold. Calm values stay in
  the theme's calm colours, with no muddy in-between hues.
- Neutral volume charts (network, power, sparklines) use the brand colours instead of a green→red scale.
- Recommendations ("▶ DO NEXT") use the theme's action colour. Chip labels are chosen to stay legible on every
  status colour.
- The health panel shrinks its bars before it ever cuts off a status word.
- Built-in Textual themes are no longer offered in the command palette.
- New: `observatory themes [--audit]`; `--demo-scenario healthy|warning|critical`.
- New: `tests/test_themes.py` quality gate. It audits colours and renders every theme × scenario × size × view.
