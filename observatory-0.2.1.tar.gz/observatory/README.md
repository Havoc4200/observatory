# Observatory

**Observe. Understand. Predict. Optimize.**

Observatory is a Linux infrastructure intelligence monitor for homelabs, self-hosters and small server rooms. It combines a btop-style real-time terminal UI with process and Docker management, a power estimation engine, electricity cost tracking, a SQLite history with rollups, anomaly detection and simple forecasting.

```
┌ CURRENT POWER ┐┌ POWER COST TODAY ┐┌ MONTHLY COST ESTIMATE ┐┌ SYSTEM HEALTH SCORE ┐
│ 112 W         ││ $0.41            ││ $12.30                ││ 92 · Excellent      │
└───────────────┘└──────────────────┘└───────────────────────┘└─────────────────────┘
┌ TOP PROCESS ──┐┌ TOP CONTAINER ───┐┌ MOST ACTIVE DRIVE ────┐┌ HIGHEST TEMPERATURE ┐
│ plex          ││ jellyfin         ││ sda                   ││ 68°C                │
└───────────────┘└──────────────────┘└───────────────────────┘└─────────────────────┘
```

## Features

| Area | What you get |
|---|---|
| Real-time monitoring | CPU (per core, frequency, I/O wait, steal), memory, swap (incl. swap-in/out rate), load averages, uptime, disk usage, disk I/O (throughput, IOPS, utilisation), temperatures, network throughput, NVIDIA/AMD GPU metrics |
| Processes | Full process table, sort by CPU / memory / PID / name, search, filters (mine, running, high CPU, high memory, hide kernel threads), terminate (SIGTERM) and kill (SIGKILL) with confirmation |
| Docker | Containers with state, health, CPU, memory, network, restart count and Compose stack; start / stop / restart with confirmation; restart and state-change events |
| Power intelligence | Per-component wall-power estimate from CPU model, GPU model, RAM size, storage devices and PSU efficiency, using a bundled hardware profile database; uses RAPL and GPU driver power readings when available; confidence band |
| Cost intelligence | Configurable utility rate and currency; cost today, current hourly cost, monthly and annual estimates; daily energy history |
| History | SQLite (WAL) with raw samples and 1-minute / 1-hour / 1-day rollups, energy-per-hour, events and alerts tables, configurable retention |
| Anomaly detection | CPU spikes, memory leaks, excessive disk activity, network spikes, thermal events — with hysteresis, escalation, cool-down and an event log |
| Analytics | Historical charts (1 h to 30 days), energy and cost by day, top processes in range, storage-exhaustion and memory-trend forecasts |
| Operations | systemd collector service, one-shot `status` (text or JSON), `hardware` report, database maintenance commands |

## Quick start

```bash
git clone <your-repo-url> observatory   # or unpack the release archive
cd observatory
sudo ./scripts/install.sh --rate 0.15   # your price per kWh
observatory                              # launch the UI
```

The installer creates a virtualenv in `/opt/observatory`, links `/usr/local/bin/observatory`, writes `/etc/observatory/config.toml`, creates the `observatory` group (and adds you to it), and enables `observatory.service`, which records history in the background. See **[docs/INSTALL.md](docs/INSTALL.md)** for per-distribution notes (Ubuntu, Debian, Linux Mint, Proxmox VE, generic Linux), manual installation, upgrades and troubleshooting.

Run from source without installing:

```bash
python3.12 -m venv .venv && . .venv/bin/activate
pip install -r requirements.txt && pip install -e .
observatory
```

## The Home dashboard

![Observatory Home dashboard](docs/screenshots/home-mission-control-warning-180x50.png)

Home is the product: you can leave Observatory on it for months. One screen answers
**what is happening, why, what changed and what to do next**, without navigating:

| Area | What it shows |
|---|---|
| Header | Host, OS/Proxmox version, uptime, a live system pulse, current watts and $/h, health score, risk score, alerts, pending updates, reboot-required |
| Live resources | CPU, memory, swap, disk I/O, network, GPU (or load), thermal — each with the live value, a trend arrow, a 24 h chart that ends at "now", the 24 h peak and when it happened, the 7-day average and the week-over-week change |
| Infrastructure health | Overall score ring; stability, power, thermal, storage and network sub-scores (Excellent → Critical); risk and efficiency; the reasons behind every low score |
| Insights + Do next | Plain-language explanations ranked by importance (e.g. "CPU is 34% higher than your normal Wednesday 14:00 pattern; most of it comes from container plex"), then numbered actions with their impact ("saves $2.17/mo", "full in 21 d") |
| Power & cost | Watts now, cost per hour, today, this week vs last, month, year and next-30-days forecast; 24 h power chart with peak (and the process behind it) and low; power flow from components to cost; savings tip |
| Storage | Every filesystem with its projected fill date; every drive with SMART health, temperature, age and failure risk |
| Containers | Running / healthy / unhealthy / stopped / restarts-today counts; top containers by CPU, memory and network; restart history |
| Services & media | systemd running/failed units and reboot-required; Plex, Jellyfin, Radarr, Sonarr, Lidarr, Readarr and qBittorrent: streams (and transcodes), queues, rates, library size and growth |
| Radar · Network · What changed · 30-day outlook | Pressure radar vs the 7-day normal; traffic with 24 h history and monthly transfer forecast; a change journal of Observatory events, package upgrades and reboots; predictions for cost, storage, memory, CPU, traffic and drive risk |

Every panel is clickable and opens its deep-dive screen. The layout adapts to the terminal: a 160×45 terminal shows
everything at once, wider screens add the radar (176+ columns) and a 7×24 week heatmap (214+ columns), and small
terminals stack the panels and scroll.

Try it without touching your system: `observatory --demo` (add `--demo-scenario healthy` or `critical` to see the other states).

## Keys

| Key | Action |
|---|---|
| `H` `P` `D` `S` `N` `W` `A` `F` `L` `M` `,` | Home, Processes, Docker, Storage, Network, Power, Analytics, Forecasts, Alerts, Media, Settings (upper or lower case; digits `1`–`9` also work) |
| `T` | Theme picker with live preview (see [Themes](#themes)) |
| `space` | Pause / resume refreshing |
| `?` | Help |
| `q` | Quit |
| Processes: `/` `c` `r` `o` `k` `K` | Search, sort by CPU / RAM, cycle sort column, terminate, kill |
| Docker: `r` `x` | Restart, start/stop |
| Alerts: `enter` `e` `x` | Acknowledge selected, acknowledge all, clear resolved |
| Settings: `ctrl+s` | Save |

Run with `sudo observatory` to see and manage every user's processes and to read RAPL energy counters. The systemd
service runs as root, so SMART health appears for every user once it is installed.

## Themes

![The seven Observatory themes](docs/screenshots/themes-gallery.png)

Seven curated themes, not dozens of average ones. Each one is built on the same set of colour roles: surfaces, text,
brand, status (ok / warning / critical / notice), action, and chart scales. Each role means the same thing in every
theme: amber or red always means warning or critical, and charts only turn amber or red when the value has actually
crossed the warning or critical threshold.

| Theme | Character |
|---|---|
| `mission-control` (default) | Deep charcoal, soft cyan, electric blue, clean white. An operations centre. |
| `midnight-ops` | Near-black with restrained blue accents and soft white text. SOC / NOC night shift. |
| `arctic` | Light theme. Cool greys, white panels, soft blues. For bright rooms. |
| `cyber-grid` | Dark indigo, electric teal and purple. Cyberpunk without the neon overload. |
| `oled-black` | True black for OLED panels and always-on wall displays. |
| `retro-terminal` | Green phosphor, kept professional: amber warnings, red criticals. |
| `solar` | Amber and gold on dark slate. A warm workstation for long sessions. |

Every theme passes an automated quality gate (`observatory themes --audit`, plus `tests/test_themes.py`):

- WCAG contrast: 7:1 for body text, 4.5:1 for secondary text, status text and chip labels, 3:1 for chart marks.
- Perceptual separation (ΔE ≥ 24) between ok, warning and critical, and between those and the brand colours,
  so an alert can never be mistaken for decoration.
- A rendered check of every glyph on the dashboard in the healthy, warning and critical demo states, at
  118×40, 160×45 and 230×62.
- Error-free rendering of the Home, Forecast, Docker, Storage, Network, Power and Alerts views.

Set the theme with `T` (the choice is saved), `--theme NAME`, or `theme = "..."` under `[ui]` in the config file.
Older theme names from 0.1/0.2.0 (`observatory`, `cyberpunk`, `retro-amber`, …) map to the closest new theme
automatically.

## Command line

```text
observatory [--config PATH] [--db PATH] [--tab NAME] [--theme NAME] [--no-record] [--no-docker]
            [--demo [--demo-scenario healthy|warning|critical]]
observatory daemon [--once]          headless collector (used by systemd)
observatory status [--json]          one-shot summary
observatory hardware                 detected hardware and power breakdown
observatory themes [--audit]         list the themes; --audit prints every contrast check
observatory init-config [--system|--path P] [--force]
observatory db stats|rollup|prune|vacuum
```

When the systemd service is running, the TUI detects its heartbeat and does not write duplicate history; when the service is stopped, the TUI records history itself.

## How power and cost are estimated

```
wall watts = (CPU + memory + GPUs + storage + platform) / PSU efficiency + extra devices
CPU        = (idle + (max − idle) × utilisation^0.8) × sockets      or RAPL package power when readable
GPU        = driver-reported board power                            or idle + (max − idle) × utilisation
memory     = DIMMs × (1.5 W + 1.5 W × activity)                     or RAPL DRAM power when readable
storage    = per device by type: HDD 5 W idle / 8 W active (0.8 W spun down), SATA SSD 0.6/3 W, NVMe 1.5/6 W
platform   = motherboard, chipset, fans by chassis: server 45 W, desktop 18 W, mini PC 6 W, laptop 5 W
```

CPU and GPU idle/max figures come from `src/observatory/data/hardware_profiles.json`; unknown models fall back to naming-convention heuristics. Modeled components carry ±25 % uncertainty, measured ones ±5 %, shown as the range under Current Power. Run `observatory hardware` to see what was detected, then correct anything in Settings (CPU/GPU override, RAM, DIMM count, PSU efficiency, platform watts, extra devices, spun-down drives).

Energy is integrated every refresh into an hourly table priced at the rate in force at the time, so changing your rate never rewrites past costs. Monthly and annual estimates fill every hour without data with your 7-day average draw.

## Project layout

```text
observatory/
├── pyproject.toml                  package metadata, dependencies, pytest config
├── requirements.txt                runtime dependencies
├── requirements-dev.txt            test dependencies
├── Makefile                        dev shortcuts (venv, test, run, lint)
├── config/observatory.example.toml documented configuration
├── packaging/systemd/observatory.service
├── scripts/install.sh              installer (Ubuntu/Debian/Mint/Proxmox/generic)
├── scripts/uninstall.sh
├── docs/INSTALL.md                 installation guide
├── docs/ARCHITECTURE.md            how the MVP maps to the architecture
├── src/observatory/
│   ├── cli.py                      command-line entry point
│   ├── config.py                   TOML config load/validate/save
│   ├── models.py                   dataclasses shared by every layer
│   ├── collectors/                 system, disks, network, sensors, gpu, processes, docker
│   ├── engines/                    hardware, power, cost, anomaly, health, forecast, stats
│   ├── storage/                    database (schema/migrations), repository, aggregation
│   ├── services/                   monitor (orchestration), daemon (systemd collector)
│   ├── data/hardware_profiles.json hardware profile database
│   ├── ui/                         Textual app, stylesheet, widgets
│   │   └── panes/                  dashboard, processes, disks, network, docker, analytics, alerts, settings
│   └── util/                       formatting, counter rates, PCI lookup
└── tests/                          pytest suite (unit, integration, headless UI)
```

## Testing

```bash
pip install -r requirements-dev.txt && pip install -e .
pytest                    # full suite, including headless UI tests
pytest --cov=observatory  # with coverage
```

The suite covers configuration, formatting and statistics, the SQLite schema, repository, rollups and retention, every collector (with fake sysfs trees and a fake Docker client), the power, cost, anomaly, health and forecast engines, the monitor service and daemon, the CLI, and the UI via Textual's pilot.

## Limitations (MVP)

- Linux only; Python 3.12+.
- Power is an estimate unless RAPL/GPU sensors cover the main consumers; for best accuracy compare against a wall meter once and adjust `platform_watts` / `psu_efficiency`.
- In VMs and LXC containers the estimate reflects the guest's own load, not the host's draw.
- SMART health, media-server integrations, plugins and the web UI are planned for later versions (see the architecture document).

## License

MIT — see [LICENSE](LICENSE).
