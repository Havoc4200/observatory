"""Theme quality gate.

No theme ships unless it passes the colour audit *and* renders every view legibly in the
healthy, warning and critical demo scenarios at small, standard and large terminal sizes.
"""

from __future__ import annotations

import logging

import pytest
from rich.console import Console

from observatory.config import Config
from observatory.demo import SCENARIOS, DemoService
from observatory.ui.app import ObservatoryApp
from observatory.ui.colors import contrast, delta_e
from observatory.ui.themes import (
    COLLECTION, DEFAULT_THEME, LEGACY_NAMES, SPECS, THEMES, audit_all, palette_for, resolve_theme_name,
)

THEME_NAMES = [spec.name for spec in COLLECTION]
SIZES = [(118, 40), (160, 45), (230, 62)]       # small terminal, standard, large monitor
VIEWS = ["home", "forecast", "docker", "storage", "network", "power", "alerts"]
TEXT_MIN = 4.5      # any letter or digit drawn by a dashboard panel
MARK_MIN = 3.0      # chart glyphs and icons


# ------------------------------------------------------------------ static audit
def test_collection_is_the_curated_seven():
    assert THEME_NAMES == ["mission-control", "midnight-ops", "arctic", "cyber-grid", "oled-black",
                           "retro-terminal", "solar"]
    assert DEFAULT_THEME == "mission-control"
    assert Config().ui.theme == "mission-control"
    assert set(THEMES) == set(THEME_NAMES)


@pytest.mark.parametrize("report", audit_all(), ids=lambda r: r.theme)
def test_theme_passes_colour_audit(report):
    failures = [f"{c.label}: {c.value:.2f} < {c.required}" for c in report.failures]
    assert report.passed, f"{report.theme} failed: " + "; ".join(failures)


def test_legacy_theme_names_resolve_into_collection():
    for old, new in LEGACY_NAMES.items():
        assert resolve_theme_name(old) == new
        assert new in SPECS
    assert resolve_theme_name("does-not-exist") == DEFAULT_THEME
    for name in THEME_NAMES:
        assert resolve_theme_name(name) == name


@pytest.mark.parametrize("name", THEME_NAMES)
def test_status_chips_are_legible(name):
    pal = palette_for(name)
    for severity in ("critical", "warning", "notice", "good", "info", "other"):
        color = pal.for_severity(severity)
        assert contrast(pal.on(color), color) >= TEXT_MIN, (name, severity)
    for color in (pal.primary, pal.action, pal.accent):
        assert contrast(pal.on(color), color) >= TEXT_MIN, (name, color)


@pytest.mark.parametrize("name", THEME_NAMES)
def test_critical_never_looks_like_brand(name):
    pal = palette_for(name)
    for brand in (pal.primary, pal.secondary, pal.accent, pal.action):
        assert delta_e(pal.crit, brand) >= 24
        assert delta_e(pal.warn, brand) >= 24


# ------------------------------------------------------------- rendered audit
def _segments(renderable, width: int):
    console = Console(width=width, color_system="truecolor", file=open("/dev/null", "w"), legacy_windows=False)
    return list(console.render(renderable, console.options.update(width=width)))


def _legibility_problems(app, spec) -> list[str]:
    """Every coloured glyph a dashboard panel draws must stand out from what it is drawn on."""
    from observatory.ui.dashboard.panels import DashPanel

    pal = app.palette
    exempt = {pal.grid.lower(), pal.border.lower()}   # deliberate low-contrast chart scaffolding
    problems: list[str] = []
    widgets = [*app.query(DashPanel)]
    if getattr(app, "header", None) is not None:
        widgets.append(app.header)
    for panel in widgets:
        if not panel.display or panel.size.width < 4:
            continue
        for seg in _segments(panel.render(), max(panel.size.width - 2, 10)):
            text, style = seg.text, seg.style
            if not text.strip() or style is None or style.color is None:
                continue
            fg = style.color.get_truecolor().hex if not style.color.is_default else spec.text
            if fg.lower() in exempt:
                continue
            bg = style.bgcolor.get_truecolor().hex if style.bgcolor and not style.bgcolor.is_default else spec.surface
            if fg.lower() == bg.lower():           # solid block cells (bars, heatmaps) carry no text
                continue
            need = TEXT_MIN if any(ch.isalnum() for ch in text) else MARK_MIN
            if style.dim:
                need = MARK_MIN
            ratio = contrast(fg, bg)
            if ratio < need:
                problems.append(f"{panel.id}: {text.strip()[:24]!r} {fg} on {bg} = {ratio:.2f} < {need}")
    return problems


@pytest.mark.parametrize("scenario", SCENARIOS)
async def test_every_theme_renders_every_view_in_every_state(scenario, caplog, tmp_path):
    cfg = Config()
    cfg.storage.db_path = str(tmp_path / "t.db")
    service = DemoService(cfg, scenario=scenario)
    app = ObservatoryApp(service)
    problems: list[str] = []
    try:
        with caplog.at_level(logging.ERROR):
            async with app.run_test(size=SIZES[1]) as pilot:
                await pilot.pause(0.5)
                assert set(app.available_themes) == set(THEME_NAMES), "foreign themes must not be offered"
                for spec in COLLECTION:
                    app.theme = spec.name
                    await pilot.pause(0.05)
                    assert app.palette.crit == spec.crit
                    for size in SIZES:
                        await pilot.resize_terminal(*size)
                        app.action_show("home")
                        await pilot.pause(0.25)
                        if size == SIZES[1]:
                            assert app.query_one("#home-scroll").max_scroll_y <= 1, (spec.name, scenario)
                        for p in _legibility_problems(app, spec):
                            problems.append(f"{spec.name}/{scenario}/{size[0]}x{size[1]} {p}")
                    for view in VIEWS[1:]:
                        app.action_show(view)
                        await pilot.pause(0.1)
                        assert app.switcher.current == view
                    app.action_show("home")
                    await pilot.pause(0.05)
    finally:
        service.close()
    errors = [r.getMessage() for r in caplog.records if r.levelno >= logging.ERROR]
    assert not errors, errors[:5]
    assert not problems, f"{len(problems)} legibility problems:\n" + "\n".join(problems[:40])


@pytest.mark.parametrize("scenario", SCENARIOS)
def test_demo_scenarios_drive_the_expected_states(scenario, tmp_path):
    cfg = Config()
    cfg.storage.db_path = str(tmp_path / "t.db")
    service = DemoService(cfg, scenario=scenario)
    try:
        snap = service.collect()
    finally:
        service.close()
    severities = {a.severity for a in snap.alerts}
    if scenario == "healthy":
        assert not snap.alerts and snap.scores.overall >= 85
        assert not snap.services.failed
    elif scenario == "warning":
        assert severities == {"warning"}
        assert 40 <= snap.scores.overall < 85
    else:
        assert "critical" in severities and snap.scores.overall < 40
        assert any(i.severity == "critical" for i in snap.insights)
