"""Observatory — Observe. Understand. Predict. Optimize.

A Linux infrastructure intelligence monitor: real-time metrics, process and
Docker management, power and electricity-cost estimation, historical analytics
in SQLite, and anomaly detection, all in a Textual terminal UI.
"""

__all__ = ["__version__", "APP_NAME", "MISSION"]

__version__ = "0.2.1"
APP_NAME = "Observatory"
MISSION = "Observe. Understand. Predict. Optimize."
