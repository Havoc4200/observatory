"""Demo mode: a realistic, animated homelab for previews, screenshots and tests.

``observatory --demo`` runs the full UI against a simulated media/homelab
server (Plex, the *arr stack, qBittorrent, ZFS pool, NVIDIA GPU) with a
synthetic 24-hour history, so every panel can be seen without real data.
No real processes or containers are touched.

Three scenarios exercise every visual state (``--demo-scenario``):

* ``healthy``  — everything green: no alerts, no failed units, nothing filling up;
* ``warning``  — the default: a scrub running hot, a pool filling, a flaky container;
* ``critical`` — a bad day: CPU and memory pinned, filesystems almost full, a drive
  failing SMART, containers down, failed units, security updates pending.
"""

from __future__ import annotations

import math
import random
import time

from observatory.collectors.changes import ChangeGroup
from observatory.collectors.media import MediaApp, QueueItem, Stream
from observatory.collectors.services import FailedUnit, ServiceSummary
from observatory.collectors.smart import SmartInfo, score_drive
from observatory.config import Config
from observatory.engines.cost import CostEngine
from observatory.engines.forecast import StorageForecast, TrendForecast
from observatory.engines.health import compute_health
from observatory.engines.insights import InsightInputs, generate_insights
from observatory.engines.intelligence import (
    Baseline, EnergyContext, HistoricalContext, MetricContext,
)
from observatory.engines.scores import compute_scores
from observatory.models import (
    Alert, ContainerInfo, CpuStats, DiskIO, DiskUsage, GpuStats, LoadStats, MemoryStats, NetInterface,
    PowerComponent, PowerEstimate, ProcessInfo, Snapshot, StorageDevice, SwapStats, TempReading,
)
from observatory.services.monitor import MonitorService
from observatory.storage.repository import EventRecord
from observatory.util.sysinfo import SystemIdentity
from observatory.util.updates import UpdateStatus

GB = 1024 ** 3
TB = 10 ** 12
SCENARIOS = ("healthy", "warning", "critical")


def _wave(t: float, period: float, lo: float, hi: float, phase: float = 0.0) -> float:
    return lo + (hi - lo) * (0.5 + 0.5 * math.sin(2 * math.pi * t / period + phase))


def _daily_curve(n: int, lo: float, hi: float, noise: float, seed: int, now: float | None = None) -> list[float]:
    """n buckets covering the last 24 h, oldest first, aligned to the local clock."""
    rnd = random.Random(seed)
    now = now if now is not None else time.time()
    start = now - 86400
    out = []
    for i in range(n):
        lt = time.localtime(start + (i + 0.5) * 86400 / n)
        hour = lt.tm_hour + lt.tm_min / 60
        evening = math.exp(-((hour - 21) ** 2) / 8)  # streaming peak at 21:00
        night = math.exp(-((hour - 3) ** 2) / 2)      # backups at 03:00
        v = lo + (hi - lo) * (0.55 * evening + 0.35 * night) + rnd.uniform(-noise, noise)
        out.append(max(v, 0.0))
    return out


class DemoService(MonitorService):
    """MonitorService that returns simulated snapshots instead of reading the host."""

    def __init__(self, cfg: Config, scenario: str = "warning") -> None:
        if scenario not in SCENARIOS:
            raise ValueError(f"unknown demo scenario {scenario!r} (choose from {', '.join(SCENARIOS)})")
        self.scenario = scenario
        cfg.docker.enabled = False
        cfg.media.enabled = False
        # describe the simulated machine so hardware-driven screens match the demo
        cfg.power.cpu_model = "AMD Ryzen 7 5700G with Radeon Graphics"
        cfg.power.gpu_model = "NVIDIA GeForce RTX 3060"
        cfg.power.ram_gb = 64
        cfg.power.dimm_count = 4
        cfg.power.psu_efficiency = 0.90
        cfg.power.use_rapl = False
        super().__init__(cfg, mode="never")
        self.started = time.time()
        self.rnd = random.Random(7)
        self.events: list[EventRecord] = []
        now = time.time()
        for i, (kind, sev, msg) in enumerate([
            ("container_restart", "warning", "radarr restarted (6 restarts total)"),
            ("alert_fired", "warning", "Unusual I/O on sdc: 182 MB/s vs baseline 3 MB/s"),
            ("network_device_new", "info", "New device 192.168.1.47 (a4:83:e7:2c:91:0f)"),
            ("alert_resolved", "info", "Resolved: CPU at 96% for 3 samples"),
            ("container_state", "info", "tdarr: exited → running"),
            ("config_changed", "info", "Settings updated"),
            ("container_restart", "warning", "radarr restarted (5 restarts total)"),
            ("daemon_started", "info", "Observatory daemon started"),
        ]):
            self.events.append(EventRecord(i, now - (i + 1) * 2700, kind, sev, "demo", "", msg, None))

    # ----------------------------------------------------------- simulation
    def collect(self) -> Snapshot:
        t = time.time()
        r = self.rnd
        el = t - self.started
        cpu = min(max(_wave(el, 90, 18, 52) + r.uniform(-6, 6), 2), 99)
        snap = Snapshot(ts=t, hostname="atlas")
        snap.identity = SystemIdentity("Debian GNU/Linux 12 (bookworm)", "debian", "6.8.12-4-pve", "x86_64",
                                       "Proxmox VE 8.3.2")
        snap.uptime_s = 41 * 86400 + 5 * 3600 + el
        snap.cpu = CpuStats(percent=cpu, per_core=[min(max(cpu + r.uniform(-25, 25), 0), 100) for _ in range(16)],
                            user=cpu * 0.7, system=cpu * 0.2, iowait=r.uniform(0.5, 4), freq_mhz=3900 + r.uniform(-400, 600),
                            freq_max_mhz=4900, cores_logical=16, cores_physical=8,
                            model="AMD Ryzen 7 5700G with Radeon Graphics")
        mem_pct = 61 + 4 * math.sin(el / 300)
        snap.memory = MemoryStats(total=64 * GB, used=int(64 * GB * mem_pct / 100), available=int(64 * GB * (1 - mem_pct / 100)),
                                  percent=mem_pct)
        snap.swap = SwapStats(total=8 * GB, used=int(0.6 * GB), percent=7.5, sin_bps=0, sout_bps=r.choice([0, 0, 0, 40_000]))
        snap.load = LoadStats(cpu / 100 * 9, cpu / 100 * 8, cpu / 100 * 7, 16)
        snap.disks = [
            DiskUsage("/dev/nvme0n1p2", "/", "ext4", 512 * 10**9, 188 * 10**9, 324 * 10**9, 36.7),
            DiskUsage("tank", "/tank", "zfs", 48 * TB, int(39.4 * TB), int(8.6 * TB), 82.1),
            DiskUsage("backup", "/mnt/backup", "zfs", 16 * TB, int(14.9 * TB), int(1.1 * TB), 93.1),
            DiskUsage("/dev/sdf1", "/mnt/scratch", "xfs", 2 * TB, int(0.4 * TB), int(1.6 * TB), 20.0),
        ]
        busy = _wave(el, 40, 0, 85)
        snap.disk_io = [
            DiskIO("nvme0n1", r.uniform(1e6, 40e6), r.uniform(1e6, 25e6), r.uniform(100, 2000), r.uniform(50, 900), r.uniform(2, 18)),
            DiskIO("sda", busy * 2e6, busy * 4e5, busy * 3, busy, busy),
            DiskIO("sdb", busy * 2e6, busy * 4e5, busy * 3, busy, busy * 0.97),
            DiskIO("sdc", busy * 1.9e6, busy * 3e5, busy * 3, busy, busy * 0.95),
            DiskIO("sdd", 0, 0, 0, 0, 0),
            DiskIO("sde", 0, 0, 0, 0, 0),
        ]
        snap.storage_devices = [
            StorageDevice("nvme0n1", "Samsung SSD 980 PRO 1TB", "nvme", 1000 * 10**9),
            StorageDevice("sda", "WDC WD120EFBX", "hdd", 12 * TB, True),
            StorageDevice("sdb", "WDC WD120EFBX", "hdd", 12 * TB, True),
            StorageDevice("sdc", "ST12000VN0008", "hdd", 12 * TB, True),
            StorageDevice("sdd", "ST16000NM001G", "hdd", 16 * TB, True),
            StorageDevice("sde", "ST16000NM001G", "hdd", 16 * TB, True),
        ]
        snap.temps = [
            TempReading("k10temp", "Tctl", 48 + cpu * 0.35, kind="cpu"),
            TempReading("nvme", "Composite", 44 + r.uniform(-1, 1), high=82, critical=85, kind="drive"),
            TempReading("drivetemp", "sda", 39.0, kind="drive"),
            TempReading("drivetemp", "sdc", 57.0 + r.uniform(-0.5, 0.5), kind="drive"),
            TempReading("nvidia", "GPU0", 52 + _wave(el, 60, 0, 14), kind="gpu"),
        ]
        down = _wave(el, 50, 2e6, 38e6) + r.uniform(0, 3e6)
        up = _wave(el, 70, 0.5e6, 9e6, 1.0)
        snap.net = [
            NetInterface("enp6s0", True, 2500, ["192.168.1.10"], down, up, 18 * TB, 4 * TB, 0, 12),
            NetInterface("vmbr0", True, 0, ["192.168.1.10"], down * 0.2, up * 0.1, 0, 0, virtual=True),
        ]
        gpu_util = _wave(el, 60, 12, 64)
        snap.gpus = [GpuStats(0, "NVIDIA GeForce RTX 3060", "NVIDIA", gpu_util, int(3.1 * GB), 12 * GB,
                              52 + gpu_util * 0.2, 22 + gpu_util * 1.1, 170)]
        snap.processes = [
            ProcessInfo(2101, "Plex Transcoder", "plex", cpu * 0.9, 3.1, int(1.9 * GB), 24, "running", "Plex Transcoder", 1),
            ProcessInfo(1880, "qbittorrent-nox", "media", 14.2, 2.4, int(1.5 * GB), 31, "sleeping", "qbittorrent-nox", 1),
            ProcessInfo(1773, "Radarr", "media", 3.4, 1.2, int(780e6), 22, "sleeping", "/opt/Radarr/Radarr", 1),
            ProcessInfo(1774, "Sonarr", "media", 2.1, 1.1, int(700e6), 21, "sleeping", "/opt/Sonarr/Sonarr", 1),
            ProcessInfo(990, "zfs", "root", 4.0, 0.0, 0, 1, "running", "[z_rd_int]", 1),
            ProcessInfo(1, "systemd", "root", 0.1, 0.0, int(14e6), 1, "sleeping", "/sbin/init", 1),
        ]
        snap.process_count = 412
        snap.containers = [
            ContainerInfo("p" * 64, "plex", "plexinc/pms-docker", "running", "Up 9 days (healthy)", "healthy",
                          cpu * 0.85, int(2.3 * GB), 8 * GB, 28.7, 2.1e5, up * 0.8, 0, compose_project="media"),
            ContainerInfo("q" * 64, "qbittorrent", "lscr.io/linuxserver/qbittorrent", "running", "Up 9 days", "",
                          14.0, int(1.4 * GB), 0, 0, down * 0.9, up * 0.15, 0, compose_project="media"),
            ContainerInfo("r" * 64, "radarr", "lscr.io/linuxserver/radarr", "running", "Up 12 minutes (healthy)",
                          "healthy", 3.3, int(780e6), 0, 0, 4e4, 1e4, 6, compose_project="media"),
            ContainerInfo("s" * 64, "sonarr", "lscr.io/linuxserver/sonarr", "running", "Up 9 days (healthy)",
                          "healthy", 2.0, int(700e6), 0, 0, 3e4, 1e4, 0, compose_project="media"),
            ContainerInfo("t" * 64, "tdarr", "ghcr.io/haveagitgat/tdarr", "running", "Up 2 hours (unhealthy)",
                          "unhealthy", 1.2, int(410e6), 0, 0, 0, 0, 2, compose_project="media"),
            ContainerInfo("h" * 64, "homeassistant", "ghcr.io/home-assistant/home-assistant", "running",
                          "Up 20 days", "", 1.8, int(620e6), 0, 0, 2e4, 2e4, 0, compose_project="home"),
            ContainerInfo("g" * 64, "grafana", "grafana/grafana", "exited", "Exited (0) 3 days ago", ""),
        ]
        snap.docker_available = True
        cpu_w = 8 + (88 - 8) * (cpu / 100) ** 0.8
        gpu_w = 22 + gpu_util * 1.1
        comps = [PowerComponent("CPU package", round(cpu_w, 1), "modeled"),
                 PowerComponent("GPU 0: NVIDIA GeForce RTX 3060", round(gpu_w, 1), "measured"),
                 PowerComponent("Memory", 7.5, "modeled"),
                 PowerComponent("Storage (6 devices)", round(27 + busy * 0.09, 1), "modeled"),
                 PowerComponent("Platform (board, fans)", 18.0, "modeled")]
        dc = sum(c.watts for c in comps)
        wall = dc / 0.9
        snap.power = PowerEstimate(round(wall, 1), round(dc, 1), round(wall * 0.84, 1), round(wall * 1.16, 1), 0.9, comps)
        cost_engine = CostEngine(self.cfg.cost)
        snap.cost = cost_engine.compute(wall, t)
        snap.cost.today_kwh = wall * ((t - time.mktime(time.localtime(t)[:3] + (0, 0, 0, 0, 0, -1))) / 3600) / 1000
        snap.cost.today_cost = snap.cost.today_kwh * self.cfg.cost.rate_per_kwh
        snap.cost.average_watts = 151.0
        snap.alerts = [
            Alert("disk_activity", "warning", "sdc", "Unusual I/O on sdc: 182 MB/s vs baseline 3 MB/s (ZFS scrub)",
                  182e6, t - 1500, id=41),
            Alert("thermal", "warning", "drivetemp:sdc", "drivetemp:sdc at 57°C (limit 55°C)", 57, t - 900, id=42),
        ]
        snap.updates = UpdateStatus(available=14, security=0, manager="apt", checked_at=t)
        snap.smart = self._smart()
        snap.media = self._media(el)
        snap.context = self._context(t, wall)
        snap.top_apps = []
        snap.services = ServiceSummary(available=True, running=87, total=142,
                                       failed=[FailedUnit("nut-monitor", "Network UPS Tools - power device monitor")],
                                       reboot_required=True, reboot_packages=["proxmox-kernel-6.8.12-5-pve"],
                                       checked_at=t)
        snap.package_changes = [
            ChangeGroup(t - 3 * 86400 - 3600, 6, ("docker-ce", "containerd.io"), "upgrade"),
            ChangeGroup(t - 19 * 3600, 23, ("proxmox-kernel-6.8.12-5-pve", "zfsutils-linux"), "upgrade"),
        ]
        snap.recording = True
        if self.scenario == "healthy":
            self._healthy(snap)
        elif self.scenario == "critical":
            self._critical(snap, el)
        snap.health = compute_health(snap, self.cfg.alerts)
        snap.scores = compute_scores(snap, self.cfg.alerts, snap.context, snap.smart, snap.updates,
                                     legacy_health=snap.health.score, idle_floor_watts=118.0,
                                     idle_spinning_hdds=2, net_error_rate=0.0)
        snap.health.score = snap.scores.overall
        snap.insights = generate_insights(InsightInputs(
            snap=snap, cfg=self.cfg, ctx=snap.context, scores=snap.scores, smart=snap.smart, media=snap.media,
            updates=snap.updates, storage_devices=snap.storage_devices, recent_cpu=cpu + 14,
            recent_net_bps=down + up, recent_power=wall, has_gpu_encoder=True))
        self.last_snapshot = snap
        return snap

    # ------------------------------------------------------------ scenarios
    def _healthy(self, snap: Snapshot) -> None:
        """A calm, well-kept server: every status reads green."""
        t = snap.ts
        scale = 0.45
        snap.cpu.percent *= scale
        snap.cpu.per_core = [v * scale for v in snap.cpu.per_core]
        snap.load = LoadStats(snap.load.load1 * scale, snap.load.load5 * scale, snap.load.load15 * scale, 16)
        snap.memory.percent = 42.0
        snap.memory.used = int(64 * GB * 0.42)
        snap.memory.available = int(64 * GB * 0.58)
        snap.swap = SwapStats(total=8 * GB, used=int(0.1 * GB), percent=1.2, sin_bps=0, sout_bps=0)
        snap.disks = [
            DiskUsage("/dev/nvme0n1p2", "/", "ext4", 512 * 10**9, 141 * 10**9, 371 * 10**9, 27.5),
            DiskUsage("tank", "/tank", "zfs", 48 * TB, int(27.8 * TB), int(20.2 * TB), 57.9),
            DiskUsage("backup", "/mnt/backup", "zfs", 16 * TB, int(9.6 * TB), int(6.4 * TB), 60.0),
            DiskUsage("/dev/sdf1", "/mnt/scratch", "xfs", 2 * TB, int(0.4 * TB), int(1.6 * TB), 20.0),
        ]
        for io in snap.disk_io:
            io.util_percent = min(io.util_percent, 12.0)
            io.read_bps *= 0.1
            io.write_bps *= 0.1
        snap.temps = [tr for tr in snap.temps if tr.kind != "drive" or tr.label != "sdc"]
        snap.temps.append(TempReading("drivetemp", "sdc", 38.0, kind="drive"))
        for tr in snap.temps:
            if tr.kind == "cpu":
                tr.current = 41.0 + snap.cpu.percent * 0.3
        for c in snap.containers:
            c.restart_count = 0
            c.state = "running"
            if c.name in ("tdarr", "radarr", "sonarr", "plex"):
                c.health = "healthy"
                c.status = "Up 9 days (healthy)"
            elif c.name == "grafana":
                c.status = "Up 9 days"
        snap.alerts = []
        snap.updates = UpdateStatus(available=2, security=0, manager="apt", checked_at=t)
        for info in snap.smart.values():
            info.reallocated = 0
            info.pending = 0
            if info.device == "sdc":
                info.temperature_c = 38
            if not info.standby:
                score_drive(info)
        snap.services = ServiceSummary(available=True, running=88, total=142, failed=[], reboot_required=False,
                                       checked_at=t)
        snap.package_changes = snap.package_changes[:1]
        for app in snap.media.values():
            app.health_issues = []
        ctx = snap.context
        ctx.restarts_today = {}
        ctx.alerts_24h = 0
        ctx.new_devices_24h = []
        ctx.storage = {
            "/": StorageForecast("/", 141e9, 512e9, 0.2e9, None, "high"),
            "/tank": StorageForecast("/tank", 27.8 * TB, 48 * TB, 31e9, 650.0, "high"),
            "/mnt/backup": StorageForecast("/mnt/backup", 9.6 * TB, 16 * TB, 12e9, 530.0, "medium"),
            "/mnt/scratch": StorageForecast("/mnt/scratch", 0.4 * TB, 2 * TB, -3e9, None, "low"),
        }
        ctx.trends = {"mem": TrendForecast("mem.percent", "", 42, 0.01, 42.1, 42.4, 0.3),
                      "cpu": TrendForecast("cpu.percent", "", 14, 0.0, 14, 14, 0.2)}
        for key in ("cpu", "load", "power", "temp"):
            m = ctx.metrics.get(key)
            if m and m.baseline:
                m.baseline = Baseline(m.series_24h[-1] if m.series_24h else 0, m.baseline.spread, m.baseline.samples,
                                      m.baseline.description)
        self.events = [e for e in self.events if e.severity == "info"]

    def _critical(self, snap: Snapshot, el: float) -> None:
        """Everything that can go wrong at once — the worst case every theme must make obvious."""
        t = snap.ts
        r = self.rnd
        cpu = min(max(92 + r.uniform(-4, 6), 0), 100)
        snap.cpu.percent = cpu
        snap.cpu.per_core = [min(max(cpu + r.uniform(-8, 8), 60), 100) for _ in range(16)]
        snap.cpu.iowait = 18.0 + r.uniform(-2, 2)
        snap.load = LoadStats(23.4, 19.8, 14.2, 16)
        snap.memory.percent = 95.6
        snap.memory.used = int(64 * GB * 0.956)
        snap.memory.available = int(64 * GB * 0.044)
        snap.swap = SwapStats(total=8 * GB, used=int(5.2 * GB), percent=65.0, sin_bps=9e6, sout_bps=14e6)
        snap.disks = [
            DiskUsage("/dev/nvme0n1p2", "/", "ext4", 512 * 10**9, 497 * 10**9, 15 * 10**9, 97.1),
            DiskUsage("tank", "/tank", "zfs", 48 * TB, int(44.6 * TB), int(3.4 * TB), 92.9),
            DiskUsage("backup", "/mnt/backup", "zfs", 16 * TB, int(15.88 * TB), int(0.12 * TB), 99.2),
            DiskUsage("/dev/sdf1", "/mnt/scratch", "xfs", 2 * TB, int(1.7 * TB), int(0.3 * TB), 85.0),
        ]
        for io in snap.disk_io:
            if io.device.startswith("sd") and io.device not in ("sdd", "sde"):
                io.util_percent = 97.0 + r.uniform(-2, 2)
        for tr in snap.temps:
            if tr.kind == "cpu":
                tr.current = 91.0 + r.uniform(-1, 1)
                tr.high, tr.critical = 90.0, 95.0
            elif tr.label == "sdc":
                tr.current = 64.0
            elif tr.kind == "gpu":
                tr.current = 87.0
        for g in snap.gpus:
            g.temp_c = 87.0
            g.util_percent = 99.0
        for c in snap.containers:
            if c.name == "plex":
                c.health, c.status = "unhealthy", "Up 2 hours (unhealthy)"
            elif c.name == "radarr":
                c.state, c.status, c.restart_count = "restarting", "Restarting (137) 8 seconds ago", 31
            elif c.name == "tdarr":
                c.state, c.status, c.health, c.cpu_percent = "exited", "Exited (137) 6 minutes ago", "", 0.0
            elif c.name == "homeassistant":
                c.state, c.status, c.cpu_percent = "dead", "Dead", 0.0
        snap.alerts = [
            Alert("disk_full", "critical", "/mnt/backup", "/mnt/backup is 99.2% full — 120 GB left", 99.2, t - 3600, id=51),
            Alert("disk_full", "critical", "/", "/ is 97.1% full — 15 GB left", 97.1, t - 1900, id=52),
            Alert("memory", "critical", "memory", "Memory 95.6% used, swapping 14 MB/s", 95.6, t - 1200, id=53),
            Alert("smart", "critical", "sdc", "sdc failing: 1,184 reallocated, 96 pending sectors", 96, t - 7200, id=54),
            Alert("thermal", "critical", "k10temp:Tctl", "CPU at 91°C (critical 95°C)", 91, t - 600, id=55),
            Alert("cpu_spike", "warning", "cpu", f"CPU at {cpu:.0f}% for 14 samples", cpu, t - 900, id=56),
            Alert("container", "warning", "radarr", "radarr restarting (31 restarts)", 31, t - 400, id=57),
        ]
        snap.updates = UpdateStatus(available=41, security=9, manager="apt", checked_at=t)
        sdc = snap.smart.get("sdc")
        if sdc:
            sdc.passed = False
            sdc.reallocated, sdc.pending, sdc.offline_uncorrectable = 1184, 96, 40
            sdc.temperature_c = 64
            score_drive(sdc)
        sdb = snap.smart.get("sdb")
        if sdb:
            sdb.reallocated, sdb.pending = 212, 8
            score_drive(sdb)
        snap.services = ServiceSummary(
            available=True, running=79, total=142,
            failed=[FailedUnit("nut-monitor", "Network UPS Tools - power device monitor"),
                    FailedUnit("zfs-scrub@tank", "zpool scrub on tank"),
                    FailedUnit("pvescheduler", "Proxmox VE scheduler"),
                    FailedUnit("smartd", "Self Monitoring and Reporting Technology daemon")],
            reboot_required=True, reboot_packages=["proxmox-kernel-6.8.12-5-pve", "libc6"], checked_at=t)
        ctx = snap.context
        ctx.restarts_today = {"radarr": 31, "tdarr": 9, "plex": 3}
        ctx.alerts_24h = 23
        ctx.storage = {
            "/": StorageForecast("/", 497e9, 512e9, 6.1e9, 2.5, "high"),
            "/tank": StorageForecast("/tank", 44.6 * TB, 48 * TB, 290e9, 11.7, "high"),
            "/mnt/backup": StorageForecast("/mnt/backup", 15.88 * TB, 16 * TB, 95e9, 1.3, "high"),
            "/mnt/scratch": StorageForecast("/mnt/scratch", 1.7 * TB, 2 * TB, 40e9, 7.5, "medium"),
        }
        ctx.trends = {"mem": TrendForecast("mem.percent", "", 95.6, 1.4, 97.0, 100.0, 0.83),
                      "cpu": TrendForecast("cpu.percent", "", 92, 0.9, 94, 99, 0.62)}
        for key, factor in (("cpu", 1.9), ("load", 2.4), ("mem", 1.45), ("temp", 1.4), ("power", 1.35)):
            m = ctx.metrics.get(key)
            if m and m.series_24h:
                m.series_24h = m.series_24h[:-16] + [v * factor for v in m.series_24h[-16:]]
                m.peak_24h = max(m.series_24h)
                m.peak_24h_ts = t - 300
        self.events = [
            EventRecord(100 + i, t - (i + 1) * 600, kind, sev, "demo", "", msg, None)
            for i, (kind, sev, msg) in enumerate([
                ("alert_fired", "critical", "Memory 95.6% used, swapping"),
                ("container_state", "warning", "tdarr: running → exited (137, OOM killed)"),
                ("alert_fired", "critical", "/mnt/backup is 99.2% full"),
                ("smart", "critical", "sdc: pending sectors 12 → 96"),
                ("container_restart", "warning", "radarr restarted (31 restarts total)"),
                ("container_state", "critical", "homeassistant: running → dead"),
            ])
        ] + self.events

    def _smart(self) -> dict[str, SmartInfo]:
        drives = {
            "nvme0n1": SmartInfo("nvme0n1", "Samsung SSD 980 PRO 1TB", "S5GX", "nvme", True, 44, 19_400,
                                 nvme_percentage_used=21, nvme_available_spare=100, nvme_spare_threshold=10),
            "sda": SmartInfo("sda", "WDC WD120EFBX", "A1", "ata", True, 39, 31_200),
            "sdb": SmartInfo("sdb", "WDC WD120EFBX", "A2", "ata", True, 40, 31_150, reallocated=8),
            "sdc": SmartInfo("sdc", "ST12000VN0008", "S1", "ata", True, 57, 48_900, reallocated=12),
            "sdd": SmartInfo("sdd", "ST16000NM001G", "S2", "ata", True, 36, 8_100),
            "sde": SmartInfo("sde", "ST16000NM001G", "S3", "ata", None, None, None, standby=True),
        }
        for info in drives.values():
            if not info.standby:
                score_drive(info)
        return drives

    def _media(self, el: float) -> dict[str, MediaApp]:
        plex = MediaApp("plex", "Plex", "container", "plex", "running", "healthy", "http://127.0.0.1:32400", True, True,
                        version="1.41.3", library_items=8_412)
        plex.streams = [Stream("maria", "Severance — Woe's Hollow", "playing", True, 12_000, True),
                        Stream("dad", "The Grand Budapest Hotel", "playing", True, 8_000, False),
                        Stream("kids", "Bluey — Sleepytime", "paused", False, 4_000)]
        radarr = MediaApp("radarr", "Radarr", "container", "radarr", "running", "healthy", "http://127.0.0.1:7878",
                          True, True, version="5.16.3", library_items=2_311, library_bytes=int(21.4 * TB))
        radarr.queue = [QueueItem("Dune Part Two (2024)", "downloading", 64.0)]
        radarr.queue_total = 1
        sonarr = MediaApp("sonarr", "Sonarr", "container", "sonarr", "running", "healthy", "http://127.0.0.1:8989",
                          True, True, version="4.0.11", library_items=184, library_bytes=int(14.9 * TB))
        sonarr.queue = [QueueItem("Andor S02E04", "downloading", 31.0), QueueItem("Shogun S01E07", "importPending", 100.0)]
        sonarr.queue_total = 2
        sonarr.health_issues = ["Indexer NZBgeek unavailable due to failures for more than 6 hours"]
        qbit = MediaApp("qbittorrent", "qBittorrent", "container", "qbittorrent", "running", "", "http://127.0.0.1:8080",
                        True, True, version="v5.0.3", download_bps=_wave(el, 50, 2e6, 34e6), upload_bps=2.1e6,
                        active_torrents=7)
        lidarr = MediaApp("lidarr", "Lidarr", "process", url="http://127.0.0.1:8686", configured=False)
        return {"plex": plex, "radarr": radarr, "sonarr": sonarr, "qbittorrent": qbit, "lidarr": lidarr}

    def _context(self, now: float, wall: float) -> HistoricalContext:
        ctx = HistoricalContext(available=True, built_at=now, history_since=now - 63 * 86400)
        lt = time.localtime(now)
        weekday = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"][lt.tm_wday]
        desc = f"{weekday} {lt.tm_hour:02d}:00"
        specs = {"cpu": (12, 68, 4, 1), "mem": (55, 66, 1, 2), "swap": (6, 9, 0.3, 3), "power": (128, 214, 6, 4),
                 "rx": (1e6, 30e6, 1e6, 5), "tx": (2e5, 8e6, 2e5, 6), "temp": (44, 63, 1, 7), "load": (1, 9, 0.4, 8)}
        for key, (lo, hi, noise, seed) in specs.items():
            series = _daily_curve(96, lo, hi, noise, seed, now)
            peak_i = max(range(96), key=series.__getitem__)
            low_i = min(range(96), key=series.__getitem__)
            avg = sum(series) / len(series)
            ctx.metrics[key] = MetricContext(
                avg_1h=series[-4:] and sum(series[-4:]) / 4, avg_24h=avg, peak_24h=series[peak_i],
                peak_24h_ts=now - 86400 + peak_i * 900, low_24h=series[low_i], low_24h_ts=now - 86400 + low_i * 900,
                avg_7d=avg * 0.95, avg_prev_7d=avg * 0.86,
                last_week_now=series[-1] * 0.88, baseline=Baseline(series[-1] * 0.72, avg * 0.1, 4, desc),
                series_24h=series)
        daily = [3.4, 3.5, 3.3, 3.6, 3.8, 3.5, 3.6, 3.7, 3.9, 4.1, 4.0, 4.2, 4.3, 2.1]
        rate = self.cfg.cost.rate_per_kwh
        ctx.energy = EnergyContext(
            week_kwh=27.9, week_cost=27.9 * rate, week_hours=168, prev_week_kwh=24.6, prev_week_cost=24.6 * rate,
            prev_week_hours=168, month_kwh=112.0, month_cost=112 * rate, month_hours=29 * 24,
            last_month_kwh=101.0, last_month_cost=101 * rate, last_month_hours=31 * 24,
            daily_kwh_14d=daily, daily_cost_14d=[d * rate for d in daily],
            forecast_30d_kwh=121.4, forecast_30d_cost=121.4 * rate, forecast_method="Holt-Winters (daily seasonality)")
        ctx.restarts_today = {"radarr": 6, "tdarr": 2}
        ctx.alerts_24h = 4
        ctx.new_devices_24h = [{"mac": "a4:83:e7:2c:91:0f", "ip": "192.168.1.47", "interface": "enp6s0",
                                "first_seen": now - 5000, "last_seen": now}]
        ctx.devices_active_24h = 23
        ctx.storage = {
            "/": StorageForecast("/", 188e9, 512e9, 0.4e9, None, "high"),
            "/tank": StorageForecast("/tank", 39.4 * TB, 48 * TB, 117e9, 73.5, "high"),
            "/mnt/backup": StorageForecast("/mnt/backup", 14.9 * TB, 16 * TB, 52e9, 21.2, "medium"),
            "/mnt/scratch": StorageForecast("/mnt/scratch", 0.4 * TB, 2 * TB, -3e9, None, "low"),
        }
        ctx.trends = {"mem": TrendForecast("mem.percent", "", 61, 0.21, 62.5, 67.3, 0.71),
                      "cpu": TrendForecast("cpu.percent", "", 31, 0.12, 32, 35, 0.44)}
        ctx.disk_idle_24h = {"sdd": 0.0, "sde": 0.1, "sda": 22.0, "sdb": 21.0, "sdc": 24.0, "nvme0n1": 6.0}
        ctx.media_library_growth = {"radarr": 41e9, "sonarr": 76e9}
        ctx.power_peak_process = "Plex Transcoder"
        ctx.traffic_today_bytes = 412e9 * ((now - time.mktime(time.localtime(now)[:3] + (0, 0, 0, 0, 0, -1))) / 86400)
        ctx.metrics["disk"] = MetricContext(avg_24h=131e6, peak_24h=612e6, peak_24h_ts=now - 13 * 3600, avg_7d=118e6,
                                            avg_prev_7d=92e6, series_24h=_daily_curve(96, 20e6, 610e6, 15e6, 9, now))
        ctx.metrics["gpu"] = MetricContext(avg_24h=31, peak_24h=78, peak_24h_ts=now - 3 * 3600, avg_7d=28,
                                           avg_prev_7d=25, series_24h=_daily_curve(96, 3, 70, 3, 10, now))
        rnd = random.Random(11)
        matrix = []
        for day in range(7):
            row = []
            for hour in range(24):
                evening = math.exp(-((hour - 21) ** 2) / 8)
                night = math.exp(-((hour - 3) ** 2) / 2)
                weekend = 1.25 if day in (1, 2) else 1.0
                value = (12 + 55 * evening * weekend + 35 * night + rnd.uniform(-5, 5))
                row.append(None if day == 6 and hour > time.localtime(now).tm_hour else max(value, 2))
            matrix.append(row)
        ctx.heatmap_cpu = matrix
        ctx.heatmap_days = [time.strftime("%a", time.localtime(now - (6 - d) * 86400)) for d in range(7)]
        return ctx

    def alerts_history(self, limit: int = 300) -> list[Alert]:
        snap = self.last_snapshot
        return list(snap.alerts) if snap else []

    def recent_events(self, window: float = 86400, limit: int = 80) -> list[EventRecord]:
        return list(self.events)[:limit]
