"""Configuration loading, validation and persistence.

Configuration is a TOML file with one table per section. Resolution order:

1. Path passed on the command line (``--config``)
2. ``$OBSERVATORY_CONFIG``
3. ``~/.config/observatory/config.toml`` (if it exists)
4. ``/etc/observatory/config.toml`` (if it exists)
5. Built-in defaults

Unknown keys are ignored (with a warning) so older binaries can read newer
files, and values are coerced to the declared types where that is safe.
"""

from __future__ import annotations

import logging
import os
import tomllib
from dataclasses import asdict, dataclass, field, fields, is_dataclass
from pathlib import Path
from typing import Any

import tomli_w

log = logging.getLogger(__name__)

SYSTEM_CONFIG_PATH = Path("/etc/observatory/config.toml")
SYSTEM_DB_PATH = Path("/var/lib/observatory/observatory.db")


def user_config_path() -> Path:
    base = os.environ.get("XDG_CONFIG_HOME") or str(Path.home() / ".config")
    return Path(base) / "observatory" / "config.toml"


def user_data_dir() -> Path:
    base = os.environ.get("XDG_DATA_HOME") or str(Path.home() / ".local" / "share")
    return Path(base) / "observatory"


@dataclass
class GeneralConfig:
    refresh_interval: float = 2.0
    host_name: str = ""


@dataclass
class StorageConfig:
    db_path: str = ""
    sample_interval: float = 10.0
    retention_raw_days: int = 2
    retention_1m_days: int = 30
    retention_1h_days: int = 365
    retention_1d_days: int = 0  # 0 = keep forever


@dataclass
class PowerConfig:
    cpu_model: str = ""          # override detected CPU model
    gpu_model: str = ""          # override detected discrete GPU model ("none" = no dGPU)
    ram_gb: float = 0.0          # 0 = auto-detect
    dimm_count: int = 0          # 0 = estimate from RAM size
    psu_efficiency: float = 0.87  # 0.50-0.99, wall = DC / efficiency
    platform_watts: float = -1.0  # motherboard, chipset, fans; -1 = auto by chassis type
    extra_watts: float = 0.0      # anything else on the same meter (switch, HBA, fans)
    use_rapl: bool = True         # use Intel/AMD RAPL energy counters when readable
    use_gpu_sensors: bool = True  # use nvidia-smi / amdgpu power readings when present
    spun_down_drives: list[str] = field(default_factory=list)  # e.g. ["sdc", "sdd"]


@dataclass
class CostConfig:
    rate_per_kwh: float = 0.15
    currency: str = "USD"
    currency_symbol: str = "$"
    fixed_daily_charge: float = 0.0  # share of the utility's fixed charge to attribute


@dataclass
class AlertConfig:
    enabled: bool = True
    cpu_spike_percent: float = 90.0
    cpu_spike_samples: int = 3
    cpu_spike_mad_k: float = 4.0
    memory_leak_window_minutes: int = 30
    memory_leak_min_mb: float = 100.0
    disk_util_percent: float = 90.0
    disk_busy_samples: int = 6
    network_spike_mbps: float = 100.0
    network_spike_z: float = 6.0
    temp_warning_c: float = 80.0
    temp_critical_c: float = 95.0
    drive_temp_warning_c: float = 55.0
    temp_rise_c: float = 15.0
    cooldown_minutes: int = 10


@dataclass
class DockerConfig:
    enabled: bool = True
    socket: str = "/var/run/docker.sock"
    timeout: float = 3.0


@dataclass
class UIConfig:
    default_tab: str = "home"
    confirm_actions: bool = True
    process_limit: int = 400
    theme: str = "mission-control"
    animations: bool = True


@dataclass
class MediaConfig:
    """Media stack credentials. Apps are auto-detected; URLs default to localhost."""

    enabled: bool = True
    poll_interval: float = 30.0
    plex_url: str = ""
    plex_token: str = ""
    jellyfin_url: str = ""
    jellyfin_api_key: str = ""
    radarr_url: str = ""
    radarr_api_key: str = ""
    sonarr_url: str = ""
    sonarr_api_key: str = ""
    lidarr_url: str = ""
    lidarr_api_key: str = ""
    readarr_url: str = ""
    readarr_api_key: str = ""
    qbittorrent_url: str = ""
    qbittorrent_username: str = ""
    qbittorrent_password: str = ""

    def credentials(self) -> dict[str, dict[str, str]]:
        return {
            "plex": {"url": self.plex_url, "token": self.plex_token},
            "jellyfin": {"url": self.jellyfin_url, "api_key": self.jellyfin_api_key},
            "radarr": {"url": self.radarr_url, "api_key": self.radarr_api_key},
            "sonarr": {"url": self.sonarr_url, "api_key": self.sonarr_api_key},
            "lidarr": {"url": self.lidarr_url, "api_key": self.lidarr_api_key},
            "readarr": {"url": self.readarr_url, "api_key": self.readarr_api_key},
            "qbittorrent": {"url": self.qbittorrent_url, "username": self.qbittorrent_username,
                            "password": self.qbittorrent_password},
        }


@dataclass
class Config:
    general: GeneralConfig = field(default_factory=GeneralConfig)
    storage: StorageConfig = field(default_factory=StorageConfig)
    power: PowerConfig = field(default_factory=PowerConfig)
    cost: CostConfig = field(default_factory=CostConfig)
    alerts: AlertConfig = field(default_factory=AlertConfig)
    docker: DockerConfig = field(default_factory=DockerConfig)
    ui: UIConfig = field(default_factory=UIConfig)
    media: MediaConfig = field(default_factory=MediaConfig)

    # Where this configuration was loaded from (not persisted).
    source_path: Path | None = field(default=None, compare=False, repr=False)

    # ----------------------------------------------------------------- helpers
    def resolved_db_path(self) -> Path:
        if self.storage.db_path:
            return Path(self.storage.db_path).expanduser()
        if os.geteuid() == 0:
            return SYSTEM_DB_PATH
        if SYSTEM_DB_PATH.exists() and os.access(SYSTEM_DB_PATH, os.R_OK | os.W_OK) and os.access(
            SYSTEM_DB_PATH.parent, os.W_OK
        ):
            return SYSTEM_DB_PATH
        return user_data_dir() / "observatory.db"

    def to_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {}
        for f in fields(self):
            if f.name == "source_path":
                continue
            out[f.name] = asdict(getattr(self, f.name))
        return out

    def validate(self) -> list[str]:
        """Clamp out-of-range values in place; return human-readable warnings."""
        warnings: list[str] = []

        def clamp(obj: Any, name: str, lo: float, hi: float) -> None:
            value = getattr(obj, name)
            new = min(max(value, lo), hi)
            if new != value:
                warnings.append(f"{type(obj).__name__}.{name}={value} out of range, using {new}")
                setattr(obj, name, new)

        clamp(self.general, "refresh_interval", 0.5, 60.0)
        clamp(self.storage, "sample_interval", 1.0, 3600.0)
        clamp(self.storage, "retention_raw_days", 1, 3650)
        clamp(self.storage, "retention_1m_days", 1, 3650)
        clamp(self.storage, "retention_1h_days", 1, 36500)
        clamp(self.storage, "retention_1d_days", 0, 36500)
        clamp(self.power, "psu_efficiency", 0.5, 0.99)
        clamp(self.power, "extra_watts", 0.0, 10000.0)
        clamp(self.power, "ram_gb", 0.0, 16384.0)
        clamp(self.power, "dimm_count", 0, 64)
        clamp(self.cost, "rate_per_kwh", 0.0, 100.0)
        clamp(self.cost, "fixed_daily_charge", 0.0, 1000.0)
        clamp(self.alerts, "cpu_spike_percent", 1.0, 100.0)
        clamp(self.alerts, "cpu_spike_samples", 1, 100)
        clamp(self.alerts, "disk_util_percent", 1.0, 100.0)
        clamp(self.alerts, "disk_busy_samples", 1, 100)
        clamp(self.alerts, "memory_leak_window_minutes", 5, 1440)
        clamp(self.alerts, "cooldown_minutes", 0, 1440)
        clamp(self.ui, "process_limit", 50, 5000)
        clamp(self.media, "poll_interval", 5.0, 3600.0)
        if self.power.platform_watts != -1.0 and self.power.platform_watts < 0:
            warnings.append("power.platform_watts must be >= 0 or -1 (auto); using auto")
            self.power.platform_watts = -1.0
        return warnings


# --------------------------------------------------------------------- coercion
def _coerce(value: Any, default: Any) -> Any:
    """Coerce ``value`` to the type of ``default``; raise ValueError if impossible."""
    if isinstance(default, bool):
        if isinstance(value, bool):
            return value
        if isinstance(value, str):
            lowered = value.strip().lower()
            if lowered in {"1", "true", "yes", "on"}:
                return True
            if lowered in {"0", "false", "no", "off"}:
                return False
        if isinstance(value, (int, float)):
            return bool(value)
        raise ValueError(f"expected boolean, got {value!r}")
    if isinstance(default, int):
        if isinstance(value, bool):
            raise ValueError(f"expected integer, got {value!r}")
        return int(float(value))
    if isinstance(default, float):
        if isinstance(value, bool):
            raise ValueError(f"expected number, got {value!r}")
        return float(value)
    if isinstance(default, str):
        return str(value)
    if isinstance(default, list):
        if isinstance(value, str):
            return [part.strip() for part in value.split(",") if part.strip()]
        if isinstance(value, (list, tuple)):
            return [str(v) for v in value]
        raise ValueError(f"expected list, got {value!r}")
    return value


def _apply_section(section_obj: Any, data: dict[str, Any], section_name: str) -> None:
    known = {f.name: f for f in fields(section_obj)}
    for key, value in data.items():
        if key not in known:
            log.warning("config: unknown key [%s].%s ignored", section_name, key)
            continue
        default = getattr(section_obj, key)
        try:
            setattr(section_obj, key, _coerce(value, default))
        except (TypeError, ValueError) as exc:
            log.warning("config: [%s].%s: %s; keeping %r", section_name, key, exc, default)


def config_from_dict(data: dict[str, Any]) -> Config:
    cfg = Config()
    for f in fields(cfg):
        if f.name == "source_path":
            continue
        section = data.get(f.name)
        if section is None:
            continue
        if not isinstance(section, dict):
            log.warning("config: [%s] must be a table; ignored", f.name)
            continue
        target = getattr(cfg, f.name)
        if is_dataclass(target):
            _apply_section(target, section, f.name)
    for unknown in set(data) - {f.name for f in fields(cfg)}:
        log.warning("config: unknown section [%s] ignored", unknown)
    for warning in cfg.validate():
        log.warning("config: %s", warning)
    return cfg


def candidate_paths(explicit: str | Path | None = None) -> list[Path]:
    paths: list[Path] = []
    if explicit:
        paths.append(Path(explicit).expanduser())
    env = os.environ.get("OBSERVATORY_CONFIG")
    if env:
        paths.append(Path(env).expanduser())
    paths.append(user_config_path())
    paths.append(SYSTEM_CONFIG_PATH)
    return paths


def load_config(explicit: str | Path | None = None) -> Config:
    """Load the first configuration file found, falling back to defaults.

    An explicitly requested path that does not exist is not an error: the
    returned config remembers it as ``source_path`` so Settings can create it.
    """
    for index, path in enumerate(candidate_paths(explicit)):
        if path.is_file():
            try:
                with path.open("rb") as fh:
                    data = tomllib.load(fh)
            except (OSError, tomllib.TOMLDecodeError) as exc:
                log.error("config: cannot read %s: %s; using defaults", path, exc)
                cfg = Config()
                cfg.source_path = path
                return cfg
            cfg = config_from_dict(data)
            cfg.source_path = path
            return cfg
        if index == 0 and explicit:
            cfg = Config()
            cfg.source_path = path
            return cfg
    cfg = Config()
    cfg.source_path = None
    return cfg


def default_save_path(cfg: Config) -> Path:
    if cfg.source_path is not None:
        if cfg.source_path.exists() and os.access(cfg.source_path, os.W_OK):
            return cfg.source_path
        if not cfg.source_path.exists() and os.access(_nearest_existing_parent(cfg.source_path), os.W_OK):
            return cfg.source_path
    if os.geteuid() == 0:
        return SYSTEM_CONFIG_PATH
    return user_config_path()


def _nearest_existing_parent(path: Path) -> Path:
    for parent in [path.parent, *path.parents]:
        if parent.exists():
            return parent
    return Path("/")


def save_config(cfg: Config, path: str | Path | None = None) -> Path:
    """Write the config atomically (temp file + rename) and return the path."""
    target = Path(path).expanduser() if path else default_save_path(cfg)
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp = target.with_suffix(target.suffix + ".tmp")
    header = (
        "# Observatory configuration\n"
        "# Observe. Understand. Predict. Optimize.\n"
        "# Edited by the Settings screen; comments are not preserved.\n\n"
    )
    payload = header + tomli_w.dumps(cfg.to_dict())
    tmp.write_text(payload, encoding="utf-8")
    if target.exists():
        # keep the original permissions (the installed file is group-writable)
        try:
            os.chmod(tmp, target.stat().st_mode & 0o7777)
        except OSError:
            pass
    os.replace(tmp, target)
    cfg.source_path = target
    return target
