"""Colour science helpers for the theme audit: WCAG contrast and perceptual distance."""

from __future__ import annotations

import math
from functools import lru_cache

from rich.color import Color


@lru_cache(maxsize=4096)
def rgb(color: str) -> tuple[int, int, int]:
    t = Color.parse(color).get_truecolor()
    return t.red, t.green, t.blue


def hex_color(r: float, g: float, b: float) -> str:
    return "#{:02x}{:02x}{:02x}".format(*(max(0, min(255, round(v))) for v in (r, g, b)))


def mix(c1: str, c2: str, t: float) -> str:
    """Blend c1 toward c2 by t (0..1)."""
    a, b = rgb(c1), rgb(c2)
    return hex_color(*(x + (y - x) * t for x, y in zip(a, b)))


@lru_cache(maxsize=4096)
def luminance(color: str) -> float:
    def channel(v: int) -> float:
        s = v / 255
        return s / 12.92 if s <= 0.03928 else ((s + 0.055) / 1.055) ** 2.4

    r, g, b = rgb(color)
    return 0.2126 * channel(r) + 0.7152 * channel(g) + 0.0722 * channel(b)


def contrast(a: str, b: str) -> float:
    """WCAG 2.x contrast ratio (1..21)."""
    la, lb = luminance(a), luminance(b)
    hi, lo = max(la, lb), min(la, lb)
    return (hi + 0.05) / (lo + 0.05)


@lru_cache(maxsize=4096)
def lab(color: str) -> tuple[float, float, float]:
    def lin(v: float) -> float:
        return v / 12.92 if v <= 0.04045 else ((v + 0.055) / 1.055) ** 2.4

    r, g, b = (lin(v / 255) for v in rgb(color))
    x = (0.4124 * r + 0.3576 * g + 0.1805 * b) / 0.95047
    y = 0.2126 * r + 0.7152 * g + 0.0722 * b
    z = (0.0193 * r + 0.1192 * g + 0.9505 * b) / 1.08883

    def f(t: float) -> float:
        return t ** (1 / 3) if t > 0.008856 else 7.787 * t + 16 / 116

    fx, fy, fz = f(x), f(y), f(z)
    return 116 * fy - 16, 500 * (fx - fy), 200 * (fy - fz)


def delta_e(a: str, b: str) -> float:
    """CIE76 colour difference; ≥ 20 reads as clearly different at a glance."""
    return math.dist(lab(a), lab(b))


def best_on(background: str, candidates: tuple[str, ...]) -> str:
    """The candidate with the highest contrast against ``background``."""
    return max(candidates, key=lambda c: contrast(c, background))
