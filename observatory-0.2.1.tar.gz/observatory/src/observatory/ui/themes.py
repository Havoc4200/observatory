"""Observatory's curated theme collection.

Seven themes, each built from the same set of semantic roles so every screen
means the same thing in every theme:

    surfaces   background · surface (panels) · raised (header, table headers) · border · grid
    text       text (≥ 7:1 on surface) · muted (≥ 4.5:1) — never decoration-only
    brand      primary (titles, navigation, "now") · secondary (second series) ·
               accent (headline numbers) — none of them may look like a status
    status     ok · warn · crit · info — always ≥ 4.5:1 on surface, mutually
               distinct, and distinct from every brand colour, so alerts never
               blend into decoration
    action     recommendations ("Do next")
    charts     heat (low → high load, calm → hot), flow (volume), series
               (categorical, e.g. power components)

:func:`audit_theme` measures all of this (WCAG contrast, CIE ΔE separation);
the test suite fails if any shipped theme does not pass, and
``observatory themes --audit`` prints the report.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from textual.theme import Theme

from observatory.ui.charts import HeatScale
from observatory.ui.colors import best_on, contrast, delta_e, mix


@dataclass(frozen=True)
class ThemeSpec:
    name: str
    title: str
    description: str
    dark: bool
    background: str
    surface: str
    raised: str
    border: str
    grid: str
    text: str
    muted: str
    primary: str
    secondary: str
    accent: str
    ok: str
    warn: str
    crit: str
    info: str
    action: str
    heat: tuple[str, ...]
    flow: tuple[str, str]
    series: tuple[str, ...]
    selection: str = ""          # table cursor background; derived from primary when empty
    notes: str = ""

    @property
    def chip_fg(self) -> str:
        """Text colour on solid status/brand chips (best of the theme's ink colours)."""
        inks = (self.background, "#000000", "#ffffff", self.text)
        chips = (self.ok, self.warn, self.crit, self.info, self.primary, self.action)
        return max(inks, key=lambda ink: min(contrast(ink, c) for c in chips))

    @property
    def cursor(self) -> str:
        return self.selection or mix(self.surface, self.primary, 0.28)


# ---------------------------------------------------------------- collection
COLLECTION: tuple[ThemeSpec, ...] = (
    ThemeSpec(
        name="mission-control", title="Mission Control",
        description="Flagship. Deep charcoal with soft cyan, electric blue and clean white — an operations centre.",
        dark=True,
        background="#0b0e13", surface="#10151c", raised="#161d27", border="#36434f", grid="#2a3442",
        text="#eef2f6", muted="#94a1b2",
        primary="#5ec8ec", secondary="#4d8dff", accent="#ffffff",
        ok="#3fd18f", warn="#f5b942", crit="#ff5f5f", info="#b09cff", action="#5ec8ec",
        heat=("#3b82d6", "#4cc4e0", "#f5b942", "#ff5f5f"),
        flow=("#4d8dff", "#5ec8ec"),
        series=("#5ec8ec", "#4d8dff", "#b09cff", "#f381c0", "#9fb0c3"),
    ),
    ThemeSpec(
        name="midnight-ops", title="Midnight Ops",
        description="SOC / NOC night shift. Near-black, restrained blue accents, soft white text.",
        dark=True,
        background="#06080b", surface="#0a0d11", raised="#10141a", border="#303a47", grid="#222a34",
        text="#e2e7ee", muted="#8994a3",
        primary="#6aa5ff", secondary="#4a7fe0", accent="#c9dcff",
        ok="#46c79f", warn="#eaa93a", crit="#f25757", info="#9a94f5", action="#6aa5ff",
        heat=("#3768c4", "#6aa5ff", "#eaa93a", "#f25757"),
        flow=("#4a7fe0", "#6aa5ff"),
        series=("#6aa5ff", "#b48cf0", "#4fc1d6", "#d98bc4", "#8994a3"),
    ),
    ThemeSpec(
        name="arctic", title="Arctic",
        description="Light. Cool greys, white panels and soft blues — clean and minimal for bright rooms.",
        dark=False,
        background="#eef1f5", surface="#ffffff", raised="#e4e9f0", border="#c3ccd8", grid="#d5dce5",
        text="#16202c", muted="#566375",
        primary="#1d63c4", secondary="#5348c7", accent="#0b1a2b",
        ok="#11703f", warn="#9c4c08", crit="#c0262c", info="#6b33c9", action="#1d63c4",
        heat=("#4a87cf", "#1d93ad", "#c56a12", "#c0262c"),
        flow=("#5348c7", "#1d63c4"),
        series=("#1d63c4", "#5348c7", "#0f8aa3", "#b8337a", "#5f6d80"),
        selection="#d6e4f7",
    ),
    ThemeSpec(
        name="cyber-grid", title="Cyber Grid",
        description="Cyberpunk, done tastefully. Dark indigo, electric teal and purple — no neon overload.",
        dark=True,
        background="#0b0d18", surface="#10131f", raised="#161a2a", border="#363c62", grid="#282d47",
        text="#e7e9f6", muted="#9196b8",
        primary="#2fd6d0", secondary="#9d83ff", accent="#d8ccff",
        ok="#62de86", warn="#ffc65c", crit="#ff6b8b", info="#9d83ff", action="#2fd6d0",
        heat=("#6c5ce7", "#2fd6d0", "#ffc65c", "#ff6b8b"),
        flow=("#9d83ff", "#2fd6d0"),
        series=("#2fd6d0", "#9d83ff", "#5aa8ff", "#e98bd6", "#9196b8"),
    ),
    ThemeSpec(
        name="oled-black", title="OLED Black",
        description="True black for OLED panels and always-on wall displays, with crisp high-contrast colour.",
        dark=True,
        background="#000000", surface="#000000", raised="#0d0d0d", border="#333333", grid="#2b2b2b",
        text="#f5f5f5", muted="#a3a3a3",
        primary="#4ec3ff", secondary="#8f86ff", accent="#ffffff",
        ok="#32d74b", warn="#ffd60a", crit="#ff453a", info="#bf9bff", action="#4ec3ff",
        heat=("#2f7dff", "#4ec3ff", "#ffd60a", "#ff453a"),
        flow=("#8f86ff", "#4ec3ff"),
        series=("#4ec3ff", "#8f86ff", "#64e3d8", "#ff7ab8", "#a3a3a3"),
    ),
    ThemeSpec(
        name="retro-terminal", title="Retro Terminal",
        description="Classic green phosphor, kept professional: amber warnings, red criticals, cyan notices.",
        dark=True,
        background="#030a05", surface="#06110a", raised="#0b1a10", border="#1f4029", grid="#1a3623",
        text="#bdf7c8", muted="#78b487",
        primary="#5be37f", secondary="#3fb866", accent="#e3ffe8",
        ok="#b6f04a", warn="#ffb547", crit="#ff6159", info="#65d6f2", action="#5be37f",
        heat=("#2e9c52", "#5be37f", "#ffb547", "#ff6159"),
        flow=("#3fb866", "#5be37f"),
        series=("#5be37f", "#65d6f2", "#b6f04a", "#d9c27a", "#78b487"),
    ),
    ThemeSpec(
        name="solar", title="Solar",
        description="Warm engineering workstation. Amber and gold on dark slate — easy on the eyes for long sessions.",
        dark=True,
        background="#12161b", surface="#171c22", raised="#1e242c", border="#38414c", grid="#323a45",
        text="#f1e9d8", muted="#aba18e",
        primary="#e9a94b", secondary="#c7884a", accent="#f6d27a",
        ok="#8fcb7a", warn="#ff8547", crit="#ff5468", info="#7fb7dc", action="#e9a94b",
        heat=("#5d8fbd", "#8fcb7a", "#ff8547", "#ff5468"),
        flow=("#c7884a", "#e9a94b"),
        series=("#e9a94b", "#7fb7dc", "#f6d27a", "#c99bd6", "#aba18e"),
    ),
)

SPECS: dict[str, ThemeSpec] = {s.name: s for s in COLLECTION}
DEFAULT_THEME = "mission-control"

# Names used by earlier versions → their closest member of the collection.
LEGACY_NAMES = {
    "observatory": "mission-control", "observatory-light": "arctic", "oled": "oled-black",
    "cyberpunk": "cyber-grid", "retro-green": "retro-terminal", "retro-amber": "solar",
    "nebula": "cyber-grid", "nord": "arctic", "textual-dark": "mission-control",
    "textual-light": "arctic",
}


def resolve_theme_name(name: str | None) -> str:
    if not name:
        return DEFAULT_THEME
    name = name.strip().lower()
    if name in SPECS:
        return name
    return LEGACY_NAMES.get(name, DEFAULT_THEME)


# ---------------------------------------------------------------------- audit
@dataclass(frozen=True)
class Check:
    label: str
    value: float
    required: float
    unit: str = ":1"

    @property
    def ok(self) -> bool:
        return self.value >= self.required


@dataclass
class AuditReport:
    theme: str
    checks: list[Check] = field(default_factory=list)

    @property
    def passed(self) -> bool:
        return all(c.ok for c in self.checks)

    @property
    def failures(self) -> list[Check]:
        return [c for c in self.checks if not c.ok]


# WCAG: 7:1 body text (AAA), 4.5:1 secondary text & status words (AA),
# 3:1 for graphical objects such as chart marks (1.4.11). Status colours must
# be at least ΔE 24 apart, and from brand colours, so alerts never read as decoration.
TEXT_AAA = 7.0
TEXT_AA = 4.5
GRAPHIC = 3.0
GRID_MIN = 1.25
SEPARATION = 24.0


def audit_theme(spec: ThemeSpec) -> AuditReport:
    r = AuditReport(spec.name)
    add = r.checks.append
    for bg_name in ("surface", "background", "raised"):
        bg = getattr(spec, bg_name)
        add(Check(f"text on {bg_name}", contrast(spec.text, bg), TEXT_AAA))
        add(Check(f"muted on {bg_name}", contrast(spec.muted, bg), TEXT_AA))
    for role in ("primary", "secondary", "accent", "ok", "warn", "crit", "info", "action"):
        add(Check(f"{role} text on surface", contrast(getattr(spec, role), spec.surface), TEXT_AA))
        add(Check(f"{role} text on raised", contrast(getattr(spec, role), spec.raised), TEXT_AA))
    for i, stop in enumerate(spec.heat):
        add(Check(f"heat[{i}] mark on surface", contrast(stop, spec.surface), GRAPHIC))
    for i, stop in enumerate(spec.flow):
        add(Check(f"flow[{i}] mark on surface", contrast(stop, spec.surface), GRAPHIC))
    for i, stop in enumerate(spec.series):
        add(Check(f"series[{i}] mark on surface", contrast(stop, spec.surface), GRAPHIC))
    add(Check("border on surface", contrast(spec.border, spec.surface), 1.6))
    add(Check("grid on surface", contrast(spec.grid, spec.surface), GRID_MIN))
    add(Check("text on table cursor", contrast(spec.text, spec.cursor), TEXT_AAA))
    for role in ("ok", "warn", "crit", "info", "primary", "action"):
        add(Check(f"chip text on {role}", contrast(spec.chip_fg, getattr(spec, role)), TEXT_AA))
    status = ("ok", "warn", "crit")
    for i, a in enumerate(status):
        for b in status[i + 1:]:
            add(Check(f"ΔE {a}↔{b}", delta_e(getattr(spec, a), getattr(spec, b)), SEPARATION, ""))
    for s in ("warn", "crit"):
        for b in ("primary", "accent", "secondary", "action", "info"):
            add(Check(f"ΔE {s}↔{b}", delta_e(getattr(spec, s), getattr(spec, b)), SEPARATION, ""))
    add(Check("ΔE ok↔primary", delta_e(spec.ok, spec.primary), 18.0, ""))
    add(Check("ΔE heat low↔high", delta_e(spec.heat[0], spec.heat[-1]), 60.0, ""))
    for i in range(len(spec.series) - 1):
        add(Check(f"ΔE series[{i}]↔[{i + 1}]", delta_e(spec.series[i], spec.series[i + 1]), 20.0, ""))
    return r


def audit_all() -> list[AuditReport]:
    return [audit_theme(s) for s in COLLECTION]


# ----------------------------------------------------------- textual themes
def to_textual(spec: ThemeSpec) -> Theme:
    return Theme(
        name=spec.name, primary=spec.primary, secondary=spec.secondary, accent=spec.accent,
        warning=spec.warn, error=spec.crit, success=spec.ok, foreground=spec.text,
        background=spec.background, surface=spec.surface, panel=spec.raised, dark=spec.dark,
        variables={
            "obs-border": spec.border,
            "obs-border-strong": mix(spec.border, spec.primary, 0.45),
            "obs-grid": spec.grid,
            "obs-muted": spec.muted,
            "obs-raised": spec.raised,
            "obs-cursor": spec.cursor,
            "obs-title": spec.primary,
            "obs-hero": spec.accent,
            "obs-chip-fg": spec.chip_fg,
            "obs-action": spec.action,
            "footer-key-foreground": spec.primary,
            "footer-description-foreground": spec.muted,
            "footer-background": spec.raised,
            "input-selection-background": f"{spec.primary} 35%",
            "block-cursor-background": spec.cursor,
            "block-cursor-foreground": spec.text,
            "block-cursor-text-style": "bold",
            "block-cursor-blurred-background": mix(spec.surface, spec.primary, 0.14),
            "block-cursor-blurred-foreground": spec.text,
            "block-hover-background": mix(spec.surface, spec.primary, 0.10),
            "scrollbar": spec.border,
            "scrollbar-hover": mix(spec.border, spec.primary, 0.4),
            "scrollbar-active": spec.primary,
            "scrollbar-background": spec.surface,
            "scrollbar-corner-color": spec.surface,
            "text-muted": spec.muted,
        },
    )


THEMES: dict[str, Theme] = {s.name: to_textual(s) for s in COLLECTION}
THEME_DESCRIPTIONS = {s.name: s.description for s in COLLECTION}
THEME_TITLES = {s.name: s.title for s in COLLECTION}


def theme_variable_defaults() -> dict[str, str]:
    """Fallback values for Observatory's custom CSS variables (flagship theme)."""
    return dict(THEMES[DEFAULT_THEME].variables)


def register_themes(app) -> None:
    """Register the collection and remove every theme that is not part of it."""
    for theme in THEMES.values():
        app.register_theme(theme)


def prune_foreign_themes(app) -> None:
    """Call after the app's theme is set to one of ours: drops Textual's built-in themes
    (never designed for this dashboard) from the picker and command palette."""
    for name in list(app.available_themes):
        if name not in THEMES and name != app.theme:
            app.unregister_theme(name)


# ------------------------------------------------------------------ palette
@dataclass(frozen=True, slots=True)
class Palette:
    """Rich-side view of a theme, used by every chart and panel renderer."""

    primary: str
    secondary: str
    accent: str
    ok: str
    warn: str
    crit: str
    info: str
    action: str
    text: str
    muted: str
    grid: str
    border: str
    surface: str
    raised: str
    background: str
    chip_fg: str
    heat: tuple[str, ...]          # calm → hot, for "more is worse" metrics
    cool: tuple[str, ...]          # brand flow gradient for neutral volume metrics
    series: tuple[str, ...]        # categorical marks
    dark: bool = True

    def for_score(self, score: float) -> str:
        """Colour for a 0-100 health-style score (higher is better)."""
        if score >= 90:
            return self.ok
        if score >= 75:
            return self.primary
        if score >= 55:
            return self.warn
        return self.crit

    def for_load(self, fraction: float) -> str:
        """Colour for a 0..1 utilisation (higher is worse)."""
        if fraction >= 0.9:
            return self.crit
        if fraction >= 0.7:
            return self.warn
        return self.ok

    def for_severity(self, severity: str) -> str:
        return {"critical": self.crit, "warning": self.warn, "notice": self.info, "good": self.ok,
                "info": self.muted}.get(severity, self.primary)

    def on(self, color: str) -> str:
        """Ink for text drawn on a solid ``color`` chip: the theme's chip ink when it is legible
        (every status/brand role is audited for it), otherwise the best of black/white/text."""
        if contrast(self.chip_fg, color) >= 4.5:
            return self.chip_fg
        return best_on(color, (self.chip_fg, self.text, self.background, "#000000", "#ffffff"))

    def for_risk(self, level: str) -> str:
        return {"low": self.ok, "elevated": self.warn, "high": self.crit, "critical": self.crit}.get(level, self.muted)


def palette_from_spec(spec: ThemeSpec) -> Palette:
    return Palette(
        primary=spec.primary, secondary=spec.secondary, accent=spec.accent, ok=spec.ok, warn=spec.warn,
        crit=spec.crit, info=spec.info, action=spec.action, text=spec.text, muted=spec.muted, grid=spec.grid,
        border=spec.border, surface=spec.surface, raised=spec.raised, background=spec.background,
        chip_fg=spec.chip_fg, heat=HeatScale(spec.heat), cool=spec.flow, series=spec.series, dark=spec.dark,
    )


PALETTES: dict[str, Palette] = {s.name: palette_from_spec(s) for s in COLLECTION}


def palette_for(theme_name: str, theme: Theme | None = None) -> Palette:
    return PALETTES.get(resolve_theme_name(theme_name)) or PALETTES[DEFAULT_THEME]
