"""The Home dashboard panels — Observatory's command center.

Design rules
------------
* The dashboard is the product: every panel pairs live state with history
  (24 h / 7 d / learned baseline), a prediction where one exists, and the
  action that follows from it.
* Every panel renders line by line with explicit truncation, so nothing
  wraps unexpectedly at any terminal size; panels drop their least important
  lines first when given less height.
* Colour carries meaning only: the palette's ok/warn/crit for status, the
  heat gradient for "more is worse", the brand gradient for volume.
* Clicking a panel opens its deep-dive screen.
"""

from __future__ import annotations

import time
from collections.abc import Iterable, Sequence
from typing import TYPE_CHECKING

from rich.console import Group
from rich.style import Style
from rich.text import Text
from textual.events import Click
from textual.widget import Widget

from observatory.collectors.sensors import cpu_package_temp
from observatory.models import Snapshot
from observatory.ui.charts import (
    block_area, gradient, gradient_text, hbar, heatmap_grid, mirror_area, pulse_line, pulse_wave, radar_chart,
    ring_gauge,
    seg_text, seg_width, spark_blocks, stacked_bar,
)
from observatory.ui.themes import Palette
from observatory.util.format import fmt_bytes, fmt_duration, fmt_money, fmt_rate, fmt_watts, truncate

if TYPE_CHECKING:  # pragma: no cover
    from observatory.ui.app import ObservatoryApp

STATUS_ICON = {"Excellent": "●", "Healthy": "●", "Warning": "▲", "Degraded": "▲", "Critical": "✖"}


# ================================================================= helpers
def arrow(current: float, previous: float | None, tolerance: float = 0.05) -> tuple[str, str]:
    """Trend arrow and its semantic ('up'|'down'|'flat') comparing to a previous value."""
    if previous is None or previous == 0:
        return "→", "flat"
    change = (current - previous) / abs(previous)
    if change > tolerance:
        return "▲", "up"
    if change < -tolerance:
        return "▼", "down"
    return "→", "flat"


def pct_change(current: float | None, previous: float | None) -> str:
    if current is None or previous is None or previous == 0:
        return "—"
    change = (current - previous) / abs(previous) * 100
    return f"{'+' if change >= 0 else ''}{change:.0f}%"


def fit(text: Text, width: int) -> Text:
    """Single display line: never wraps, ellipsis when too long."""
    text.no_wrap = True
    text.overflow = "ellipsis"
    if text.cell_len > width:
        text.truncate(max(width, 1), overflow="ellipsis")
    return text


def wrap_words(text: str, width: int) -> list[str]:
    width = max(width, 8)
    lines: list[str] = []
    current = ""
    for word in text.split():
        if len(current) + len(word) + (1 if current else 0) > width:
            if current:
                lines.append(current)
            while len(word) > width:
                lines.append(word[:width])
                word = word[width:]
            current = word
        else:
            current = f"{current} {word}" if current else word
    if current:
        lines.append(current)
    return lines or [""]


def when_in(days: float) -> str:
    return time.strftime("%b %d", time.localtime(time.time() + days * 86400))


def short_time(ts: float, now: float | None = None) -> str:
    now = now if now is not None else time.time()
    if time.localtime(ts)[:3] == time.localtime(now)[:3]:
        return time.strftime("%H:%M", time.localtime(ts))
    if now - ts < 6 * 86400:
        return time.strftime("%a %H:%M", time.localtime(ts))
    return time.strftime("%b %d", time.localtime(ts))


def lines_group(lines: Sequence[Text], height: int) -> Group:
    return Group(*list(lines)[: max(height, 0)])


# ============================================================== base panel
class DashPanel(Widget):
    """Base class: holds the latest snapshot and re-renders on update."""

    DEFAULT_CLASSES = "dash-panel"
    TITLE = ""
    LINK: str | None = None   # section opened when the panel is clicked

    def __init__(self, *, id: str | None = None, classes: str | None = None) -> None:
        super().__init__(id=id, classes=classes)
        self.add_class("dash-panel")
        self.snap: Snapshot | None = None
        if self.TITLE:
            self.border_title = self.TITLE

    @property
    def obs(self) -> "ObservatoryApp":
        return self.app  # type: ignore[return-value]

    @property
    def pal(self) -> Palette:
        return self.obs.palette

    def update_snapshot(self, snap: Snapshot) -> None:
        self.snap = snap
        try:
            self.update_titles(snap)
        except Exception:  # a title bug must not take the dashboard down
            pass
        self.refresh()

    def update_titles(self, snap: Snapshot) -> None:
        """Override to set border subtitles from the snapshot."""

    def render(self):
        if self.snap is None:
            return Text("collecting…", style=self.pal.muted)
        try:
            return self.render_panel(self.snap, max(self.size.width, 10), max(self.size.height, 1))
        except Exception as exc:  # a panel bug must not take the dashboard down
            return Text(f"panel error: {exc}", style=self.pal.crit)

    def render_panel(self, snap: Snapshot, width: int, height: int):  # pragma: no cover - overridden
        raise NotImplementedError

    def on_click(self, event: Click) -> None:
        if self.LINK:
            self.obs.action_show(self.LINK)

    # styling helpers
    def s(self, color: str | None = None, bold: bool = False, italic: bool = False) -> Style:
        return Style(color=color or self.pal.text, bold=bold, italic=italic)

    def muted(self, text: str, italic: bool = False) -> Text:
        return Text(text, style=Style(color=self.pal.muted, italic=italic))

    def label(self, text: str) -> Text:
        return Text(text, style=Style(color=self.pal.muted, bold=True))

    def rule(self, title: str, width: int, color: str | None = None) -> Text:
        t = Text()
        t.append(f"{title} ", Style(color=color or self.pal.accent, bold=True))
        t.append("─" * max(width - len(title) - 1, 0), Style(color=self.pal.grid))
        return t


# ================================================================== header
class HeaderBar(Widget):
    """Logo, identity, a live pulse, vital signs and the navigation strip."""

    DEFAULT_CLASSES = "header-bar"
    PULSE_COLS = 14

    def __init__(self, sections: list[tuple[str, str, str]], **kwargs) -> None:
        super().__init__(**kwargs)
        self.sections = sections  # (id, key, title)
        self.active = sections[0][0]
        self.snap: Snapshot | None = None
        self.phase = 0

    @property
    def pal(self) -> Palette:
        return self.app.palette  # type: ignore[attr-defined]

    def on_mount(self) -> None:
        self.set_interval(1 / 6, self._beat)

    def _beat(self) -> None:
        app = self.app
        if getattr(app, "animations", False) and not getattr(app, "paused", False):
            self.phase += 1
            self.refresh()

    def set_active(self, section: str) -> None:
        self.active = section
        self.refresh()

    def update_snapshot(self, snap: Snapshot) -> None:
        self.snap = snap
        self.refresh()

    def _chips(self, snap: Snapshot) -> list[Text]:
        pal = self.pal
        chips: list[Text] = []
        if getattr(self.app, "paused", False):
            chips.append(Text(" ⏸ PAUSED ", style=Style(color=pal.chip_fg, bgcolor=pal.warn, bold=True)))
        ident = snap.identity
        host = Text()
        host.append(snap.hostname, Style(bold=True, color=pal.text))
        if ident is not None:
            host.append(f" {ident.platform or ident.os_name}", Style(color=pal.muted))
        chips.append(host)
        chips.append(Text(f"up {fmt_duration(snap.uptime_s)}", style=pal.muted))
        # live pulse
        activity = getattr(self.app, "history", None)
        series = activity.get("activity") if activity is not None else []
        level = series[-1] if series else 0.0
        pulse = Text()
        pulse.append("♥ ", Style(color=pal.crit if level > 0.85 else pal.accent, bold=True))
        pulse.append_text(pulse_line(self.phase, self.PULSE_COLS, level, [pal.secondary, pal.primary, pal.accent],
                                     pal.grid))
        pulse.append(f" {int(55 + 110 * level)} bpm", Style(color=pal.muted))
        chips.append(pulse)
        chips.append(Text.assemble(("ϟ ", Style(color=pal.accent, bold=True)),
                                   (fmt_watts(snap.power.wall_watts), Style(color=pal.accent, bold=True)),
                                   (f" {fmt_money(snap.cost.hourly_cost, snap.cost.currency_symbol, 3)}/h",
                                    Style(color=pal.muted))))
        if snap.scores is not None:
            s = snap.scores
            c = pal.for_score(s.overall)
            chips.append(Text.assemble(("health ", pal.muted), (f"{s.overall} ", Style(color=c, bold=True)),
                                       (s.status, Style(color=c))))
            rc = risk_color(pal, s.risk)
            chips.append(Text.assemble(("risk ", pal.muted), (f"{s.risk} ", Style(color=rc, bold=True)),
                                       (s.risk_status, Style(color=rc))))
        crit = sum(1 for a in snap.alerts if a.severity == "critical")
        if snap.alerts:
            n = len(snap.alerts)
            chips.append(Text(f"▲ {n} alert{'s' if n != 1 else ''}",
                              style=Style(color=pal.crit if crit else pal.warn, bold=True)))
        else:
            chips.append(Text("✔ no alerts", style=pal.ok))
        if snap.updates is not None and snap.updates.available:
            chips.append(Text(f"⬆ {snap.updates.label}", style=pal.warn if snap.updates.security else pal.primary))
        if snap.services is not None and snap.services.reboot_required:
            chips.append(Text("⟳ reboot needed", style=pal.warn))
        chips.append(Text("● REC" if snap.recording else "● LIVE", style=pal.crit if snap.recording else pal.ok))
        return chips

    def render(self):
        pal = self.pal
        width = self.size.width
        line1 = Text()
        line1.append_text(gradient_text(" ◉ OBSERVATORY ", [pal.secondary, pal.primary, pal.accent]))
        clock = Text(time.strftime(" %a %H:%M:%S "), style=Style(color=pal.text, bold=True))
        chips = self._chips(self.snap) if self.snap is not None else []
        budget = width - line1.cell_len - clock.cell_len - 1
        sep = Text(" │ ", style=pal.grid)
        used = 0
        for i, chip in enumerate(chips):
            needed = chip.cell_len + (sep.cell_len if i else 1)
            if used + needed > budget:
                continue  # skip chips that do not fit, keep trying smaller ones
            line1.append_text(sep if i else Text(" "))
            line1.append_text(chip)
            used += needed
        line1.append(" " * max(width - line1.cell_len - clock.cell_len, 0))
        line1.append_text(clock)

        nav = Text(" ")
        for sid, key, title in self.sections:
            if sid == self.active:
                nav.append(f" {key} ", Style(color=pal.on(pal.primary), bgcolor=pal.primary, bold=True))
                nav.append(f" {title} ", Style(color=pal.primary, bold=True))
            else:
                nav.append(f" {key} ", Style(color=pal.primary, bold=True))
                nav.append(f"{title} ", Style(color=pal.muted))
            nav.append(" ")
        nav.append(" T ", Style(color=pal.primary, bold=True))
        nav.append("Themes  ", Style(color=pal.muted))
        nav.append(" ? ", Style(color=pal.primary, bold=True))
        nav.append("Help", Style(color=pal.muted))
        return Group(fit(line1, width), fit(nav, width))


def risk_color(pal: Palette, risk: float) -> str:
    return pal.ok if risk < 15 else pal.primary if risk < 35 else pal.warn if risk < 60 else pal.crit


# ============================================================ metric tiles
class MetricTile(DashPanel):
    """One resource: live value and trend arrow, a 24-hour area chart whose last
    column is "now", and the historical context line (peak, 7-day, last week)."""

    LINKS = {"cpu": "processes", "mem": "processes", "swap": "processes", "disk": "storage", "net": "network",
             "gpu": "power", "load": "processes", "temp": "storage"}

    def __init__(self, kind: str, **kwargs) -> None:
        super().__init__(**kwargs)
        self.kind = kind
        self.LINK = self.LINKS.get(kind)

    def _spec(self, snap: Snapshot) -> dict:
        ctx = snap.context
        h = self.obs.history
        pal = self.pal
        k = self.kind
        m = (lambda key: ctx.metric(key)) if ctx else (lambda key: None)
        pct = lambda v: f"{v:.0f}%"  # noqa: E731
        if k == "cpu":
            temp = cpu_package_temp(snap.temps)
            extra = f"{snap.cpu.freq_mhz / 1000:.1f}GHz" + (f" {temp:.0f}°C" if temp else "")
            return dict(title="CPU", value=snap.cpu.percent, text=pct(snap.cpu.percent), extra=extra,
                        live=h.get("cpu"), max=100, ctx=m("cpu"), fmt=pct, stops=pal.heat,
                        load=snap.cpu.percent / 100)
        if k == "mem":
            mem = snap.memory
            return dict(title="MEMORY", value=mem.percent, text=pct(mem.percent),
                        extra=f"{fmt_bytes(mem.used, 0)}/{fmt_bytes(mem.total, 0)}", live=h.get("mem"), max=100,
                        ctx=m("mem"), fmt=pct, stops=pal.heat, load=mem.percent / 100)
        if k == "swap":
            sw = snap.swap
            extra = f"{fmt_bytes(sw.used, 0)}/{fmt_bytes(sw.total, 0)}" if sw.total else "none configured"
            if sw.sout_bps > 0:
                extra = f"out {fmt_rate(sw.sout_bps)}"
            return dict(title="SWAP", value=sw.percent, text=pct(sw.percent), extra=extra, live=h.get("swap"),
                        max=100, ctx=m("swap"), fmt=pct, stops=pal.heat, load=sw.percent / 100)
        if k == "disk":
            total = sum(d.total_bps for d in snap.disk_io)
            busiest = snap.most_active_drive()
            util = max((d.util_percent for d in snap.disk_io), default=0.0)
            extra = f"{busiest.device} {busiest.util_percent:.0f}%" if busiest else "no devices"
            return dict(title="DISK I/O", value=total, text=fmt_rate(total), extra=extra, live=h.get("disk"),
                        max=None, ctx=m("disk"), fmt=fmt_rate, stops=pal.cool + (pal.accent,), load=util / 100)
        if k == "net":
            rx, tx = snap.net_totals()
            ctx_net = _sum_ctx(ctx.metric("rx"), ctx.metric("tx")) if ctx else None
            return dict(title="NETWORK", value=rx + tx, text=f"↓{fmt_rate(rx)}", extra=f"↑{fmt_rate(tx)}",
                        live=h.get("net"), max=None, ctx=ctx_net, fmt=fmt_rate, stops=pal.cool + (pal.accent,),
                        load=0.0)
        if k == "temp":
            hot = snap.hottest()
            if hot is None:
                return dict(title="THERMAL", value=0.0, text="n/a", extra="no sensors", live=[], max=100,
                            ctx=m("temp"), fmt=lambda v: f"{v:.0f}°", stops=pal.heat, load=0.0, min=20)
            name = hot.label if hot.chip in ("drivetemp", "nvidia") and hot.label else hot.chip
            return dict(title="THERMAL", value=hot.current, text=f"{hot.current:.0f}°C", extra=truncate(name, 12),
                        live=h.get("temp"), max=100, ctx=m("temp"), fmt=lambda v: f"{v:.0f}°", stops=pal.heat,
                        load=max((hot.current - 30) / 65, 0.0), min=20)
        if k == "gpu" and snap.gpus:
            g = next((x for x in snap.gpus if x.util_percent is not None), snap.gpus[0])
            util = g.util_percent or 0.0
            parts = []
            if g.power_w is not None:
                parts.append(f"{g.power_w:.0f}W")
            if g.mem_used is not None and g.mem_total:
                parts.append(f"{g.mem_used / g.mem_total * 100:.0f}%vram")
            return dict(title="GPU", value=util, text=pct(util) if g.util_percent is not None else "idle",
                        extra=" ".join(parts) or truncate(g.name, 14), live=h.get("gpu"), max=100, ctx=m("gpu"),
                        fmt=pct, stops=pal.heat, load=util / 100)
        load = snap.load
        return dict(title="LOAD", value=load.load1, text=f"{load.load1:.2f}",
                    extra=f"{load.per_core1:.2f}/core", live=h.get("load"), max=max(load.cores, 1),
                    ctx=m("load"), fmt=lambda v: f"{v:.1f}", stops=pal.heat, load=load.per_core1 / 2)

    def update_titles(self, snap: Snapshot) -> None:
        spec = self._spec(snap)
        self.border_title = spec["title"]
        ctx = spec["ctx"]
        has_history = ctx is not None and ctx.series_24h and any(ctx.series_24h)
        self.border_subtitle = "24 h" if has_history else "live"

    def render_panel(self, snap: Snapshot, width: int, height: int):
        pal = self.pal
        spec = self._spec(snap)
        ctx = spec["ctx"]
        live = spec["live"] or []
        value = spec["value"]
        color = pal.for_load(spec["load"]) if spec["load"] else pal.primary

        head = Text()
        head.append(spec["text"], Style(color=color, bold=True))
        prev = live[-min(len(live), 30)] if len(live) > 3 else (ctx.avg_1h if ctx else None)
        sym, direction = arrow(value, prev, 0.15)
        head.append(f" {sym} ", Style(color=pal.warn if direction == "up" else pal.ok if direction == "down"
                                      else pal.muted))
        head.append(spec["extra"], Style(color=pal.muted))
        lines: list = [fit(head, width)]

        chart_rows = max(height - 2, 1)
        if ctx is not None and ctx.series_24h and any(ctx.series_24h):
            data = list(ctx.series_24h)
            data[-1] = value  # rightmost column is "now"
            data = data[-max(width, 1):] if len(data) > width * 3 else data
            baseline = ctx.avg_7d
        else:
            data = list(live) or [0.0]
            baseline = None
        chart = block_area(data, width, chart_rows, spec["stops"], spec["max"], spec.get("min", 0.0),
                           baseline=baseline, baseline_color=pal.muted, empty_color=pal.grid,
                           marker_last=pal.accent)
        lines.append(chart)
        if height >= 3:
            lines.append(fit(self._context_line(spec, ctx, value), width))
        return Group(*lines)

    def _context_line(self, spec: dict, ctx, value: float) -> Text:
        pal = self.pal
        fmt = spec["fmt"]
        info = Text()
        if ctx is None or (ctx.peak_24h is None and ctx.avg_7d is None):
            info.append("history builds in the first hour", Style(color=pal.muted, italic=True))
            return info
        # pieces in priority order; each is added only if it fits the tile
        pieces: list[list[tuple[str, Style]]] = []
        if ctx.peak_24h is not None:
            pieces.append([("pk ", Style(color=pal.muted)), (fmt(ctx.peak_24h), Style(color=pal.text, bold=True))])
        if ctx.avg_7d is not None:
            pieces.append([("7d ", Style(color=pal.muted)), (fmt(ctx.avg_7d), Style(color=pal.text))])
        if ctx.avg_7d and ctx.avg_prev_7d:
            change = (ctx.avg_7d - ctx.avg_prev_7d) / ctx.avg_prev_7d
            up = change >= 0
            pieces.append([(f"{'▲' if up else '▼'}{abs(change) * 100:.0f}% wk",
                            Style(color=pal.warn if up and change > 0.1 else pal.ok if not up else pal.muted))])
        if ctx.peak_24h_ts:
            pieces.insert(1, [(time.strftime("@%H:%M", time.localtime(ctx.peak_24h_ts)), Style(color=pal.muted))])
        width = max(self.size.width, 10)
        for piece in pieces:
            piece_len = sum(len(text) for text, _ in piece) + (1 if info.cell_len else 0)
            if info.cell_len + piece_len > width:
                continue
            if info.cell_len:
                info.append(" ")
            for text, style in piece:
                info.append(text, style)
        return info


def _sum_ctx(a, b):
    """Combine rx and tx contexts into one 'total traffic' context."""
    from observatory.engines.intelligence import MetricContext

    def add(x, y):
        if x is None and y is None:
            return None
        return (x or 0) + (y or 0)

    out = MetricContext()
    out.avg_1h = add(a.avg_1h, b.avg_1h)
    out.avg_24h = add(a.avg_24h, b.avg_24h)
    out.peak_24h = add(a.peak_24h, b.peak_24h)
    out.peak_24h_ts = a.peak_24h_ts
    out.avg_7d = add(a.avg_7d, b.avg_7d)
    out.avg_prev_7d = add(a.avg_prev_7d, b.avg_prev_7d)
    out.last_week_now = add(a.last_week_now, b.last_week_now)
    if a.series_24h and b.series_24h:
        out.series_24h = [x + y for x, y in zip(a.series_24h, b.series_24h)]
    return out


# =========================================================== health center
SUB_LABELS = (("stability", "Stability"), ("power", "Power"), ("thermal", "Thermal"), ("storage", "Storage"),
              ("network", "Network"))


class HealthCenter(DashPanel):
    TITLE = "INFRASTRUCTURE HEALTH"
    LINK = "alerts"

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self.shown_score = 0.0
        self._timer = None

    def update_snapshot(self, snap: Snapshot) -> None:
        super().update_snapshot(snap)
        target = float(snap.scores.overall if snap.scores else snap.health.score)
        if self.obs.animations and abs(target - self.shown_score) > 1:
            self._animate_to(target)
        else:
            self.shown_score = target

    def _animate_to(self, target: float) -> None:
        """Sweep the ring towards the new score (ease-out, ~0.6 s)."""
        if self._timer is not None:
            self._timer.stop()

        def tick() -> None:
            delta = target - self.shown_score
            self.shown_score = target if abs(delta) <= 0.5 else self.shown_score + delta * 0.25
            self.refresh()
            if self.shown_score == target and self._timer is not None:
                self._timer.stop()
                self._timer = None

        self._timer = self.set_interval(1 / 30, tick, repeat=45)

    def update_titles(self, snap: Snapshot) -> None:
        ctx = snap.context
        if ctx is not None and ctx.history_days:
            self.border_subtitle = f"learning {ctx.history_days:.0f} d" if ctx.history_days < 7 else \
                f"baseline {min(ctx.history_days, 28):.0f} d"
        else:
            self.border_subtitle = "live"

    def render_panel(self, snap: Snapshot, width: int, height: int):
        pal = self.pal
        scores = snap.scores
        overall = scores.overall if scores else snap.health.score
        status = scores.status if scores else snap.health.grade
        color = pal.for_score(overall)
        shown = int(round(self.shown_score)) if self.shown_score else overall

        ring_cols = 20 if width >= 46 else 16
        reasons_rows = 3 if height >= 12 else 1 if height >= 10 else 0
        ring_rows = max(min(height - reasons_rows, 9), 5)
        digits = seg_text(str(shown), Style(color=color, bold=True))
        center: list[Text] = []
        if seg_width(str(shown)) <= ring_cols - 6 and ring_rows >= 7:
            center = [*digits, Text(status.upper(), style=Style(color=color, bold=True))]
        else:
            center = [Text(str(shown), Style(color=color, bold=True)), Text(status.upper(), Style(color=color))]
        ring = ring_gauge(self.shown_score / 100 if self.shown_score else overall / 100, ring_cols, ring_rows,
                          pal.secondary, pal.grid, center, thickness=2, color_end=color)
        ring_lines = ring.split("\n")

        right_w = max(width - ring_cols - 2, 10)
        # label (10) + bar + " 100 " (5) + status (≤ 9): the bar gives way first so the
        # status word — the thing that matters — is never cut off
        bar_w = min(right_w - 25, 14)
        if bar_w < 3:
            bar_w = 0
        right: list[Text] = []
        if scores:
            right.append(fit(Text("SUBSYSTEMS", Style(color=pal.muted, bold=True)), right_w))
            for key, name in SUB_LABELS:
                sub = scores.subs.get(key)
                if sub is None:
                    continue
                c = pal.for_score(sub.score)
                t = Text()
                t.append(f"{name:<10}", Style(color=pal.text, bold=True))
                if bar_w:
                    t.append_text(hbar(sub.score / 100, bar_w, c, pal.grid))
                t.append(f" {sub.score:>3} ", Style(color=c, bold=True))
                t.append(sub.status, Style(color=c))
                right.append(fit(t, right_w))
            right.append(Text(""))
            rc = risk_color(pal, scores.risk)
            t = Text()
            t.append(f"{'Risk':<10}", Style(color=pal.text, bold=True))
            if bar_w:
                t.append_text(hbar(scores.risk / 100, bar_w, rc, pal.grid))
            t.append(f" {scores.risk:>3} ", Style(color=rc, bold=True))
            t.append(scores.risk_status, Style(color=rc))
            right.append(fit(t, right_w))
            eff = scores.power_efficiency
            t = Text()
            t.append(f"{'Efficiency':<10}", Style(color=pal.text, bold=True))
            if bar_w:
                t.append_text(hbar(eff / 100, bar_w, pal.for_score(eff), pal.grid))
            t.append(f" {eff:>3} ", Style(color=pal.for_score(eff), bold=True))
            t.append("power", Style(color=pal.muted))
            right.append(fit(t, right_w))

        body: list[Text] = []
        for i in range(ring_rows):
            row = Text()
            row.append_text(ring_lines[i] if i < len(ring_lines) else Text(" " * ring_cols))
            row.append("  ")
            if i < len(right):
                row.append_text(right[i])
            body.append(fit(row, width))

        # Why: the weakest subsystems and the top risk factor, in plain words
        if reasons_rows and scores:
            weak = sorted((s for s in scores.subs.values() if s.score < 90 and s.reasons), key=lambda s: s.score)
            for sub in weak[: max(reasons_rows - 1, 1)]:
                c = pal.for_score(sub.score)
                t = Text()
                t.append(f"{STATUS_ICON.get(sub.status, '●')} {sub.name.capitalize()}: ", Style(color=c, bold=True))
                t.append("; ".join(sub.reasons[:2]), Style(color=pal.text))
                body.append(fit(t, width))
            if scores.risk_reasons and len(body) < height:
                t = Text()
                t.append("⚠ Risk: ", Style(color=risk_color(pal, scores.risk), bold=True))
                t.append("; ".join(scores.risk_reasons[:2]), Style(color=pal.text))
                body.append(fit(t, width))
            if not weak and not scores.risk_reasons:
                body.append(fit(Text("✔ Every subsystem is healthy.", Style(color=pal.ok)), width))
        return lines_group(body, height)


# ================================================================ insights
class InsightsPanel(DashPanel):
    """What is happening and why (insights), then what to do (ranked actions)."""

    TITLE = "OBSERVATORY INSIGHTS"
    LINK = "alerts"

    def update_titles(self, snap: Snapshot) -> None:
        attention = sum(1 for i in snap.insights if i.severity in ("critical", "warning", "notice"))
        self.border_subtitle = f"{attention} need attention · {len(snap.insights)} total"

    def render_panel(self, snap: Snapshot, width: int, height: int):
        pal = self.pal
        actions = [i for i in snap.insights if i.recommendation and i.severity in ("critical", "warning", "notice")]
        n_actions = min(len(actions), 4 if height >= 12 else 3 if height >= 9 else 2)
        action_rows = (n_actions + 1) if n_actions else 0
        insight_rows = max(height - action_rows, 1)

        lines: list[Text] = []
        for ins in snap.insights:
            color = pal.for_severity(ins.severity)
            wrapped = wrap_words(ins.text, width - 4)
            if len(lines) + 1 > insight_rows:
                break
            room = insight_rows - len(lines)
            take = wrapped[: min(2, room)]
            for k, chunk in enumerate(take):
                t = Text()
                if k == 0:
                    t.append("▌", Style(color=color, bold=True))
                    t.append(f"{ins.icon} ", Style(color=color, bold=True))
                else:
                    t.append("▌  ", Style(color=color))
                last = k == len(take) - 1 and len(wrapped) > len(take)
                t.append(chunk + ("…" if last else ""), Style(color=pal.text,
                                                               bold=k == 0 and ins.severity in ("critical", "warning")))
                lines.append(fit(t, width))
        while len(lines) < insight_rows:
            lines.append(Text(""))

        if n_actions:
            lines.append(self.rule("▶ DO NEXT", width, pal.action))
            for idx, ins in enumerate(actions[:n_actions], 1):
                color = pal.for_severity(ins.severity)
                impact = ins.impact
                t = Text()
                t.append(f" {idx} ", Style(color=pal.on(color), bgcolor=color, bold=True))
                t.append(" ")
                room = width - 5 - (len(impact) + 2 if impact else 0)
                t.append(truncate(ins.recommendation, max(room, 10)), Style(color=pal.text))
                if impact:
                    t.append(" " * max(width - t.cell_len - len(impact), 1))
                    t.append(impact, Style(color=color, bold=True))
                lines.append(fit(t, width))
        return lines_group(lines, height)


# ============================================================= power & cost
class PowerCenter(DashPanel):
    TITLE = "POWER & COST"
    LINK = "power"

    def update_titles(self, snap: Snapshot) -> None:
        p = snap.power
        self.border_subtitle = f"{p.method} · ±{(p.high_watts - p.low_watts) / 2:.0f} W · PSU {p.psu_efficiency:.2f}"

    def render_panel(self, snap: Snapshot, width: int, height: int):
        pal = self.pal
        cost = snap.cost
        sym = cost.currency_symbol
        ctx = snap.context
        e = ctx.energy if ctx else None
        pm = ctx.metric("power") if ctx else None

        # ---- hero: big watts + cost now / today / week
        watts_txt = f"{snap.power.wall_watts:.0f}"
        big = seg_text(watts_txt, Style(color=pal.accent, bold=True))
        big_w = seg_width(watts_txt) + 2
        unit = [Text(""), Text(""), Text("W", Style(color=pal.accent, bold=True))]
        side_w = max(width - big_w - 3, 10)
        week_change = e.week_change if e else None
        side = [
            Text.assemble((fmt_money(cost.hourly_cost, sym, 3), self.s(pal.text, True)), (" /hour now", pal.muted)),
            Text.assemble(("today ", pal.muted), (fmt_money(cost.today_cost, sym), self.s(pal.text, True)),
                          (f"  {cost.today_kwh:.1f} kWh", pal.muted)),
            Text.assemble(("week  ", pal.muted), (fmt_money(e.week_cost if e else 0, sym), self.s(pal.text, True)),
                          (f"  {'▲' if (week_change or 0) > 0 else '▼'}{abs(week_change) * 100:.0f}% vs last"
                           if week_change is not None else "", pal.warn if (week_change or 0) > 0.1 else pal.muted)),
        ]
        lines: list[Text] = []
        for i in range(3):
            row = Text()
            row.append_text(big[i])
            row.append_text(unit[i])
            row.append(" " * max(big_w - big[i].cell_len - 1, 1))
            row.append("  ")
            row.append_text(fit(side[i], side_w))
            lines.append(fit(row, width))

        # ---- projections
        proj = Text()
        f30 = e.forecast_30d_cost if e else None
        for label, value, color in (("month ", fmt_money(cost.monthly_estimate, sym), pal.primary),
                                    ("  year ", fmt_money(cost.annual_estimate, sym, 0), pal.primary),
                                    ("  next 30d ", fmt_money(f30, sym) if f30 is not None else "—", pal.secondary)):
            proj.append(label, Style(color=pal.muted))
            proj.append(value, Style(color=color, bold=True))
        lines.append(fit(proj, width))

        # ---- 24 h power chart with the average as a dotted reference
        fixed_after = 4  # peak line, flow bar, legend, efficiency/tip
        chart_rows = max(min(height - len(lines) - fixed_after, 4), 1)
        series = list(pm.series_24h) if pm and pm.series_24h and any(pm.series_24h) else []
        if series:
            series[-1] = snap.power.wall_watts
        data = series or self.obs.history.get("power") or [snap.power.wall_watts]
        lo = min(v for v in data if v > 0) * 0.85 if any(v > 0 for v in data) else 0.0
        lines.append(block_area(data, width, chart_rows, [pal.secondary, pal.primary, pal.accent],
                                min_value=lo, baseline=cost.average_watts or None, baseline_color=pal.muted,
                                empty_color=pal.grid, marker_last=pal.accent))
        peak = Text()
        if pm and pm.peak_24h is not None:
            peak.append("▲ peak ", Style(color=pal.muted))
            peak.append(fmt_watts(pm.peak_24h), Style(color=pal.warn, bold=True))
            if pm.peak_24h_ts:
                peak.append(time.strftime(" %H:%M", time.localtime(pm.peak_24h_ts)), Style(color=pal.muted))
            if ctx and ctx.power_peak_process:
                peak.append(f" ({ctx.power_peak_process})", Style(color=pal.text))
            if pm.low_24h is not None:
                peak.append("  ▼ low ", Style(color=pal.muted))
                peak.append(fmt_watts(pm.low_24h), Style(color=pal.ok, bold=True))
            peak.append("  avg ", Style(color=pal.muted))
            peak.append(fmt_watts(cost.average_watts), Style(color=pal.text))
        else:
            peak.append(f"24 h history appears after the first hour · avg {fmt_watts(cost.average_watts)}",
                        Style(color=pal.muted, italic=True))
        lines.append(fit(peak, width))

        # ---- power flow: hardware → watts → cost
        comps = [c for c in sorted(snap.power.components, key=lambda c: -c.watts) if c.watts > 0]
        colors = list(pal.series)
        flow_w = max(width - 22, 8)
        bar = Text()
        bar.append_text(stacked_bar([(c.watts, colors[i % len(colors)]) for i, c in enumerate(comps)], flow_w,
                                    pal.grid))
        bar.append(" ━▶ ", Style(color=pal.muted))
        bar.append(f"{fmt_money(cost.hourly_cost * 24, sym)}/day", Style(color=pal.primary, bold=True))
        lines.append(fit(bar, width))
        legend = Text()
        for i, c in enumerate(comps):
            name = c.name.split(":")[0].replace(" package", "").replace(" (board, fans)", "").split(" (")[0]
            name = {"Platform": "Board", "Extra devices": "Extra", "Memory": "RAM"}.get(name, name)
            if name.startswith("GPU"):
                name = "GPU" 
            legend.append("■", Style(color=colors[i % len(colors)]))
            legend.append(f"{name} {c.watts:.0f}{'' if c.method != 'measured' else '*'} ", Style(color=pal.text))
        lines.append(fit(legend, width))

        tips = [i for i in snap.insights if i.category in ("power", "cost") and i.recommendation]
        tail = Text()
        if tips:
            tail.append("◆ ", Style(color=pal.accent, bold=True))
            tail.append(tips[0].recommendation, Style(color=pal.text, italic=True))
            if tips[0].impact:
                tail.append(f"  {tips[0].impact}", Style(color=pal.ok, bold=True))
        elif snap.scores is not None:
            tail.append(f"Efficiency {snap.scores.power_efficiency}/100", Style(color=pal.muted))
            tail.append("  * = measured", Style(color=pal.muted))
        lines.append(fit(tail, width))
        return lines_group(lines, height)


# ================================================================== storage
class StorageCenter(DashPanel):
    TITLE = "STORAGE INTELLIGENCE"
    LINK = "storage"

    def update_titles(self, snap: Snapshot) -> None:
        total = sum(d.total for d in snap.disks)
        used = sum(d.used for d in snap.disks)
        self.border_subtitle = f"{fmt_bytes(used, 0)} / {fmt_bytes(total, 0)}"

    def render_panel(self, snap: Snapshot, width: int, height: int):
        pal = self.pal
        ctx = snap.context
        lines: list[Text] = []

        def urgency(d):
            fc = ctx.storage.get(d.mountpoint) if ctx else None
            days = fc.days_to_full if fc and fc.days_to_full is not None else 1e6
            return (days, -d.percent)

        mounts = sorted(snap.disks, key=urgency)
        drives = snap.storage_devices
        drive_rows = min(len(drives), max((height - 2) // 2, 1)) if drives else 0
        mount_rows = max(min(len(mounts), height - drive_rows - (1 if drives else 0)), 1)

        name_w = min(max(width // 4, 8), 14)
        bar_w = max(width - name_w - 31, 4)
        for d in mounts[:mount_rows]:
            fc = ctx.storage.get(d.mountpoint) if ctx else None
            c = pal.for_load(d.percent / 100)
            t = Text()
            t.append(f"{truncate(d.mountpoint, name_w):<{name_w}} ", Style(color=pal.text, bold=True))
            t.append_text(hbar(d.percent / 100, bar_w, c, pal.grid))
            t.append(f" {d.percent:3.0f}% ", Style(color=c, bold=True))
            t.append(f"{fmt_bytes(d.free, 0):>7} ", Style(color=pal.muted))
            if fc is None or fc.confidence == "insufficient data":
                t.append("learning", Style(color=pal.muted, italic=True))
            elif fc.days_to_full is None:
                t.append("stable", Style(color=pal.ok))
            else:
                days = fc.days_to_full
                fc_color = pal.crit if days < 14 else pal.warn if days < 60 else pal.text
                t.append(f"full {when_in(days)}", Style(color=fc_color, bold=days < 60))
            lines.append(fit(t, width))
        if len(mounts) > mount_rows:
            lines[-1] = fit(lines[-1], width)

        if drives:
            hdr = Text()
            hdr.append("DRIVES ", Style(color=pal.muted, bold=True))
            if not snap.smart and snap.smart_error:
                hdr.append(f"SMART {snap.smart_error}", Style(color=pal.muted, italic=True))
            else:
                worst = min((i.health_score for i in snap.smart.values() if not i.standby), default=None)
                if worst is not None:
                    hdr.append("worst health ", Style(color=pal.muted))
                    hdr.append(str(worst), Style(color=pal.for_score(worst), bold=True))
                spinning = sum(1 for i in snap.smart.values() if i.standby)
                if spinning:
                    hdr.append(f" · {spinning} in standby", Style(color=pal.muted))
            lines.append(fit(hdr, width))
            temps = {t.label or t.chip: t.current for t in snap.temps if t.kind == "drive"}
            io_by = {d.device: d for d in snap.disk_io}
            risk_order = {"critical": 0, "high": 1, "elevated": 2, "low": 3, "unknown": 4}

            def drive_key(dev):
                info = snap.smart.get(dev.name)
                return (risk_order.get(info.risk, 4) if info else 4, dev.name)

            for dev in sorted(drives, key=drive_key)[:drive_rows]:
                info = snap.smart.get(dev.name)
                io = io_by.get(dev.name)
                t = Text()
                if info is not None and not info.standby:
                    rc = {"low": pal.ok, "elevated": pal.warn, "high": pal.crit, "critical": pal.crit}.get(
                        info.risk, pal.muted)
                    t.append("● ", Style(color=rc, bold=True))
                elif info is not None and info.standby:
                    t.append("◌ ", Style(color=pal.muted))
                else:
                    t.append("○ ", Style(color=pal.muted))
                t.append(f"{dev.name:<8}", Style(color=pal.text, bold=True))
                t.append(f"{dev.kind.upper():<5}{fmt_bytes(dev.size_bytes, 0):>8} ", Style(color=pal.muted))
                if info is not None and not info.standby:
                    t.append(f"♥{info.health_score:<4}", Style(color=pal.for_score(info.health_score), bold=True))
                    temp = info.temperature_c
                    if temp is not None:
                        t.append(f"{temp:3.0f}° ", Style(color=pal.crit if temp >= 55 else pal.text))
                    if info.age_years is not None:
                        t.append(f"{info.age_years:3.1f}y ", Style(color=pal.muted))
                    if info.risk not in ("low", "unknown"):
                        t.append(info.risk, Style(color=pal.crit if info.risk in ("high", "critical")
                                                  else pal.warn, bold=True))
                    elif io is not None:
                        t.append(fmt_rate(io.total_bps), Style(color=pal.muted))
                elif info is not None and info.standby:
                    t.append("standby (spun down)", Style(color=pal.muted, italic=True))
                else:
                    temp = temps.get(dev.name)
                    if temp is not None:
                        t.append(f"{temp:3.0f}° ", Style(color=pal.text))
                    if io is not None:
                        t.append(fmt_rate(io.total_bps), Style(color=pal.muted))
                lines.append(fit(t, width))
        return lines_group(lines, height)


# =============================================================== containers
class DockerCenter(DashPanel):
    TITLE = "CONTAINERS"
    LINK = "docker"

    def update_titles(self, snap: Snapshot) -> None:
        if snap.docker_available:
            running = sum(1 for c in snap.containers if c.state == "running")
            self.border_subtitle = f"{running}/{len(snap.containers)} running"
        else:
            self.border_subtitle = "unavailable"

    def render_panel(self, snap: Snapshot, width: int, height: int):
        pal = self.pal
        if not snap.docker_available:
            lines = [fit(Text("Docker not reachable", Style(color=pal.warn, bold=True)), width)]
            for chunk in wrap_words(snap.docker_error or "Docker is not installed.", width)[: height - 1]:
                lines.append(self.muted(chunk))
            return lines_group(lines, height)
        cs = snap.containers
        running = [c for c in cs if c.state == "running"]
        healthy = sum(1 for c in cs if c.health == "healthy")
        unhealthy = [c for c in cs if c.health == "unhealthy" or c.state == "restarting"]
        stopped = [c for c in cs if c.state in ("exited", "dead", "created")]
        restarts = snap.context.restarts_today if snap.context else {}
        chips = Text()
        for value, name, color in ((len(running), "running", pal.primary), (healthy, "healthy", pal.ok),
                                   (len(unhealthy), "unhealthy", pal.crit if unhealthy else pal.muted),
                                   (len(stopped), "stopped", pal.muted),
                                   (sum(restarts.values()), "restarts", pal.warn if restarts else pal.muted)):
            chips.append(f" {value} ", Style(color=pal.on(color), bgcolor=color, bold=True))
            chips.append(f" {name} ", Style(color=color))
        lines: list[Text] = [fit(chips, width)]

        name_w = max(min(width - 34, 22), 8)
        hdr = Text(f"{'':2}{'NAME':<{name_w}} {'CPU':<10} {'MEM':>7} {'NET':>9} {'↻':>3}",
                   Style(color=pal.muted, bold=True))
        lines.append(fit(hdr, width))
        tail_rows = 1
        rows = max(height - len(lines) - tail_rows, 1)
        ordered = sorted(cs, key=lambda c: (c not in unhealthy, c.state != "running", -c.cpu_percent))
        for c in ordered[:rows]:
            bad = c in unhealthy
            dot_color = pal.crit if bad else pal.ok if c.health == "healthy" else pal.primary \
                if c.state == "running" else pal.muted
            t = Text()
            t.append("● " if c.state == "running" else "○ ", Style(color=dot_color, bold=True))
            t.append(f"{truncate(c.name, name_w):<{name_w}} ", Style(color=pal.text, bold=bad))
            if c.state == "running":
                t.append_text(hbar(min(c.cpu_percent / 100, 1.0), 5, pal.for_load(c.cpu_percent / 100), pal.grid))
                t.append(f"{c.cpu_percent:4.0f}% ", Style(color=pal.text))
                t.append(f"{fmt_bytes(c.mem_usage, 0):>7} ", Style(color=pal.text))
                t.append(f"{fmt_rate(c.net_rx_bps + c.net_tx_bps, 0):>9} ", Style(color=pal.muted))
            else:
                t.append(f"{c.status[:24]:<26}", Style(color=pal.muted, italic=True))
            n = restarts.get(c.name, 0)
            t.append(f"{n:>3}" if n else f"{'·':>3}", Style(color=pal.warn if n else pal.muted, bold=bool(n)))
            lines.append(fit(t, width))
        foot = Text()
        if restarts:
            foot.append("↻ ", Style(color=pal.warn, bold=True))
            foot.append(", ".join(f"{k} ×{v}" for k, v in sorted(restarts.items(), key=lambda kv: -kv[1])) +
                        " today", Style(color=pal.text))
        elif unhealthy:
            foot.append(f"✖ {unhealthy[0].name} failing its health check", Style(color=pal.crit))
        else:
            foot.append("✔ all containers stable today", Style(color=pal.ok))
        if len(lines) < height:
            lines.append(fit(foot, width))
        return lines_group(lines, height)


# ======================================================= services & media
class ServicesPanel(DashPanel):
    """systemd health plus the media stack (Plex, Jellyfin, *arr, qBittorrent)."""

    TITLE = "SERVICES & MEDIA"
    LINK = "media"
    HEALTH = {"healthy": "ok", "warning": "warn", "unhealthy": "crit", "down": "crit", "detected": "muted"}

    def update_titles(self, snap: Snapshot) -> None:
        streams = sum(len(a.streams) for a in snap.media.values())
        parts = []
        if snap.media:
            parts.append(f"{len(snap.media)} media apps")
        if streams:
            parts.append(f"{streams} streams")
        self.border_subtitle = " · ".join(parts) or "systemd"

    def render_panel(self, snap: Snapshot, width: int, height: int):
        pal = self.pal
        lines: list[Text] = []
        sv = snap.services
        t = Text()
        if sv is not None and sv.available:
            t.append("systemd ", Style(color=pal.muted, bold=True))
            t.append(f"● {sv.running} running", Style(color=pal.ok))
            if sv.failed:
                t.append(f"  ✖ {sv.failed_count} failed: ", Style(color=pal.crit, bold=True))
                t.append(", ".join(u.name for u in sv.failed[:3]), Style(color=pal.crit))
            else:
                t.append("  none failed", Style(color=pal.muted))
        else:
            t.append("systemd ", Style(color=pal.muted, bold=True))
            t.append(sv.error if sv is not None and sv.error else "checking…", Style(color=pal.muted, italic=True))
        lines.append(fit(t, width))
        if sv is not None and sv.reboot_required:
            r = Text()
            r.append("⟳ reboot required", Style(color=pal.warn, bold=True))
            if sv.reboot_packages:
                r.append(" for " + ", ".join(sv.reboot_packages[:3]), Style(color=pal.muted))
            lines.append(fit(r, width))

        if not snap.media:
            for chunk in wrap_words("No media services detected. Plex, Jellyfin, Radarr, Sonarr, Lidarr, Readarr "
                                    "and qBittorrent are found automatically.", width)[: height - len(lines)]:
                lines.append(self.muted(chunk))
            return lines_group(lines, height)

        growth = snap.context.media_library_growth if snap.context else {}
        unconfigured = 0
        for app in snap.media.values():
            if len(lines) >= height:
                break
            health = app.service_health
            color = getattr(pal, self.HEALTH.get(health, "muted"))
            t = Text()
            t.append("● ", Style(color=color, bold=True))
            t.append(f"{app.name:<12}", Style(color=pal.text, bold=True))
            if app.streams:
                tc = sum(1 for s in app.streams if s.transcode)
                t.append(f"▶ {len(app.streams)} stream{'s' if len(app.streams) != 1 else ''}",
                         Style(color=pal.accent, bold=True))
                if tc:
                    t.append(f" ({tc} transcode)", Style(color=pal.warn))
                t.append(" ")
            if app.download_bps is not None:
                t.append(f"↓{fmt_rate(app.download_bps, 0)} ↑{fmt_rate(app.upload_bps or 0, 0)} ", Style(color=pal.text))
                if app.active_torrents is not None:
                    t.append(f"{app.active_torrents} active ", Style(color=pal.muted))
            if app.queue_total:
                t.append(f"queue {app.queue_total} ", Style(color=pal.text))
            if app.health_issues:
                t.append("▲ issue ", Style(color=pal.warn))
            if app.library_bytes:
                t.append(f"{fmt_bytes(app.library_bytes, 1)}", Style(color=pal.muted))
                per_day = growth.get(app.key)
                if per_day and per_day > 0:
                    t.append(f" +{fmt_bytes(per_day, 0)}/d", Style(color=pal.muted))
            elif app.library_items and not app.streams:
                t.append(f"{app.library_items:,} items", Style(color=pal.muted))
            if t.cell_len <= 16:
                if not app.configured:
                    t.append(f"detected · add API key", Style(color=pal.muted, italic=True))
                    unconfigured += 1
                elif app.error:
                    t.append(app.error, Style(color=pal.crit))
                else:
                    t.append("idle", Style(color=pal.muted))
            lines.append(fit(t, width))
        streams = [(a, s) for a in snap.media.values() for s in a.streams]
        if streams and len(lines) < height - 1:
            lines.append(self.rule("NOW PLAYING", width))
            for app, st in streams[: height - len(lines)]:
                t = Text()
                t.append(" ⇄ " if st.transcode else " ▶ ", Style(color=pal.warn if st.transcode else pal.ok))
                t.append(f"{st.user}: ", Style(color=pal.muted))
                t.append(st.title, Style(color=pal.text))
                if st.transcode and st.hardware is False:
                    t.append(" (software)", Style(color=pal.warn))
                lines.append(fit(t, width))
        return lines_group(lines, height)


# =================================================================== radar
def pressures(snap: Snapshot, cfg_temp_crit: float = 95.0) -> list[tuple[str, float]]:
    cpu = max(snap.cpu.percent / 100, min(snap.load.per_core1 / 2, 1.0))
    ram = snap.memory.percent / 100
    if snap.swap.sout_bps > 1_000_000:
        ram = min(ram + 0.1, 1.0)
    hottest = snap.hottest()
    if hottest:
        limit = hottest.critical or cfg_temp_crit
        thermal = min(max((hottest.current - 30) / max(limit - 30, 1), 0.0), 1.0)
    else:
        thermal = 0.0
    storage = max([d.percent / 100 for d in snap.disks] + [io.util_percent / 100 for io in snap.disk_io] + [0.0])
    rx, tx = snap.net_totals()
    capacities = [n.speed_mbps * 125_000 for n in snap.net if not n.virtual and n.speed_mbps > 0 and n.is_up]
    if capacities:
        network = min(max(rx, tx) / max(capacities), 1.0)
    else:
        ctx = snap.context
        peak = 0.0
        if ctx is not None:
            peak = (ctx.metric("rx").peak_24h or 0) + (ctx.metric("tx").peak_24h or 0)
        network = min((rx + tx) / max(peak, 1_000_000), 1.0)
    return [("CPU", cpu), ("RAM", ram), ("HEAT", thermal), ("DISK", storage), ("NET", network)]


def baseline_pressures(snap: Snapshot) -> list[float] | None:
    ctx = snap.context
    if ctx is None:
        return None
    cpu = ctx.metric("cpu").avg_7d
    mem = ctx.metric("mem").avg_7d
    if cpu is None or mem is None:
        return None
    temp = ctx.metric("temp").avg_7d
    thermal = min(max(((temp or 30) - 30) / 65, 0.0), 1.0)
    storage = max([d.percent / 100 for d in snap.disks] + [0.0])
    rx = ctx.metric("rx").avg_7d or 0
    tx = ctx.metric("tx").avg_7d or 0
    peak = (ctx.metric("rx").peak_24h or 0) + (ctx.metric("tx").peak_24h or 0)
    network = min((rx + tx) / max(peak, 1_000_000), 1.0)
    return [cpu / 100, mem / 100, thermal, storage, network]


class RadarPanel(DashPanel):
    TITLE = "INFRASTRUCTURE RADAR"
    LINK = "analytics"

    def update_titles(self, snap: Snapshot) -> None:
        self.border_subtitle = "━ now ┄ 7-day" if snap.context else "━ now"

    def render_panel(self, snap: Snapshot, width: int, height: int):
        pal = self.pal
        axes = pressures(snap)
        worst = max(v for _l, v in axes)
        color = pal.for_load(worst)
        return radar_chart(axes, width, height, color, pal.grid, f"bold {pal.text}",
                           baseline=baseline_pressures(snap), baseline_color=pal.muted,
                           fill_color=gradient([pal.primary, color], 0.5))


# ================================================================= network
class NetworkCenter(DashPanel):
    TITLE = "NETWORK INTELLIGENCE"
    LINK = "network"

    def update_titles(self, snap: Snapshot) -> None:
        ctx = snap.context
        if ctx is not None and ctx.devices_active_24h:
            new = len(ctx.new_devices_24h)
            self.border_subtitle = f"{ctx.devices_active_24h} devices" + (f" · {new} new" if new else "")
        else:
            self.border_subtitle = "24 h ↓ above ↑ below"

    def render_panel(self, snap: Snapshot, width: int, height: int):
        pal = self.pal
        rx, tx = snap.net_totals()
        ctx = snap.context
        lines: list[Text] = []
        head = Text()
        head.append("↓ ", Style(color=pal.primary, bold=True))
        head.append(fmt_rate(rx), Style(color=pal.text, bold=True))
        head.append("  ↑ ", Style(color=pal.secondary, bold=True))
        head.append(fmt_rate(tx), Style(color=pal.text, bold=True))
        if ctx is not None and ctx.traffic_today_bytes is not None:
            head.append(f"   today {fmt_bytes(ctx.traffic_today_bytes, 0)}", Style(color=pal.muted))
            m_rx, m_tx = ctx.metric("rx"), ctx.metric("tx")
            if m_rx.avg_7d is not None:
                month = ((m_rx.avg_7d or 0) + (m_tx.avg_7d or 0)) * 86400 * 30
                head.append(f" · 30d ≈{fmt_bytes(month, 1)}", Style(color=pal.muted))
        lines.append(fit(head, width))

        r24 = ctx.metric("rx").series_24h if ctx else []
        t24 = ctx.metric("tx").series_24h if ctx else []
        if r24 and any(r24):
            down, up = list(r24), list(t24 or [0.0] * len(r24))
            down[-1], up[-1] = rx, tx
        else:
            down, up = self.obs.history.get("rx"), self.obs.history.get("tx")
        chart_rows = 4 if height >= 9 else 2
        lines.extend(mirror_area(down or [0.0], up or [0.0], width, chart_rows, pal.primary, pal.secondary)
                     .split("\n"))

        if ctx is not None and ctx.metric("rx").avg_24h is not None:
            m_rx, m_tx = ctx.metric("rx"), ctx.metric("tx")
            t = Text()
            t.append("24h ", Style(color=pal.muted, bold=True))
            t.append(f"avg ↓{fmt_rate(m_rx.avg_24h or 0, 0)} ↑{fmt_rate(m_tx.avg_24h or 0, 0)}", Style(color=pal.text))
            if m_rx.peak_24h is not None:
                t.append(f"  peak ↓{fmt_rate(m_rx.peak_24h, 0)}", Style(color=pal.muted))
                if m_rx.peak_24h_ts:
                    t.append(time.strftime(" @%H:%M", time.localtime(m_rx.peak_24h_ts)), Style(color=pal.muted))
            lines.append(fit(t, width))
        talkers = [(n.name, n.total_bps) for n in snap.net if not n.virtual and n.name != "lo"]
        talkers += [(f"▣{c.name}", c.net_rx_bps + c.net_tx_bps) for c in snap.containers if c.state == "running"]
        talkers = sorted([t for t in talkers if t[1] > 0], key=lambda t: -t[1])[:3]
        t = Text()
        t.append("TOP ", Style(color=pal.muted, bold=True))
        for name, bps in talkers or [("idle", 0.0)]:
            t.append(f"{name} ", Style(color=pal.text))
            if bps:
                t.append(f"{fmt_rate(bps, 0)}  ", Style(color=pal.muted))
        lines.append(fit(t, width))
        if snap.top_apps:
            t = Text()
            t.append("APPS ", Style(color=pal.muted, bold=True))
            for app in snap.top_apps[:3]:
                t.append(f"{app.name} ", Style(color=pal.text))
                t.append(f"{app.connections}c  ", Style(color=pal.muted))
            lines.append(fit(t, width))
        status = Text()
        anomalies = [a for a in snap.alerts if a.kind == "network_spike"]
        if anomalies:
            status.append("▲ " + anomalies[0].message, Style(color=pal.warn))
        elif ctx is not None and ctx.new_devices_24h:
            d = ctx.new_devices_24h[0]
            status.append("⇅ new device ", Style(color=pal.accent, bold=True))
            status.append(f"{d['ip']} ({d['mac']})", Style(color=pal.text))
        else:
            status.append("✔ no network anomalies", Style(color=pal.ok))
        errors = snap.net_error_rate
        if errors > 0:
            status.append(f"  {errors:.1f} err/s", Style(color=pal.warn))
        lines.append(fit(status, width))
        return lines_group(lines, height)


# ============================================================ what changed
class ChangesPanel(DashPanel):
    """The Change Journal: Observatory events, package upgrades and reboots."""

    TITLE = "WHAT CHANGED"
    LINK = "alerts"
    ICONS = {"alert_fired": ("▲", "warn"), "alert_resolved": ("✔", "ok"), "alert_escalated": ("▲", "crit"),
             "container_restart": ("↻", "warn"), "container_state": ("▣", "primary"),
             "container_created": ("+", "primary"), "container_removed": ("−", "muted"),
             "container_unhealthy": ("✖", "crit"), "config_changed": ("⚙", "primary"),
             "network_device_new": ("⇅", "accent"), "daemon_started": ("◉", "ok"), "tui_started": ("◉", "muted"),
             "process_signal": ("✖", "muted"), "container_restart_user": ("↻", "primary"),
             "package": ("⬆", "secondary"), "boot": ("⏻", "accent")}

    def entries(self, snap: Snapshot) -> list[tuple[float, str, str]]:
        items = [(e.ts, e.kind, e.message) for e in self.obs.recent_events]
        for group in snap.package_changes:
            items.append((group.ts, "package", group.message))
        boot = snap.ts - snap.uptime_s
        if snap.ts - boot < 7 * 86400:
            items.append((boot, "boot", "System booted"))
        items.sort(key=lambda x: -x[0])
        return items

    def update_titles(self, snap: Snapshot) -> None:
        n = sum(1 for ts, *_ in self.entries(snap) if snap.ts - ts < 86400)
        self.border_subtitle = f"{n} in 24 h"

    def render_panel(self, snap: Snapshot, width: int, height: int):
        pal = self.pal
        items = self.entries(snap)
        if not items:
            lines = [self.muted("No changes recorded yet.")]
            if self.obs.service.repo is None:
                lines.append(self.muted("History is disabled, so changes are not tracked.", italic=True))
            return lines_group(lines, height)
        lines: list[Text] = []
        for ts, kind, message in items[:height]:
            icon, tone = self.ICONS.get(kind, ("•", "muted"))
            color = getattr(pal, tone, pal.muted)
            t = Text()
            stamp = short_time(ts, snap.ts)
            t.append(f"{stamp:>9} ", Style(color=pal.muted))
            t.append(f"{icon} ", Style(color=color, bold=True))
            t.append(message, Style(color=pal.text))
            lines.append(fit(t, width))
        return lines_group(lines, height)


# ============================================================ 30-day outlook
class OutlookPanel(DashPanel):
    TITLE = "30-DAY OUTLOOK"
    LINK = "forecast"

    def update_titles(self, snap: Snapshot) -> None:
        e = snap.context.energy if snap.context else None
        self.border_subtitle = e.forecast_method.split(" (")[0] if e and e.forecast_method else "predictions"

    def render_panel(self, snap: Snapshot, width: int, height: int):
        pal = self.pal
        ctx = snap.context
        sym = snap.cost.currency_symbol
        lines: list[Text] = []

        def row(icon: str, label: str, value: str, value_color: str | None = None, note: str = "") -> None:
            t = Text()
            t.append(f"{icon} ", Style(color=pal.accent, bold=True))
            t.append(f"{label:<8}", Style(color=pal.muted, bold=True))
            t.append(value, Style(color=value_color or pal.text, bold=True))
            if note:
                t.append(f"  {note}", Style(color=pal.muted))
            lines.append(fit(t, width))

        if ctx is None:
            row("$", "Cost", fmt_money(snap.cost.monthly_estimate, sym), None, "this month at current draw")
            lines.append(self.muted("Forecasts sharpen as history accumulates.", italic=True))
            return lines_group(lines, height)
        e = ctx.energy
        if e.forecast_30d_cost is not None:
            row("$", "Cost", fmt_money(e.forecast_30d_cost, sym), pal.primary, f"{e.forecast_30d_kwh:.0f} kWh")
        else:
            row("$", "Cost", fmt_money(snap.cost.monthly_estimate, sym), pal.primary, "learning")
        fills = sorted((fc for fc in ctx.storage.values() if fc.days_to_full is not None),
                       key=lambda fc: fc.days_to_full)
        if fills:
            fc = fills[0]
            color = pal.crit if fc.days_to_full < 30 else pal.warn if fc.days_to_full < 90 else pal.text
            row("▤", "Storage", f"{fc.mountpoint} full {when_in(fc.days_to_full)}", color,
                f"{fc.days_to_full:.0f} d")
        elif ctx.storage:
            row("▤", "Storage", "no filesystem fills", pal.ok)
        else:
            row("▤", "Storage", "learning", pal.muted)
        for key, label, icon in (("mem", "Memory", "◇"), ("cpu", "CPU", "◆")):
            trend = ctx.trends.get(key)
            if trend is not None:
                proj = min(max(trend.projected_30d, 0), 100)
                color = pal.crit if proj > 95 else pal.warn if proj > 85 else pal.text
                row(icon, label, f"{trend.current:.0f}% → {proj:.0f}%", color, f"{trend.slope_per_day:+.1f}/day")
            else:
                row(icon, label, "learning", pal.muted, "needs 6 h")
        m_rx, m_tx = ctx.metric("rx"), ctx.metric("tx")
        if m_rx.avg_7d is not None:
            month = ((m_rx.avg_7d or 0) + (m_tx.avg_7d or 0)) * 86400 * 30
            row("⇅", "Traffic", fmt_bytes(month, 1))
        risky = [i for i in snap.smart.values() if i.risk in ("elevated", "high", "critical")]
        if risky:
            worst = min(risky, key=lambda i: i.health_score)
            row("♥", "Drives", f"{worst.device} {worst.risk} risk",
                pal.crit if worst.risk in ("high", "critical") else pal.warn, f"health {worst.health_score}")
        days = e.daily_kwh_14d
        if days and any(days) and len(lines) < height:
            t = Text()
            t.append("ϟ ", Style(color=pal.accent, bold=True))
            t.append(f"{'14d kWh':<8}", Style(color=pal.muted, bold=True))
            t.append_text(spark_blocks([d - min(days) * 0.8 for d in days], max(min(width - 22, 28), 6),
                                       pal.cool + (pal.accent,)))
            t.append(f" {sum(days) / len(days):.1f}/d", Style(color=pal.muted))
            lines.append(fit(t, width))
        return lines_group(lines, height)


# ============================================================ week heatmap
class HeatmapPanel(DashPanel):
    TITLE = "WEEK PATTERN · CPU"
    LINK = "analytics"

    def update_titles(self, snap: Snapshot) -> None:
        self.border_subtitle = "hour of day →"

    def render_panel(self, snap: Snapshot, width: int, height: int):
        pal = self.pal
        ctx = snap.context
        if ctx is None or not ctx.heatmap_cpu or not any(v is not None for row in ctx.heatmap_cpu for v in row):
            return Text("Hourly patterns appear after the first day of history.", Style(color=pal.muted, italic=True))
        rows = ctx.heatmap_cpu[-max(height - 1, 1):]
        labels = ctx.heatmap_days[-len(rows):]
        hour = time.localtime(snap.ts).tm_hour
        axis = "0     6     12    18   "
        return heatmap_grid(rows, labels, pal.heat, pal.grid, Style(color=pal.muted), max_value=100,
                            col_labels=axis if height > len(rows) else "",
                            highlight=(len(rows) - 1, hour), highlight_color=pal.accent)


# ===================================================== legacy compatibility
MediaPanel = ServicesPanel
ForecastPanel = OutlookPanel


class PulsePanel(DashPanel):
    """Standalone pulse (the header carries the pulse on the dashboard)."""

    TITLE = "SYSTEM PULSE"

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self.phase = 0

    def on_mount(self) -> None:
        self.set_interval(1 / 6, self._tick)

    def _tick(self) -> None:
        if self.obs.animations and self.display and self.snap is not None:
            self.phase += 1
            self.refresh()

    def render_panel(self, snap: Snapshot, width: int, height: int):
        pal = self.pal
        return pulse_wave(self.obs.history.get("activity"), self.phase, width, height,
                          [pal.secondary, pal.primary, pal.accent])


def iter_panels(widgets: Iterable[Widget]) -> list[DashPanel]:
    return [w for w in widgets if isinstance(w, DashPanel)]


__all__ = [
    "ChangesPanel", "DashPanel", "DockerCenter", "ForecastPanel", "HeaderBar", "HealthCenter", "HeatmapPanel",
    "InsightsPanel", "MediaPanel", "MetricTile", "NetworkCenter", "OutlookPanel", "PowerCenter", "PulsePanel",
    "RadarPanel", "ServicesPanel", "StorageCenter", "pressures",
]
