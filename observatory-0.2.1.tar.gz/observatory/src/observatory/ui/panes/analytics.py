"""Analytics: historical charts, energy and cost history, top consumers, forecasts."""

from __future__ import annotations

import time
from dataclasses import dataclass, field

from rich.text import Text
from textual import on, work
from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.widgets import DataTable, Select, Static

from observatory.engines.forecast import StorageForecast, TrendForecast, forecast_storage, forecast_trend
from observatory.models import Snapshot
from observatory.storage.repository import EnergyDay, SeriesStats
from observatory.ui.panes.base import Pane, refill_table
from observatory.ui.widgets import LabeledSparkline
from observatory.util.format import fmt_bytes, fmt_money, fmt_rate, fmt_watts, truncate

RANGES = [("Last hour", 3600), ("Last 6 hours", 6 * 3600), ("Last 24 hours", 86400),
          ("Last 7 days", 7 * 86400), ("Last 30 days", 30 * 86400)]
RELOAD_EVERY = 60.0
CHART_BINS = 120


def bin_series(points: list[tuple[float, float]], start: float, end: float, bins: int) -> list[float]:
    """Place points on a fixed time axis so a chart always spans the whole range.

    Bins without data are 0, so a short history shows as a bar at the right
    edge instead of being stretched across the full width.
    """
    if bins <= 0 or end <= start:
        return []
    sums = [0.0] * bins
    counts = [0] * bins
    width = (end - start) / bins
    for ts, value in points:
        index = int((ts - start) / width)
        if 0 <= index < bins:
            sums[index] += value
            counts[index] += 1
        elif index == bins:
            sums[-1] += value
            counts[-1] += 1
    return [s / c if c else 0.0 for s, c in zip(sums, counts)]

CHARTS = [
    ("cpu", "cpu.percent", "", "CPU %", lambda v: f"{v:.0f}%"),
    ("mem", "mem.percent", "", "Memory %", lambda v: f"{v:.0f}%"),
    ("power", "power.watts", "", "Power", fmt_watts),
    ("temp", "temp.max_c", "", "Hottest sensor", lambda v: f"{v:.0f}°C"),
    ("rx", "net.rx_bps", "_total", "Download", fmt_rate),
    ("tx", "net.tx_bps", "_total", "Upload", fmt_rate),
]


@dataclass
class AnalyticsData:
    span: int
    series: dict[str, list[float]] = field(default_factory=dict)
    stats: dict[str, SeriesStats] = field(default_factory=dict)
    energy: list[EnergyDay] = field(default_factory=list)
    top: list[dict] = field(default_factory=list)
    storage: list[StorageForecast] = field(default_factory=list)
    mem_trend: TrendForecast | None = None
    first_ts: float | None = None
    loaded_at: float = 0.0


class AnalyticsPane(Pane):
    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self.span = 86400
        self._data: AnalyticsData | None = None
        self._loaded_at = 0.0

    def compose(self) -> ComposeResult:
        with Horizontal(id="analytics-toolbar"):
            yield Select(RANGES, value=86400, allow_blank=False, id="range-select")
            yield Static(id="analytics-status", classes="status-line")
        with VerticalScroll(id="analytics-body"):
            with Horizontal(classes="chart-row"):
                for key, *_ in CHARTS[:3]:
                    yield LabeledSparkline(key, id=f"ch-{key}")
            with Horizontal(classes="chart-row"):
                for key, *_ in CHARTS[3:]:
                    yield LabeledSparkline(key, id=f"ch-{key}")
            with Horizontal(id="analytics-tables"):
                with Vertical(classes="panel"):
                    yield Static("Energy & cost by day", classes="panel-title")
                    yield DataTable(id="energy-table", cursor_type="row", zebra_stripes=True)
                with Vertical(classes="panel"):
                    yield Static("Top processes in range", classes="panel-title")
                    yield DataTable(id="top-table", cursor_type="row", zebra_stripes=True)
            yield Static("Forecasts", classes="panel-title")
            yield Static(id="forecast-text", classes="panel")

    def on_mount(self) -> None:
        energy = self.query_one("#energy-table", DataTable)
        for label, key, width in (("Day", "day", 12), ("kWh", "kwh", 8), ("Cost", "cost", 10),
                                  ("Avg W", "avgw", 8), ("Coverage", "cov", 9)):
            energy.add_column(label, key=key, width=width)
        top = self.query_one("#top-table", DataTable)
        for label, key, width in (("Process", "name", 22), ("Avg CPU %", "avg", 10), ("Peak CPU %", "max", 11),
                                  ("Peak RSS", "rss", 10)):
            top.add_column(label, key=key, width=width)

    @on(Select.Changed, "#range-select")
    def _range_changed(self, event: Select.Changed) -> None:
        self.span = int(event.value)
        self.reload()

    def on_show_pane(self) -> None:
        if time.monotonic() - self._loaded_at >= 5:
            self.reload()

    def update_snapshot(self, snap: Snapshot) -> None:
        if time.monotonic() - self._loaded_at >= RELOAD_EVERY:
            self.reload()
        if self._data is not None:
            self._render_forecasts(self._data, snap)

    def reload(self) -> None:
        self._loaded_at = time.monotonic()
        if self.service.repo is None:
            self.query_one("#analytics-status", Static).update(
                Text(self.service.storage_error or "History is disabled (view-only mode).", style=self.pal.warn))
            return
        self.query_one("#analytics-status", Static).update(Text("Loading history…", style=self.pal.muted))
        snap = self.obs_app.snapshot
        disks = [(d.mountpoint, float(d.total), float(d.used)) for d in (snap.disks if snap else [])]
        self._load(self.span, disks)

    @work(thread=True, exclusive=True, group="analytics-load")
    def _load(self, span: int, disks: list[tuple[str, float, float]]) -> None:
        repo = self.service.repo
        if repo is None:
            return
        now = time.time()
        start = now - span
        data = AnalyticsData(span=span)
        for key, metric, label, _title, _fmt in CHARTS:
            points = repo.series(metric, label, start, now, max_points=CHART_BINS)
            data.series[key] = bin_series([(p.ts, p.avg) for p in points], start, now, CHART_BINS)
            data.stats[key] = repo.stats(metric, label, start, now)
        data.energy = repo.energy_daily(14, now)
        data.top = repo.top_processes(start, now, 12)
        fullest = sorted(disks, key=lambda d: d[2] / d[1] if d[1] else 0, reverse=True)[:5]
        for mount, total, used in fullest:
            data.storage.append(forecast_storage(repo, mount, total, used, now=now))
        data.mem_trend = forecast_trend(repo, "mem.percent", "", 7, now)
        data.first_ts = repo.first_sample_ts()
        data.loaded_at = now
        self.app.call_from_thread(self._apply, data)

    def _apply(self, data: AnalyticsData) -> None:
        if data.span != self.span:
            return
        self._data = data
        for key, _metric, _label, title, fmt in CHARTS:
            st = data.stats.get(key)
            if st and st.count:
                caption = f"{title} · avg {fmt(st.avg)} · min {fmt(st.min)} · max {fmt(st.max)}"
            else:
                caption = f"{title} · no data in range"
            self.query_one(f"#ch-{key}", LabeledSparkline).set(data.series.get(key, []), caption)

        sym = self.service.cfg.cost.currency_symbol
        energy_rows = []
        for day in data.energy:
            if day.hours_covered <= 0:
                continue
            avg_w = day.kwh * 1000 / day.hours_covered if day.hours_covered else 0
            energy_rows.append((str(int(day.day_start)), (
                time.strftime("%a %b %d", time.localtime(day.day_start)),
                Text(f"{day.kwh:.2f}", justify="right"), Text(fmt_money(day.cost, sym), justify="right"),
                Text(f"{avg_w:.0f}", justify="right"), Text(f"{min(day.hours_covered / 24 * 100, 100):.0f}%",
                                                            justify="right"),
            )))
        refill_table(self.query_one("#energy-table", DataTable), energy_rows)

        top_rows = [(f"{i}:{t['name']}", (
            truncate(t["name"], 22), Text(f"{t['avg_cpu']:.1f}", justify="right"),
            Text(f"{t['max_cpu']:.1f}", justify="right"), Text(fmt_bytes(t["max_rss"]), justify="right"),
        )) for i, t in enumerate(data.top)]
        refill_table(self.query_one("#top-table", DataTable), top_rows)

        since = time.strftime("%Y-%m-%d %H:%M", time.localtime(data.first_ts)) if data.first_ts else "—"
        mode = "recording" if self.service.recording else "daemon is recording"
        self.query_one("#analytics-status", Static).update(
            Text(f"History since {since} · {mode} · database {fmt_bytes(self.service.db.size_bytes()) if self.service.db else '—'}",
                 style=self.pal.muted))
        snap = self.obs_app.snapshot
        if snap is not None:
            self._render_forecasts(data, snap)

    def _render_forecasts(self, data: AnalyticsData, snap: Snapshot) -> None:
        cost = snap.cost
        sym = cost.currency_symbol
        text = Text()
        text.append("Power cost  ", style="bold")
        text.append(f"this month ≈ {fmt_money(cost.monthly_estimate, sym)} "
                    f"({cost.monthly_kwh_estimate:.0f} kWh) · year ≈ {fmt_money(cost.annual_estimate, sym)} · "
                    f"month to date {fmt_money(cost.month_to_date_cost, sym)} · based on "
                    f"{cost.average_watts:.0f} W average at {fmt_money(cost.rate_per_kwh, sym, 3)}/kWh\n")
        text.append("Storage     ", style="bold")
        if not data.storage:
            text.append("no filesystems\n", style=self.pal.muted)
        else:
            parts = []
            for fc in data.storage:
                if fc.days_to_full is not None:
                    style = {"critical": f"bold {self.pal.crit}", "warning": self.pal.warn}.get(fc.status, "")
                    parts.append((f"{fc.mountpoint} full in {fc.days_to_full:.0f} d ({fc.confidence})", style))
                elif fc.confidence == "insufficient data":
                    parts.append((f"{fc.mountpoint} collecting data", self.pal.muted))
                else:
                    parts.append((f"{fc.mountpoint} stable", self.pal.ok))
            for i, (part, style) in enumerate(parts):
                text.append(part, style=style)
                text.append(" · " if i < len(parts) - 1 else "\n")
        text.append("Memory      ", style="bold")
        trend = data.mem_trend
        if trend is None:
            text.append("needs at least 6 hours of history\n", style=self.pal.muted)
        else:
            direction = "rising" if trend.slope_per_day > 0.5 else "falling" if trend.slope_per_day < -0.5 else "flat"
            text.append(f"{direction} {trend.slope_per_day:+.1f} pts/day · projected "
                        f"{min(max(trend.projected_7d, 0), 100):.0f}% in 7 d, "
                        f"{min(max(trend.projected_30d, 0), 100):.0f}% in 30 d\n")
        self.query_one("#forecast-text", Static).update(text)
