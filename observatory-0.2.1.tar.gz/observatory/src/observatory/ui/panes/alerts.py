"""Alerts: active alerts, alert history and the event log."""

from __future__ import annotations

import time

from rich.text import Text
from textual import on, work
from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.widgets import DataTable, Static

from observatory.models import Alert, Snapshot
from observatory.storage.repository import EventRecord
from observatory.ui.panes.base import Pane, refill_table, selected_row_key
from observatory.util.format import fmt_duration, fmt_ts, truncate

def sev_style(pal, severity: str) -> str:
    return {"critical": f"bold {pal.crit}", "warning": pal.warn, "info": pal.info}.get(severity, "")
RELOAD_EVERY = 10.0


class AlertsPane(Pane):
    BINDINGS = [
        Binding("enter", "ack", "Acknowledge"),
        Binding("e", "ack_all", "Ack all"),
        Binding("x", "clear_resolved", "Clear resolved"),
    ]

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self._loaded_at = 0.0
        self._history: list[Alert] = []
        self._events: list[EventRecord] = []

    def compose(self) -> ComposeResult:
        yield Static(id="alerts-status", classes="status-line")
        yield Static("Active alerts", classes="panel-title")
        yield DataTable(id="active-table", cursor_type="row", zebra_stripes=True)
        with Horizontal(id="alerts-lower"):
            with Vertical(classes="panel"):
                yield Static("Alert history", classes="panel-title")
                yield DataTable(id="history-table", cursor_type="row", zebra_stripes=True)
            with Vertical(classes="panel"):
                yield Static("Event log", classes="panel-title")
                yield DataTable(id="events-table", cursor_type="row", zebra_stripes=True)

    def on_mount(self) -> None:
        active = self.query_one("#active-table", DataTable)
        for label, key, width in (("Severity", "sev", 9), ("Type", "kind", 14), ("Subject", "subj", 20),
                                  ("For", "for", 9), ("Ack", "ack", 4), ("Message", "msg", None)):
            active.add_column(label, key=key, width=width)
        history = self.query_one("#history-table", DataTable)
        for label, key, width in (("Started", "start", 19), ("Sev", "sev", 8), ("Type", "kind", 13),
                                  ("State", "state", 9), ("Duration", "dur", 9), ("Message", "msg", None)):
            history.add_column(label, key=key, width=width)
        events = self.query_one("#events-table", DataTable)
        for label, key, width in (("Time", "ts", 19), ("Sev", "sev", 8), ("Kind", "kind", 18),
                                  ("Message", "msg", None)):
            events.add_column(label, key=key, width=width)

    def on_show_pane(self) -> None:
        self._reload()

    @work(thread=True, exclusive=True, group="alerts-load")
    def _reload_worker(self) -> None:
        history = self.service.alerts_history(300)
        events = self.service.repo.events(300) if self.service.repo is not None else []
        self.app.call_from_thread(self._apply_history, history, events)

    def _reload(self) -> None:
        self._loaded_at = time.monotonic()
        self._reload_worker()

    def _apply_history(self, history: list[Alert], events: list[EventRecord]) -> None:
        self._history = history
        self._events = events
        now = time.time()
        rows = []
        for a in history:
            end = a.ended_at or now
            rows.append((str(a.id), (
                fmt_ts(a.started_at), Text(a.severity, style=sev_style(self.pal, a.severity)), a.kind,
                Text(a.state, style="bold" if a.state == "active" else self.pal.muted), fmt_duration(end - a.started_at),
                truncate(a.message, 200),
            )))
        refill_table(self.query_one("#history-table", DataTable), rows)
        ev_rows = [(str(e.id), (
            fmt_ts(e.ts), Text(e.severity, style=sev_style(self.pal, e.severity)), e.kind, truncate(e.message, 200),
        )) for e in events]
        refill_table(self.query_one("#events-table", DataTable), ev_rows)

    def update_snapshot(self, snap: Snapshot) -> None:
        if time.monotonic() - self._loaded_at >= RELOAD_EVERY or snap.new_alerts:
            self._reload()
        now = time.time()
        alerts = sorted(snap.alerts, key=lambda a: (a.severity != "critical", -a.started_at))
        rows = []
        for a in alerts:
            key = str(a.id) if a.id is not None else f"{a.kind}:{a.subject}"
            rows.append((key, (
                Text(a.severity.upper(), style=sev_style(self.pal, a.severity)), a.kind, truncate(a.subject, 20),
                fmt_duration(now - a.started_at), "✓" if a.acknowledged else "", truncate(a.message, 200),
            )))
        refill_table(self.query_one("#active-table", DataTable), rows)
        crit = sum(1 for a in alerts if a.severity == "critical")
        warn = sum(1 for a in alerts if a.severity == "warning")
        status = Text()
        status.append(f"{crit} critical", style=f"bold {self.pal.crit}" if crit else self.pal.muted)
        status.append(" · ")
        status.append(f"{warn} warning", style=self.pal.warn if warn else self.pal.muted)
        enabled = self.service.cfg.alerts.enabled
        status.append(f" · detection {'on' if enabled else 'OFF'}", style="" if enabled else f"bold {self.pal.warn}")
        status.append("   enter acknowledge · e acknowledge all · x clear resolved", style=self.pal.muted)
        self.query_one("#alerts-status", Static).update(status)

    # ------------------------------------------------------------------ actions
    @on(DataTable.RowSelected, "#active-table")
    def _row_selected(self, _event: DataTable.RowSelected) -> None:
        self.action_ack()

    def action_ack(self) -> None:
        key = selected_row_key(self.query_one("#active-table", DataTable))
        if not key or not key.isdigit():
            self.app.notify("Select a recorded alert to acknowledge.", severity="warning")
            return
        self.service.acknowledge(int(key))
        self.app.notify("Alert acknowledged.")
        self._refresh_now()

    def action_ack_all(self) -> None:
        for alert in self.service.anomaly.manager.active.values():
            alert.acknowledged = True
        if self.service.repo is not None:
            self.service.repo.acknowledge_all()
        self.app.notify("All alerts acknowledged.")
        self._refresh_now()

    def action_clear_resolved(self) -> None:
        if self.service.repo is None:
            return
        removed = self.service.repo.clear_resolved()
        self.app.notify(f"Removed {removed} resolved alert(s) from history.")
        self._reload()

    def _refresh_now(self) -> None:
        snap = self.obs_app.snapshot
        if snap is not None:
            self.update_snapshot(snap)
        self._reload()
