"""Network: per-interface throughput, totals, errors and TCP connection states."""

from __future__ import annotations

import time

from rich.text import Text
from textual import work
from textual.app import ComposeResult
from textual.containers import Horizontal
from textual.widgets import DataTable, Static

from observatory.collectors.network import connection_summary
from observatory.models import Snapshot
from observatory.ui.panes.base import Pane, refill_table
from observatory.ui.widgets import LabeledSparkline
from observatory.util.format import fmt_bits, fmt_bytes, fmt_rate, truncate

CONN_EVERY = 10.0


class NetworkPane(Pane):
    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self._conn_at = 0.0
        self._conns: dict[str, int] = {}
        self.show_virtual = True

    def compose(self) -> ComposeResult:
        with Horizontal(id="net-sparks"):
            yield LabeledSparkline("Download", id="sp-rx")
            yield LabeledSparkline("Upload", id="sp-tx")
        yield Static("Interfaces", classes="panel-title")
        yield DataTable(id="net-table", cursor_type="row", zebra_stripes=True)
        yield Static(id="net-conns", classes="status-line")

    def on_mount(self) -> None:
        table = self.query_one("#net-table", DataTable)
        for label, key, width in (("Interface", "if", 14), ("State", "state", 6), ("Type", "type", 8),
                                  ("Speed", "speed", 9), ("RX/s", "rx", 11), ("TX/s", "tx", 11),
                                  ("RX total", "rxt", 10), ("TX total", "txt", 10), ("Err", "err", 6),
                                  ("Drop", "drop", 6), ("Addresses", "addr", None)):
            table.add_column(label, key=key, width=width)

    @work(thread=True, exclusive=True, group="net-conns")
    def _refresh_conns(self) -> None:
        conns = connection_summary()
        self.app.call_from_thread(self._set_conns, conns)

    def _set_conns(self, conns: dict[str, int]) -> None:
        self._conns = conns

    def update_snapshot(self, snap: Snapshot) -> None:
        if time.monotonic() - self._conn_at >= CONN_EVERY:
            self._conn_at = time.monotonic()
            self._refresh_conns()
        rx, tx = snap.net_totals()
        hist = self.obs_app.history
        rx_hist, tx_hist = hist.get("rx"), hist.get("tx")
        self.query_one("#sp-rx", LabeledSparkline).set(
            rx_hist, f"Download {fmt_rate(rx)} ({fmt_bits(rx)}) · peak {fmt_rate(max(rx_hist, default=0))}")
        self.query_one("#sp-tx", LabeledSparkline).set(
            tx_hist, f"Upload {fmt_rate(tx)} ({fmt_bits(tx)}) · peak {fmt_rate(max(tx_hist, default=0))}")

        rows = []
        for n in snap.net:
            state = Text("up", style=self.pal.ok) if n.is_up else Text("down", style=self.pal.muted)
            err_style = self.pal.crit if n.errors else ""
            rows.append((n.name, (
                n.name, state, Text("virtual" if n.virtual else "physical", style=self.pal.muted if n.virtual else ""),
                f"{n.speed_mbps} Mb/s" if n.speed_mbps else "—",
                Text(fmt_rate(n.rx_bps), justify="right"), Text(fmt_rate(n.tx_bps), justify="right"),
                Text(fmt_bytes(n.rx_total), justify="right"), Text(fmt_bytes(n.tx_total), justify="right"),
                Text(str(n.errors), style=err_style, justify="right"), Text(str(n.drops), justify="right"),
                truncate(", ".join(n.addresses), 60),
            )))
        refill_table(self.query_one("#net-table", DataTable), rows)

        line = Text()
        line.append("TCP connections: ", style="bold")
        if self._conns:
            total = sum(self._conns.values())
            line.append(f"{total} total  ")
            for state, count in sorted(self._conns.items(), key=lambda kv: -kv[1])[:6]:
                line.append(f"{state.lower()} {count}  ", style=self.pal.muted)
        else:
            line.append("unavailable (run as root to see all sockets)", style=self.pal.muted)
        self.query_one("#net-conns", Static).update(line)
