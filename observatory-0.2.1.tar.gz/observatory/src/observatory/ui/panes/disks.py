"""Disks: filesystem usage, per-device I/O, storage inventory and fill forecasts."""

from __future__ import annotations

import time

from rich.text import Text
from textual import work
from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical
from textual.widgets import DataTable, Static

from observatory.engines.forecast import StorageForecast, forecast_storage
from observatory.models import Snapshot
from observatory.ui.panes.base import Pane, refill_table
from observatory.util.format import bar_text, fmt_bytes, fmt_rate, level_style, truncate

FORECAST_EVERY = 120.0


class DisksPane(Pane):
    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self._forecasts: dict[str, StorageForecast] = {}
        self._forecast_at = 0.0

    def compose(self) -> ComposeResult:
        yield Static("Filesystems", classes="panel-title")
        yield DataTable(id="fs-table", cursor_type="row", zebra_stripes=True)
        with Horizontal(id="disk-lower"):
            with Vertical(classes="panel"):
                yield Static("Block device I/O", classes="panel-title")
                yield DataTable(id="io-table", cursor_type="row", zebra_stripes=True)
            with Vertical(classes="panel", id="smart-panel"):
                yield Static("Drive health (SMART)", classes="panel-title")
                yield DataTable(id="dev-table", cursor_type="row", zebra_stripes=True)
        yield Static(id="disk-temps", classes="status-line")

    def on_mount(self) -> None:
        fs = self.query_one("#fs-table", DataTable)
        for label, key, width in (("Mount", "mount", 22), ("Device", "dev", 22), ("FS", "fs", 8),
                                  ("Size", "size", 10), ("Used", "used", 10), ("Free", "free", 10),
                                  ("Use", "pct", 28), ("Forecast", "forecast", None)):
            fs.add_column(label, key=key, width=width)
        io = self.query_one("#io-table", DataTable)
        for label, key, width in (("Device", "dev", 14), ("Read/s", "r", 11), ("Write/s", "w", 11),
                                  ("IOPS", "iops", 7), ("Util", "util", 18)):
            io.add_column(label, key=key, width=width)
        dev = self.query_one("#dev-table", DataTable)
        for label, key, width in (("Drive", "name", 9), ("Type", "type", 5), ("Size", "size", 9),
                                  ("SMART", "smart", 8), ("Health", "health", 6), ("Risk", "risk", 9),
                                  ("Temp", "temp", 5), ("Age", "age", 6), ("Realloc", "re", 7),
                                  ("Pending", "pend", 7), ("Wear", "wear", 5), ("Model / why", "model", None)):
            dev.add_column(label, key=key, width=width)

    def on_show_pane(self) -> None:
        self._forecast_at = 0.0

    @work(thread=True, exclusive=True, group="disk-forecast")
    def _refresh_forecasts(self, disks: list[tuple[str, float, float]]) -> None:
        repo = self.service.repo
        if repo is None:
            return
        results = {}
        for mount, total, used in disks:
            try:
                results[mount] = forecast_storage(repo, mount, total, used)
            except Exception:
                continue
        self.app.call_from_thread(self._set_forecasts, results)

    def _set_forecasts(self, results: dict[str, StorageForecast]) -> None:
        self._forecasts = results
        snap = self.obs_app.snapshot
        if snap is not None:
            self.update_snapshot(snap)

    def _forecast_text(self, fc: StorageForecast | None) -> Text:
        if fc is None:
            return Text("—", style=self.pal.muted)
        if fc.days_to_full is None:
            if fc.confidence == "insufficient data":
                return Text("collecting data", style=self.pal.muted)
            return Text(f"stable ({fmt_bytes(fc.growth_bytes_per_day)}/day)", style=self.pal.ok)
        style = {"critical": f"bold {self.pal.crit}", "warning": self.pal.warn}.get(fc.status, "")
        days = fc.days_to_full
        when = f"{days:.0f} days" if days < 3650 else ">10 years"
        return Text(f"full in {when} (+{fmt_bytes(fc.growth_bytes_per_day)}/day, {fc.confidence})", style=style)

    def update_snapshot(self, snap: Snapshot) -> None:
        if time.monotonic() - self._forecast_at >= FORECAST_EVERY and self.service.repo is not None:
            self._forecast_at = time.monotonic()
            self._refresh_forecasts([(d.mountpoint, float(d.total), float(d.used)) for d in snap.disks])

        fs_rows = []
        for d in snap.disks:
            usage = bar_text(d.percent, 16, level_style(d.percent, 80, 90, self.pal), pal=self.pal)
            usage.append(f" {d.percent:5.1f}%")
            fs_rows.append((d.mountpoint, (
                truncate(d.mountpoint, 22), truncate(d.device, 22), d.fstype,
                Text(fmt_bytes(d.total), justify="right"), Text(fmt_bytes(d.used), justify="right"),
                Text(fmt_bytes(d.free), justify="right"), usage,
                self._forecast_text(self._forecasts.get(d.mountpoint) or
                                    (snap.context.storage.get(d.mountpoint) if snap.context else None)),
            )))
        refill_table(self.query_one("#fs-table", DataTable), fs_rows)

        io_rows = []
        for io in snap.disk_io:
            util = bar_text(io.util_percent, 10, level_style(io.util_percent, 60, 90, self.pal), pal=self.pal)
            util.append(f" {io.util_percent:5.1f}%")
            io_rows.append((io.device, (
                io.device, Text(fmt_rate(io.read_bps), justify="right"), Text(fmt_rate(io.write_bps), justify="right"),
                Text(f"{io.read_iops + io.write_iops:.0f}", justify="right"), util,
            )))
        refill_table(self.query_one("#io-table", DataTable), io_rows)

        kind_style = {"hdd": self.pal.warn, "ssd": self.pal.primary, "nvme": self.pal.secondary, "usb": self.pal.info}
        risk_style = {"low": self.pal.ok, "elevated": self.pal.warn, "high": f"bold {self.pal.crit}", "critical": f"bold {self.pal.crit}"}
        dev_rows = []
        for d in snap.storage_devices:
            info = snap.smart.get(d.name) if snap.smart else None
            dash = Text("—", style=self.pal.muted, justify="right")
            if info is None or info.standby:
                status = Text("standby" if info else "n/a", style=self.pal.muted)
                cells = [dash] * 7
                why = truncate(d.model or "—", 60)
            else:
                status = Text(info.status, style=self.pal.ok if info.status == "PASSED" else f"bold {self.pal.crit}")
                score_style = self.pal.ok if info.health_score >= 90 else self.pal.warn if info.health_score >= 60 else f"bold {self.pal.crit}"
                cells = [
                    Text(str(info.health_score), style=score_style, justify="right"),
                    Text(info.risk, style=risk_style.get(info.risk, self.pal.muted)),
                    Text(f"{info.temperature_c:.0f}°" if info.temperature_c is not None else "—", justify="right"),
                    Text(f"{info.age_years:.1f}y" if info.age_years is not None else "—", justify="right"),
                    Text(str(info.reallocated), style=self.pal.warn if info.reallocated else "", justify="right"),
                    Text(str(info.pending), style=f"bold {self.pal.crit}" if info.pending else "", justify="right"),
                    Text(f"{info.nvme_percentage_used}%" if info.nvme_percentage_used is not None else "—",
                         justify="right"),
                ]
                why = "; ".join(info.reasons[:2]) or (d.model or info.model or "—")
            dev_rows.append((d.name, (d.name, Text(d.kind.upper(), style=kind_style.get(d.kind, self.pal.muted)),
                                      Text(fmt_bytes(d.size_bytes, 0), justify="right"), status, *cells,
                                      truncate(why, 80))))
        refill_table(self.query_one("#dev-table", DataTable), dev_rows)

        drive_temps = [t for t in snap.temps if t.kind == "drive"]
        line = Text()
        line.append("Drive temperatures: ", style="bold")
        if drive_temps:
            for t in drive_temps:
                style = self.pal.crit if t.current >= self.service.cfg.alerts.drive_temp_warning_c else self.pal.ok
                line.append(f"{t.name} {t.current:.0f}°C  ", style=style)
        else:
            line.append("none reported (load the 'drivetemp' kernel module for SATA drives)", style=self.pal.muted)
        if snap.smart_error and not snap.smart:
            line.append(f"   ·  SMART: {snap.smart_error}", style=self.pal.muted)
        if self.service.repo is None and snap.context is None:
            line.append("   ·  history disabled, forecasts unavailable", style=self.pal.muted)
        self.query_one("#disk-temps", Static).update(line)
