"""Processes: searchable, filterable, sortable process table with kill controls."""

from __future__ import annotations

import getpass

from rich.text import Text
from textual import on, work
from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal
from textual.widgets import DataTable, Input, Select, Static

from observatory.collectors.processes import is_kernel_thread
from observatory.models import ProcessInfo, Snapshot
from observatory.ui.panes.base import Pane, refill_table, selected_row_key
from observatory.ui.widgets import ConfirmScreen
from observatory.util.format import fmt_bytes, truncate

FILTERS = [
    ("All processes", "all"),
    ("My processes", "mine"),
    ("Running only", "running"),
    ("High CPU (>5%)", "cpu"),
    ("High memory (>1%)", "mem"),
    ("Hide kernel threads", "nokernel"),
]
SORTS = {
    "cpu": ("CPU %", lambda p: (p.cpu_percent, p.rss), True),
    "mem": ("Memory", lambda p: (p.rss, p.cpu_percent), True),
    "pid": ("PID", lambda p: p.pid, False),
    "name": ("Name", lambda p: p.name.lower(), False),
}


def filter_processes(procs: list[ProcessInfo], query: str, mode: str, me: str) -> list[ProcessInfo]:
    q = query.strip().lower()
    out = []
    for p in procs:
        if mode == "mine" and p.username != me:
            continue
        if mode == "running" and p.status != "running":
            continue
        if mode == "cpu" and p.cpu_percent <= 5:
            continue
        if mode == "mem" and p.memory_percent <= 1:
            continue
        if mode == "nokernel" and is_kernel_thread(p):
            continue
        if q:
            haystack = f"{p.pid} {p.name} {p.username} {p.cmdline}".lower()
            if q.isdigit():
                if str(p.pid) != q and q not in haystack:
                    continue
            elif q not in haystack:
                continue
        out.append(p)
    return out


def sort_processes(procs: list[ProcessInfo], key: str) -> list[ProcessInfo]:
    _label, fn, reverse = SORTS.get(key, SORTS["cpu"])
    return sorted(procs, key=fn, reverse=reverse)


class ProcessesPane(Pane):
    BINDINGS = [
        Binding("slash", "focus_search", "Search"),
        Binding("escape", "clear_search", "Clear search", show=False),
        Binding("c", "sort('cpu')", "Sort CPU"),
        Binding("r", "sort('mem')", "Sort RAM"),
        Binding("o", "cycle_sort", "Cycle sort"),
        Binding("k", "kill(False)", "Terminate"),
        Binding("K", "kill(True)", "Kill -9"),
    ]

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self.sort_key = "cpu"
        self.filter_mode = "all"
        self.query_text = ""
        self.me = getpass.getuser()
        self._procs: dict[str, ProcessInfo] = {}

    def compose(self) -> ComposeResult:
        with Horizontal(id="proc-toolbar"):
            yield Input(placeholder="Search name, user, PID or command  ( / )", id="proc-search")
            yield Select(FILTERS, value="all", allow_blank=False, id="proc-filter")
        yield Static(id="proc-status", classes="status-line")
        table = DataTable(id="proc-table", cursor_type="row", zebra_stripes=True)
        yield table
        yield Static(id="proc-detail", classes="detail-line")

    def on_mount(self) -> None:
        table = self.query_one("#proc-table", DataTable)
        table.add_column("PID", key="pid", width=8)
        table.add_column("Name", key="name", width=22)
        table.add_column("User", key="user", width=12)
        table.add_column("CPU %", key="cpu", width=7)
        table.add_column("MEM %", key="memp", width=7)
        table.add_column("RSS", key="rss", width=10)
        table.add_column("Thr", key="thr", width=5)
        table.add_column("State", key="state", width=9)
        table.add_column("Command", key="cmd")

    # ----------------------------------------------------------------- events
    @on(Input.Changed, "#proc-search")
    def _search_changed(self, event: Input.Changed) -> None:
        self.query_text = event.value
        self._rerender()

    @on(Select.Changed, "#proc-filter")
    def _filter_changed(self, event: Select.Changed) -> None:
        self.filter_mode = str(event.value)
        self._rerender()

    @on(DataTable.RowHighlighted, "#proc-table")
    def _row_highlighted(self, event: DataTable.RowHighlighted) -> None:
        self._show_detail(event.row_key.value if event.row_key else None)

    def _show_detail(self, key: str | None) -> None:
        proc = self._procs.get(key or "")
        detail = self.query_one("#proc-detail", Static)
        if proc is None:
            detail.update("")
            return
        detail.update(Text.assemble(("PID ", "bold"), str(proc.pid), ("  cmd ", "bold"), truncate(proc.cmdline, 400)))

    # ---------------------------------------------------------------- actions
    def action_focus_search(self) -> None:
        self.query_one("#proc-search", Input).focus()

    def action_clear_search(self) -> None:
        search = self.query_one("#proc-search", Input)
        search.value = ""
        self.query_one("#proc-table", DataTable).focus()

    def action_cycle_sort(self) -> None:
        order = list(SORTS)
        self.action_sort(order[(order.index(self.sort_key) + 1) % len(order)])

    def action_sort(self, key: str) -> None:
        self.sort_key = key
        self._rerender()

    def action_kill(self, force: bool) -> None:
        key = selected_row_key(self.query_one("#proc-table", DataTable))
        proc = self._procs.get(key or "")
        if proc is None:
            self.app.notify("Select a process first.", severity="warning")
            return
        signal_name = "SIGKILL (force)" if force else "SIGTERM"

        def done(confirmed: bool | None) -> None:
            if confirmed:
                self._do_kill(proc.pid, force)

        if self.service.cfg.ui.confirm_actions:
            self.app.push_screen(
                ConfirmScreen("Kill process?" if force else "Terminate process?",
                              f"Send {signal_name} to {proc.name} (PID {proc.pid}, user {proc.username or '?'})?\n\n"
                              f"{truncate(proc.cmdline, 200)}",
                              "Kill" if force else "Terminate"),
                done,
            )
        else:
            self._do_kill(proc.pid, force)

    @work(thread=True, group="proc-kill")
    def _do_kill(self, pid: int, force: bool) -> None:
        ok, message = self.service.kill(pid, force)
        self.app.call_from_thread(self.app.notify, message, severity="information" if ok else "error")

    # ---------------------------------------------------------------- render
    def update_snapshot(self, snap: Snapshot) -> None:
        self._snapshot = snap
        self._rerender()

    def _rerender(self) -> None:
        snap: Snapshot | None = getattr(self, "_snapshot", None)
        if snap is None:
            return
        procs = sort_processes(filter_processes(snap.processes, self.query_text, self.filter_mode, self.me),
                               self.sort_key)
        self._procs = {str(p.pid): p for p in procs}
        rows = []
        for p in procs:
            cpu_style = f"bold {self.pal.crit}" if p.cpu_percent >= 80 else self.pal.warn if p.cpu_percent >= 20 else ""
            mem_style = f"bold {self.pal.crit}" if p.memory_percent >= 30 else self.pal.warn if p.memory_percent >= 10 else ""
            rows.append((str(p.pid), (
                Text(str(p.pid), justify="right"),
                truncate(p.name, 22),
                truncate(p.username, 12),
                Text(f"{p.cpu_percent:.1f}", style=cpu_style, justify="right"),
                Text(f"{p.memory_percent:.1f}", style=mem_style, justify="right"),
                Text(fmt_bytes(p.rss), justify="right"),
                Text(str(p.threads), justify="right"),
                p.status,
                truncate(p.cmdline, 200),
            )))
        table = self.query_one("#proc-table", DataTable)
        refill_table(table, rows)
        label = SORTS[self.sort_key][0]
        shown = len(procs)
        listed = len(snap.processes)
        note = f" (top {listed} of {snap.process_count} collected)" if listed < snap.process_count else ""
        self.query_one("#proc-status", Static).update(
            f"{shown} shown · {snap.process_count} processes{note} · sorted by {label} · "
            "c CPU · r RAM · o cycle sort · k terminate · K kill"
        )
        self._show_detail(selected_row_key(table))
