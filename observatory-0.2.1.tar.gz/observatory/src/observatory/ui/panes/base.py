"""Base class shared by every section of the UI."""

from __future__ import annotations

from typing import TYPE_CHECKING

from textual.containers import Vertical
from textual.widgets import DataTable

from observatory.models import Snapshot

if TYPE_CHECKING:  # pragma: no cover
    from observatory.services.monitor import MonitorService
    from observatory.ui.app import ObservatoryApp
    from observatory.ui.themes import Palette


class Pane(Vertical):
    """A UI section. ``update_snapshot`` is called with every new snapshot
    while the pane is visible (and once when it becomes visible)."""

    DEFAULT_CLASSES = "pane"

    @property
    def obs_app(self) -> "ObservatoryApp":
        return self.app  # type: ignore[return-value]

    @property
    def service(self) -> "MonitorService":
        return self.obs_app.service

    @property
    def pal(self) -> "Palette":
        """The active theme's semantic palette (ok / warn / crit / muted / ...)."""
        return self.obs_app.palette

    def update_snapshot(self, snap: Snapshot) -> None:  # pragma: no cover - overridden
        raise NotImplementedError

    def on_show_pane(self) -> None:
        """Hook for panes that load data (e.g. from the database) when shown."""

    def focus_default(self) -> None:
        """Focus the pane's main table so its key bindings work immediately."""
        tables = list(self.query(DataTable))
        if tables:
            tables[0].focus()


def selected_row_key(table: DataTable) -> str | None:
    if table.row_count == 0:
        return None
    try:
        return table.coordinate_to_cell_key(table.cursor_coordinate).row_key.value
    except Exception:
        return None


def refill_table(table: DataTable, rows: list[tuple[str, tuple]]) -> None:
    """Replace all rows, keeping the cursor on the same row key when possible."""
    keep = selected_row_key(table)
    scroll_y = table.scroll_y
    table.clear(columns=False)
    for key, cells in rows:
        table.add_row(*cells, key=key)
    if keep is not None:
        for index, (key, _cells) in enumerate(rows):
            if key == keep:
                table.move_cursor(row=index, animate=False, scroll=False)
                break
    table.scroll_to(y=scroll_y, animate=False)
