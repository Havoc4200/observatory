"""Deep-dive screens for power, forecasts and media. Each one starts with the
same panel the Home dashboard shows, then adds the detail behind it."""

from __future__ import annotations

import time

from rich.text import Text
from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical
from textual.widgets import DataTable, Static

from observatory.models import Snapshot
from observatory.ui.dashboard.panels import (
    DashPanel, ForecastPanel, InsightsPanel, MediaPanel, PowerCenter, StorageCenter,
)
from observatory.ui.panes.base import Pane, refill_table
from observatory.util.format import fmt_bytes, fmt_money, fmt_rate, truncate


class _DeepPane(Pane):
    def update_snapshot(self, snap: Snapshot) -> None:
        for panel in self.query(DashPanel):
            panel.update_snapshot(snap)
        self.update_tables(snap)

    def update_tables(self, snap: Snapshot) -> None:  # pragma: no cover - overridden
        pass


class PowerPane(_DeepPane):
    def compose(self) -> ComposeResult:
        yield PowerCenter(id="pw-center", classes="dash-panel deep-hero")
        with Horizontal(classes="deep-row"):
            with Vertical(classes="panel"):
                yield Static("Energy & cost by day", classes="panel-title")
                yield DataTable(id="pw-days", cursor_type="row", zebra_stripes=True)
            with Vertical(classes="panel"):
                yield Static("Component breakdown", classes="panel-title")
                yield DataTable(id="pw-components", cursor_type="row", zebra_stripes=True)
                yield Static(id="pw-notes")

    def on_mount(self) -> None:
        days = self.query_one("#pw-days", DataTable)
        for label, key in (("Day", "day"), ("kWh", "kwh"), ("Cost", "cost"), ("Avg W", "w")):
            days.add_column(label, key=key)
        comps = self.query_one("#pw-components", DataTable)
        for label, key in (("Component", "c"), ("Watts", "w"), ("Share", "s"), ("Method", "m"),
                           ("Monthly cost", "mc")):
            comps.add_column(label, key=key)

    def update_tables(self, snap: Snapshot) -> None:
        sym = snap.cost.currency_symbol
        rate = snap.cost.rate_per_kwh
        ctx = snap.context
        rows = []
        if ctx is not None:
            today = time.time()
            for i, (kwh, cost) in enumerate(reversed(list(zip(ctx.energy.daily_kwh_14d, ctx.energy.daily_cost_14d)))):
                day = time.localtime(today - i * 86400)
                rows.append((str(i), (time.strftime("%a %b %d", day), Text(f"{kwh:.2f}", justify="right"),
                                      Text(fmt_money(cost, sym), justify="right"),
                                      Text(f"{kwh * 1000 / 24:.0f}" if kwh else "—", justify="right"))))
        refill_table(self.query_one("#pw-days", DataTable), rows)
        total = max(snap.power.dc_watts, 1)
        eff = snap.power.psu_efficiency
        comp_rows = []
        for c in sorted(snap.power.components, key=lambda c: -c.watts):
            wall = c.watts / eff if not c.name.startswith("Extra") else c.watts
            comp_rows.append((c.name, (c.name, Text(f"{c.watts:.1f}", justify="right"),
                                       Text(f"{c.watts / total * 100:.0f}%", justify="right"), c.method,
                                       Text(fmt_money(wall * 730 / 1000 * rate, sym), justify="right"))))
        refill_table(self.query_one("#pw-components", DataTable), comp_rows)
        hw = self.service.hardware
        note = Text()
        note.append("\nModel inputs  ", style="bold")
        note.append(f"CPU {hw.cpu_model} · {hw.ram_gb:.0f} GiB RAM in {hw.dimm_count} DIMM(s) · "
                    f"{len(hw.storage)} drive(s) · {len(hw.discrete_gpus)} discrete GPU(s) · PSU {eff:.2f}\n")
        note.append("Idle floor    ", style="bold")
        note.append(f"{self.service.idle_floor:.0f} W at the wall when everything is idle\n")
        note.append("Methods       ", style="bold")
        note.append("measured = RAPL / GPU sensors · modeled = hardware profile × utilisation · "
                    "configured = Settings", style=self.pal.muted)
        self.query_one("#pw-notes", Static).update(note)


class ForecastPane(_DeepPane):
    def compose(self) -> ComposeResult:
        with Horizontal(classes="deep-row-top"):
            yield ForecastPanel(id="fc-panel", classes="dash-panel")
            yield InsightsPanel(id="fc-insights", classes="dash-panel")
        yield StorageCenter(id="fc-storage", classes="dash-panel deep-hero")
        with Vertical(classes="panel"):
            yield Static("Resource trends (Theil–Sen over 7 days)", classes="panel-title")
            yield DataTable(id="fc-trends", cursor_type="row", zebra_stripes=True)

    def on_mount(self) -> None:
        t = self.query_one("#fc-trends", DataTable)
        for label in ("Metric", "Now", "Slope / day", "In 7 days", "In 30 days", "Fit (R²)"):
            t.add_column(label)

    def update_tables(self, snap: Snapshot) -> None:
        rows = []
        ctx = snap.context
        if ctx is not None:
            for key, trend in ctx.trends.items():
                rows.append((key, (key.upper(), f"{trend.current:.1f}%", f"{trend.slope_per_day:+.2f}",
                                   f"{min(max(trend.projected_7d, 0), 100):.0f}%",
                                   f"{min(max(trend.projected_30d, 0), 100):.0f}%", f"{trend.r_squared:.2f}")))
        refill_table(self.query_one("#fc-trends", DataTable), rows)


class MediaPane(_DeepPane):
    def compose(self) -> ComposeResult:
        yield MediaPanel(id="md-panel", classes="dash-panel deep-hero-small")
        with Vertical(classes="panel"):
            yield Static("Services", classes="panel-title")
            yield DataTable(id="md-apps", cursor_type="row", zebra_stripes=True)
        with Horizontal(classes="deep-row"):
            with Vertical(classes="panel"):
                yield Static("Streams", classes="panel-title")
                yield DataTable(id="md-streams", cursor_type="row", zebra_stripes=True)
            with Vertical(classes="panel"):
                yield Static("Download queues", classes="panel-title")
                yield DataTable(id="md-queue", cursor_type="row", zebra_stripes=True)

    def on_mount(self) -> None:
        for table_id, cols in (("#md-apps", ("Service", "Health", "Found via", "Container", "Version", "URL", "Detail")),
                               ("#md-streams", ("Service", "User", "Title", "State", "Transcode", "Bitrate")),
                               ("#md-queue", ("Service", "Title", "Status", "Progress"))):
            table = self.query_one(table_id, DataTable)
            for c in cols:
                table.add_column(c)

    def update_tables(self, snap: Snapshot) -> None:
        apps = []
        streams = []
        queue = []
        for key, app in snap.media.items():
            detail = app.error or (", ".join(app.health_issues[:1]) if app.health_issues else
                                   ("add API key in Settings → Media" if not app.configured else "ok"))
            if app.download_bps is not None:
                detail = f"↓{fmt_rate(app.download_bps)} ↑{fmt_rate(app.upload_bps or 0)}"
            if app.library_bytes:
                detail += f" · library {fmt_bytes(app.library_bytes)}"
            apps.append((key, (app.name, app.service_health, app.detected_via, app.container or "—",
                               app.version or "—", app.url, truncate(detail, 60))))
            for i, s in enumerate(app.streams):
                streams.append((f"{key}{i}", (app.name, s.user, truncate(s.title, 50), s.state,
                                              ("hardware" if s.hardware else "software") if s.transcode else "direct",
                                              f"{s.bitrate_kbps / 1000:.1f} Mb/s" if s.bitrate_kbps else "—")))
            for i, q in enumerate(app.queue[:30]):
                queue.append((f"{key}q{i}", (app.name, truncate(q.title, 60), q.status, f"{q.progress:.0f}%")))
        refill_table(self.query_one("#md-apps", DataTable), apps)
        refill_table(self.query_one("#md-streams", DataTable), streams)
        refill_table(self.query_one("#md-queue", DataTable), queue)
