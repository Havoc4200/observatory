"""The Observatory Textual application."""

from __future__ import annotations

import logging
import time

from textual import work
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Container
from textual.timer import Timer
from textual.widgets import ContentSwitcher, Footer

from observatory import APP_NAME, MISSION, __version__
from observatory.models import Snapshot
from observatory.services.monitor import MonitorService
from observatory.storage.repository import EventRecord
from observatory.ui.dashboard.home import HomePane
from observatory.ui.dashboard.panels import HeaderBar
from observatory.ui.panes import (
    AlertsPane, AnalyticsPane, DisksPane, DockerPane, ForecastPane, MediaPane, NetworkPane, PowerPane,
    ProcessesPane, SettingsPane,
)
from observatory.ui.panes.base import Pane
from observatory.ui.themes import (
    THEMES, Palette, palette_for, prune_foreign_themes, register_themes, resolve_theme_name,
    theme_variable_defaults,
)
from observatory.ui.widgets import HelpScreen, History, ThemeScreen

log = logging.getLogger(__name__)

# (id, key, title, class)
SECTIONS = [
    ("home", "H", "Home", HomePane),
    ("processes", "P", "Processes", ProcessesPane),
    ("docker", "D", "Docker", DockerPane),
    ("storage", "S", "Storage", DisksPane),
    ("network", "N", "Network", NetworkPane),
    ("power", "W", "Power", PowerPane),
    ("analytics", "A", "Analytics", AnalyticsPane),
    ("forecast", "F", "Forecasts", ForecastPane),
    ("alerts", "L", "Alerts", AlertsPane),
    ("media", "M", "Media", MediaPane),
    ("settings", ",", "Settings", SettingsPane),
]
SECTION_IDS = [sid for sid, *_ in SECTIONS]
# Legacy tab names accepted by --tab / ui.default_tab
ALIASES = {"dashboard": "home", "disks": "storage", "containers": "docker", "forecasts": "forecast"}

EVENT_KINDS_SHOWN = {"alert_fired", "alert_resolved", "alert_escalated", "container_restart", "container_state",
                     "container_created", "container_removed", "container_unhealthy", "config_changed",
                     "network_device_new", "daemon_started", "process_signal", "container_restart_user"}


def _nav_bindings() -> list[Binding]:
    bindings = []
    for index, (sid, key, title, _cls) in enumerate(SECTIONS):
        if key == ",":
            bindings.append(Binding("comma", f"show('{sid}')", title, show=False))
            bindings.append(Binding("O", f"show('{sid}')", title, show=False))
        else:
            bindings.append(Binding(key, f"show('{sid}')", title, show=False))
            bindings.append(Binding(key.lower(), f"show('{sid}')", title, show=False))
        digit = str(index + 1) if index < 9 else ("0" if index == 9 else None)
        if digit:
            bindings.append(Binding(digit, f"show('{sid}')", title, show=False))
    return bindings


class ObservatoryApp(App):
    TITLE = APP_NAME
    SUB_TITLE = MISSION
    CSS_PATH = "app.tcss"

    BINDINGS = [
        Binding("q", "quit", "Quit"),
        Binding("question_mark", "help", "Help"),
        Binding("space", "toggle_pause", "Pause"),
        Binding("T,t", "themes", "Themes"),
        *_nav_bindings(),
    ]

    def __init__(self, service: MonitorService, initial_tab: str | None = None) -> None:
        super().__init__()
        self.service = service
        self.snapshot: Snapshot | None = None
        self.history = History(length=150)
        self.paused = False
        self.recent_events: list[EventRecord] = []
        self._timer: Timer | None = None
        self._collecting = False
        self._events_at = 0.0
        tab = ALIASES.get(initial_tab or "", initial_tab) or ALIASES.get(service.cfg.ui.default_tab,
                                                                          service.cfg.ui.default_tab)
        self.initial_tab = tab if tab in SECTION_IDS else "home"
        register_themes(self)
        self.theme = resolve_theme_name(service.cfg.ui.theme)   # old names map to the new collection
        prune_foreign_themes(self)                                # only the curated collection is offered
        self.palette: Palette = palette_for(self.theme)

    # ------------------------------------------------------------- layout
    @property
    def animations(self) -> bool:
        return self.service.cfg.ui.animations

    def compose(self) -> ComposeResult:
        self.header = HeaderBar([(sid, key, title) for sid, key, title, _ in SECTIONS], id="header")
        yield self.header
        self.switcher = ContentSwitcher(initial=self.initial_tab, id="sections")
        with self.switcher:
            for sid, _key, _title, cls in SECTIONS:
                with Container(id=sid, classes="section"):
                    yield cls(id=f"pane-{sid}")
        yield Footer()

    def on_mount(self) -> None:
        self.title = f"{APP_NAME} {__version__}"
        self.header.set_active(self.initial_tab)
        self._apply_width_classes(self.size.width)
        self.collect_now()
        self._timer = self.set_interval(self.service.cfg.general.refresh_interval, self.collect_now)
        self.set_interval(1.0, self.header.refresh)
        if self.service.storage_error:
            self.notify(self.service.storage_error, severity="warning", timeout=10)
        self.call_after_refresh(self._focus_active)

    def on_resize(self, event) -> None:
        self._apply_width_classes(event.size.width)

    def _apply_width_classes(self, width: int) -> None:
        self.screen.set_class(width < 120, "-narrow")
        self.screen.set_class(width < 150, "-compact")
        self.screen.set_class(width < 175, "-medium")
        self.screen.set_class(width >= 230, "-wide")

    def get_theme_variable_defaults(self) -> dict[str, str]:
        return theme_variable_defaults()

    def watch_theme(self, theme: str) -> None:
        self.palette = palette_for(theme)
        self.refresh_all()

    def refresh_all(self) -> None:
        if self.snapshot is not None:
            self._update_active_pane()
        if getattr(self, "header", None) is not None:
            self.header.refresh()

    # ---------------------------------------------------------- collection
    def collect_now(self) -> None:
        if self.paused or self._collecting:
            return
        self._collecting = True
        self._collect_worker()

    @work(thread=True, exclusive=True, group="collect")
    def _collect_worker(self) -> None:
        try:
            snap = self.service.collect()
            events = None
            if time.time() - self._events_at >= 15:
                self._events_at = time.time()
                events = [e for e in self.service.recent_events(86400, 80) if e.kind in EVENT_KINDS_SHOWN]
        except Exception as exc:  # keep the UI alive; report once per failure
            log.exception("collection failed")
            self.call_from_thread(self._collect_failed, str(exc))
            return
        self.call_from_thread(self.apply_snapshot, snap, events)

    def _collect_failed(self, message: str) -> None:
        self._collecting = False
        self.notify(f"Collection failed: {message}", severity="error")

    def apply_snapshot(self, snap: Snapshot, events: list[EventRecord] | None = None) -> None:
        self._collecting = False
        self.snapshot = snap
        if events is not None:
            self.recent_events = events
        rx, tx = snap.net_totals()
        h = self.history
        h.push("cpu", snap.cpu.percent)
        h.push("mem", snap.memory.percent)
        h.push("swap", snap.swap.percent)
        h.push("power", snap.power.wall_watts)
        h.push("net", rx + tx)
        h.push("rx", rx)
        h.push("tx", tx)
        h.push("disk", sum(d.total_bps for d in snap.disk_io))
        h.push("load", snap.load.load1)
        gpu = next((g.util_percent for g in snap.gpus if g.util_percent is not None), None)
        if gpu is not None:
            h.push("gpu", gpu)
        io_util = max((d.util_percent for d in snap.disk_io), default=0.0) / 100
        net_peak = max(h.get("net") or [1.0]) or 1.0
        activity = min(0.55 * snap.cpu.percent / 100 + 0.2 * io_util + 0.15 * (rx + tx) / max(net_peak, 1e6)
                       + 0.1 * (gpu or 0) / 100, 1.0)
        h.push("activity", activity)
        for alert in snap.new_alerts:
            self.notify(alert.message, title=f"{alert.severity.upper()}: {alert.kind}",
                        severity="error" if alert.severity == "critical" else "warning", timeout=8)
        self.header.update_snapshot(snap)
        self._update_active_pane()

    def active_section(self) -> str:
        return self.switcher.current or "home"

    def is_home_visible(self) -> bool:
        return self.active_section() == "home" and not self.paused

    def active_pane(self) -> Pane | None:
        try:
            return self.switcher.query_one(f"#pane-{self.active_section()}", Pane)
        except Exception:
            return None

    def _update_active_pane(self) -> None:
        pane = self.active_pane()
        if pane is None or self.snapshot is None:
            return
        try:
            pane.update_snapshot(self.snapshot)
        except Exception:
            log.exception("failed to render %s", type(pane).__name__)

    def _focus_active(self) -> None:
        pane = self.active_pane()
        if pane is not None:
            pane.focus_default()

    # ------------------------------------------------------------- actions
    def action_show(self, section: str) -> None:
        switcher = self.switcher
        if switcher.current == section:
            return
        switcher.current = section
        self.header.set_active(section)
        pane = self.active_pane()
        if pane is None:
            return
        pane.on_show_pane()
        pane.focus_default()
        self._update_active_pane()

    def action_help(self) -> None:
        self.push_screen(HelpScreen())

    def action_themes(self) -> None:
        original = self.theme

        def done(chosen: str | None) -> None:
            if chosen is None:
                self.theme = original
                return
            self.theme = chosen
            self.service.cfg.ui.theme = chosen
            try:
                from observatory.config import save_config

                save_config(self.service.cfg)
            except OSError:
                pass
            self.notify(f"Theme: {chosen}")

        self.push_screen(ThemeScreen(self.theme, list(self.available_themes)), done)

    def action_toggle_pause(self) -> None:
        self.paused = not self.paused
        self.notify("Paused — press space to resume." if self.paused else "Resumed.")
        if not self.paused:
            self.collect_now()

    def on_config_changed(self) -> None:
        """Called by Settings after a save: restart the refresh timer at the new interval."""
        if self._timer is not None:
            self._timer.stop()
        self._timer = self.set_interval(self.service.cfg.general.refresh_interval, self.collect_now)

    @property
    def sub_title_text(self) -> str:  # kept for compatibility with older tests/tools
        return "PAUSED" if self.paused else MISSION

    async def action_quit(self) -> None:
        self.exit()

    def on_unmount(self) -> None:
        if self._timer is not None:
            self._timer.stop()


__all__ = ["ObservatoryApp", "SECTIONS", "SECTION_IDS", "THEMES"]
