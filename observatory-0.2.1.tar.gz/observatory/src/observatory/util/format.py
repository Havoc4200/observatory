"""Human-friendly formatting helpers used by the UI and CLI."""

from __future__ import annotations

import math
import time

_BYTE_UNITS = ["B", "KiB", "MiB", "GiB", "TiB", "PiB"]
_RATE_UNITS = ["B/s", "KB/s", "MB/s", "GB/s", "TB/s"]


def fmt_bytes(value: float | int | None, precision: int = 1) -> str:
    if value is None:
        return "—"
    value = float(value)
    if value < 0:
        return "-" + fmt_bytes(-value, precision)
    unit = 0
    while value >= 1024 and unit < len(_BYTE_UNITS) - 1:
        value /= 1024
        unit += 1
    if unit == 0:
        return f"{int(value)} B"
    return f"{value:.{precision}f} {_BYTE_UNITS[unit]}"


def fmt_rate(bytes_per_s: float | None, precision: int = 1) -> str:
    """Decimal units for throughput (network/disk convention)."""
    if bytes_per_s is None:
        return "—"
    value = max(float(bytes_per_s), 0.0)
    unit = 0
    while value >= 1000 and unit < len(_RATE_UNITS) - 1:
        value /= 1000
        unit += 1
    if unit == 0:
        return f"{value:.0f} B/s"
    return f"{value:.{precision}f} {_RATE_UNITS[unit]}"


def fmt_bits(bytes_per_s: float | None) -> str:
    if bytes_per_s is None:
        return "—"
    bits = max(float(bytes_per_s), 0.0) * 8
    for unit in ("bps", "Kbps", "Mbps", "Gbps"):
        if bits < 1000 or unit == "Gbps":
            return f"{bits:.0f} {unit}" if unit == "bps" else f"{bits:.1f} {unit}"
        bits /= 1000
    return f"{bits:.1f} Gbps"  # pragma: no cover


def fmt_percent(value: float | None, precision: int = 1) -> str:
    if value is None or (isinstance(value, float) and math.isnan(value)):
        return "—"
    return f"{value:.{precision}f}%"


def fmt_duration(seconds: float | None) -> str:
    if seconds is None:
        return "—"
    seconds = int(max(seconds, 0))
    days, rem = divmod(seconds, 86400)
    hours, rem = divmod(rem, 3600)
    minutes, secs = divmod(rem, 60)
    if days:
        return f"{days}d {hours}h {minutes}m"
    if hours:
        return f"{hours}h {minutes}m"
    if minutes:
        return f"{minutes}m {secs}s"
    return f"{secs}s"


def fmt_money(value: float | None, symbol: str = "$", precision: int = 2) -> str:
    if value is None:
        return "—"
    sign = "-" if value < 0 else ""
    return f"{sign}{symbol}{abs(value):,.{precision}f}"


def fmt_watts(value: float | None) -> str:
    if value is None:
        return "—"
    if value >= 1000:
        return f"{value / 1000:.2f} kW"
    return f"{value:.0f} W"


def fmt_temp(value: float | None) -> str:
    if value is None:
        return "—"
    return f"{value:.0f}°C"


def fmt_ts(ts: float | None, with_date: bool = True) -> str:
    if not ts:
        return "—"
    fmt = "%Y-%m-%d %H:%M:%S" if with_date else "%H:%M:%S"
    return time.strftime(fmt, time.localtime(ts))


def bar(percent: float, width: int = 20) -> str:
    """A plain text progress bar, e.g. ``██████░░░░`` (for logs/CLI)."""
    percent = min(max(percent, 0.0), 100.0)
    filled = int(round(percent / 100 * width))
    return "█" * filled + "░" * (width - filled)


def bar_text(percent: float, width: int = 20, style: str = "green", empty_style: str = "grey35", pal=None):
    """A rich Text bar drawn with box-drawing characters that every terminal font has.

    With ``pal`` (a theme Palette) the empty track uses the theme's grid colour.
    """
    from rich.text import Text

    if pal is not None:
        empty_style = pal.grid

    percent = min(max(percent, 0.0), 100.0)
    filled = int(round(percent / 100 * width))
    text = Text()
    text.append("━" * filled, style=style)
    text.append("━" * (width - filled), style=empty_style)
    return text


def level_style(percent: float, warn: float = 70.0, crit: float = 90.0, pal=None) -> str:
    """Status style for a utilisation figure; theme-aware when ``pal`` is given."""
    if percent >= crit:
        return f"bold {pal.crit}" if pal is not None else "bold red"
    if percent >= warn:
        return pal.warn if pal is not None else "yellow"
    return pal.ok if pal is not None else "green"


def truncate(text: str, width: int) -> str:
    if width <= 1:
        return text[:width]
    return text if len(text) <= width else text[: width - 1] + "…"
