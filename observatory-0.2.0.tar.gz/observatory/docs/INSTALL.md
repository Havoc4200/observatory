# Installing Observatory

Observatory needs **Linux**, **Python 3.12 or newer**, and about 60 MB of disk for the program plus its history database (typically 20–80 MB per host, depending on retention).

| Distribution | Python 3.12+ available? | Notes |
|---|---|---|
| Ubuntu 24.04+ | Yes (system `python3`) | `python3.12-venv` is installed automatically if missing |
| Linux Mint 22+ | Yes | Same as Ubuntu 24.04 |
| Debian 13 (trixie) | Yes (3.13) | |
| Debian 12 (bookworm) | No (3.11) | Installer provisions Python 3.12 with `uv` automatically |
| Proxmox VE 9 | Yes (Debian 13 base) | Install on the host to see all VMs' combined load and the real hardware |
| Proxmox VE 8 | No (Debian 12 base) | Installer provisions Python 3.12 with `uv` automatically |
| Other systemd distributions | Usually | Pass `--python /path/to/python3.12` if it is not on `PATH` |

## 1. Automatic installation (recommended)

```bash
cd observatory
sudo ./scripts/install.sh --rate 0.15
```

Options:

| Option | Effect |
|---|---|
| `--rate VALUE` | Electricity price per kWh written to the new config |
| `--prefix DIR` | Install location (default `/opt/observatory`) |
| `--python PATH` | Use a specific Python 3.12+ interpreter |
| `--no-service` | Skip the systemd service (UI only) |
| `--no-group-user` | Do not add the invoking user to the `observatory` group |
| `--drivetemp` | Load the `drivetemp` kernel module now and at boot so SATA drive temperatures appear |

What it does:

1. Finds Python 3.12+ (or provisions it with `uv` on Debian 12 / Proxmox VE 8).
2. Creates a virtualenv in `/opt/observatory/venv` and installs Observatory into it.
3. Links `/usr/local/bin/observatory`.
4. Creates the `observatory` group and adds you (`$SUDO_USER`) to it, so your UI sessions can share the service's database.
5. Creates `/etc/observatory/config.toml` (group-writable, so Settings can save it) and `/var/lib/observatory/` (setgid, group-writable).
6. Installs and starts `observatory.service`.

Log out and back in once so the new group membership applies, then run `observatory`.

### Docker access

Docker controls in the UI need access to `/var/run/docker.sock`. Either run `sudo observatory`, or add your user to the `docker` group (`sudo usermod -aG docker $USER`). Membership of the `docker` group is equivalent to root access on that host; decide accordingly.

## 2. Manual installation

```bash
sudo apt-get install -y python3.12 python3.12-venv      # Ubuntu 24.04 / Mint 22
sudo mkdir -p /opt/observatory
sudo python3.12 -m venv /opt/observatory/venv
sudo /opt/observatory/venv/bin/pip install /path/to/observatory
sudo ln -s /opt/observatory/venv/bin/observatory /usr/local/bin/observatory

sudo groupadd --system observatory
sudo usermod -aG observatory "$USER"
sudo install -d -m 2775 -g observatory /etc/observatory /var/lib/observatory
sudo install -m 0664 -g observatory config/observatory.example.toml /etc/observatory/config.toml

sudo cp packaging/systemd/observatory.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now observatory
```

On Debian 12 or Proxmox VE 8, get Python 3.12 with uv instead of apt:

```bash
curl -LsSf https://astral.sh/uv/install.sh | sh
uv venv --python 3.12 /opt/observatory/venv
uv pip install --python /opt/observatory/venv/bin/python /path/to/observatory
```

## 3. Running without installing (development)

```bash
python3.12 -m venv .venv && . .venv/bin/activate
pip install -r requirements-dev.txt && pip install -e .
observatory            # history goes to ~/.local/share/observatory/observatory.db
pytest
```

## 4. First-run checklist

1. `observatory hardware` — check the detected CPU, RAM, GPUs and drives, and the power breakdown.
2. Open Settings (`8`) and set:
   - **Utility rate per kWh** — the energy part of your bill divided by kWh used.
   - **PSU efficiency** — about 0.85 for 80 Plus Bronze, 0.90 Gold, 0.92 Platinum; 0.88 for laptop/mini-PC bricks.
   - **Board/fans allowance** and **Extra devices** if you compare against a wall meter.
   - **Drives normally spun down** if you use HDD spin-down.
3. Save with `ctrl+s`. The service picks up the change automatically within one sample interval.

## 5. Service management

```bash
systemctl status observatory
journalctl -u observatory -f            # logs, including fired alerts
sudo systemctl reload observatory       # re-read the config immediately
observatory db stats                    # database size and row counts
```

The service runs as root (to read RAPL counters, every process and the Docker socket) but with a minimal capability set (`CAP_DAC_READ_SEARCH`, `CAP_SYS_PTRACE`), a read-only filesystem except `/var/lib/observatory` and `/etc/observatory`, `Nice=10`, `CPUQuota=25%` and `MemoryMax=300M`. `systemd-analyze security observatory` rates it "OK".

## 6. Upgrading

```bash
cd observatory && git pull            # or unpack the new release
sudo ./scripts/install.sh             # keeps /etc/observatory/config.toml and all history
```

Database schema migrations run automatically on start.

## 7. Uninstalling

```bash
sudo ./scripts/uninstall.sh           # keeps config and history
sudo ./scripts/uninstall.sh --purge   # removes everything, including the group
```

## 8. Troubleshooting

| Symptom | Fix |
|---|---|
| "History disabled: cannot open /var/lib/observatory/observatory.db" | Your user is not in the `observatory` group yet: `sudo usermod -aG observatory $USER`, then log in again (or `newgrp observatory`). |
| No temperatures | Install `lm-sensors` and run `sudo sensors-detect`; for SATA drives load `drivetemp` (`sudo modprobe drivetemp`, or reinstall with `--drivetemp`). VMs usually expose no sensors. |
| No NVIDIA GPU metrics | Install the NVIDIA driver so `nvidia-smi` works. |
| "Docker unavailable — Permission denied" | Add your user to the `docker` group or run with `sudo`. |
| Power estimate looks wrong | Check `observatory hardware`; override the CPU/GPU model, DIMM count and PSU efficiency in Settings, and set `platform_watts` from a wall-meter reading at idle. |
| Running in a VM/LXC | The estimate covers the guest's own load only; install Observatory on the hypervisor for real power numbers. |
| Terminal shows boxes instead of bars | Use a UTF-8 locale and a font with box-drawing characters (most modern terminals do). |
| Logs for the UI | `~/.local/state/observatory/tui.log` |
