# Observatory MVP — architecture notes

This document maps the MVP code to the Observatory architecture specification and records the decisions that differ from it.

## Decisions for the MVP

| Specification | MVP | Why |
|---|---|---|
| Go agent + hub, SvelteKit web UI | Single Python 3.12 process with a Textual TUI, plus the same code as a headless daemon | Requested MVP stack; fastest path to a working, testable product. The engines are pure Python and isolated behind `MonitorService`, so a future hub/API can reuse them. |
| Compressed sample chunks | Narrow `metrics_raw` table (ts, metric, label, value) with rollups | Simple and adequate for one host at a 10 s interval (~0.5 M rows/day, pruned after 2 days by default). |
| Root-only probe helper | systemd unit as root with a reduced capability set | Smaller moving parts for the MVP; see the unit's sandboxing. |
| gRPC/REST API, plugins, SMART, media integrations | Not in the MVP | Planned in later phases. |

## Data flow

```
collectors (psutil, /proc, /sys, nvidia-smi, Docker socket)
      │  every refresh (TUI: 2 s) or sample interval (daemon: 10 s)
      ▼
MonitorService.collect() ──► PowerEngine ──► CostEngine (energy_hourly)
      │                         AnomalyEngine ──► AlertManager ──► alerts / events
      │                         compute_health
      ▼
Snapshot ──► TUI panes (live)          Repository.insert_metrics ──► metrics_raw
                                       Aggregator.rollup ──► metrics_1m ─► 1h ─► 1d
                                       Aggregator.prune (retention)
```

## Recording modes

`MonitorService(mode=...)`:

- `always` — the daemon. Writes metrics, energy, alerts, events and a heartbeat.
- `auto` — the TUI default. Records only while no fresh daemon heartbeat exists (checked every 30 s), so the TUI and service never write duplicate history; when the daemon is recording, the TUI shows the daemon's alerts from the database.
- `never` — `--no-record`.

## Database schema (v1)

| Table | Key | Contents |
|---|---|---|
| `meta` | key | schema/rollup watermarks, heartbeats |
| `metrics_raw` | (metric, label, ts) index | raw samples at the sample interval |
| `metrics_1m`, `metrics_1h`, `metrics_1d` | (metric, label, bucket) | avg/min/max/count; averages carried up weighted by count |
| `energy_hourly` | hour | Wh, cost (at the rate in force), seconds covered |
| `process_samples` | ts index | top processes by CPU and RSS per sample |
| `events` | id, ts index | alert fired/escalated/resolved, container lifecycle, config changes, service start/stop |
| `alerts` | id, (state, started_at) index | alert lifecycle, acknowledgement |

Migrations live in `storage/database.py` (`MIGRATIONS`), keyed by `PRAGMA user_version`.

## Metric names

`cpu.percent`, `cpu.iowait`, `cpu.freq_mhz`, `mem.percent`, `mem.used_bytes`, `swap.percent`, `load.1/5/15`, `proc.count`, `power.watts`, `power.component{name}`, `power.cost_per_hour`, `health.score`, `alerts.active`, `disk.used_pct{mount}`, `disk.used_bytes{mount}`, `disk.total_bytes{mount}`, `disk.read_bps{dev}`, `disk.write_bps{dev}`, `disk.util{dev}`, `net.rx_bps{iface|_total}`, `net.tx_bps{iface|_total}`, `temp.c{sensor}`, `temp.max_c`, `gpu.util{gpu}`, `gpu.power_w{gpu}`, `gpu.mem_used_bytes{gpu}`, `container.cpu{name}`, `container.mem_bytes{name}`, `container.net_rx_bps{name}`, `container.net_tx_bps{name}`, `docker.running`.

## Anomaly detectors

| Detector | Method | Default trigger |
|---|---|---|
| CPU spike | absolute threshold, or robust z (median/MAD over 30 min of non-spike samples) | ≥ 90 % for 3 samples, or z ≥ 4 and ≥ 25 points above baseline |
| Memory leak | Theil–Sen slope + Mann–Kendall trend over the window, per top-25 RSS process and system memory | τ ≥ 0.7, p < 0.01, growth ≥ max(100 MB, 10 % of start) over 30 min |
| Disk activity | utilisation streak; throughput robust z | ≥ 90 % busy for 6 samples; or z ≥ 6 and ≥ 50 MB/s for 3 samples |
| Network spike | robust z per physical interface; link saturation | z ≥ 6 and ≥ 100 Mbit/s for 2 samples; ≥ 90 % of link speed for 5 samples |
| Thermal | sensor limits and configured thresholds; rise rate | ≥ warning for 2 samples (critical above the critical limit); +15 °C within ~60 s |

Alerts resolve after 3 consecutive clear cycles and cannot re-fire for the cool-down period (10 min).
