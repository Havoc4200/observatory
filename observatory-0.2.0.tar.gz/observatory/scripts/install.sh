#!/usr/bin/env bash
# Observatory installer — Observe. Understand. Predict. Optimize.
#
# Supports Ubuntu, Debian, Linux Mint, Proxmox VE and generic systemd Linux.
# Installs into /opt/observatory (virtualenv), links /usr/local/bin/observatory,
# writes /etc/observatory/config.toml, creates the 'observatory' group and
# enables the observatory.service collector.
#
# Usage: sudo ./scripts/install.sh [options]
#   --prefix DIR        install location (default /opt/observatory)
#   --python PATH       Python 3.12+ interpreter to use
#   --no-service        do not install/enable the systemd service
#   --no-group-user     do not add the invoking user to the 'observatory' group
#   --drivetemp         load the drivetemp kernel module (SATA drive temperatures) now and at boot
#   --rate VALUE        set the electricity rate per kWh in the new config
#   -h, --help          show this help

set -euo pipefail

PREFIX="/opt/observatory"
PYTHON=""
INSTALL_SERVICE=1
ADD_USER=1
DRIVETEMP=0
RATE=""
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CONF_DIR="/etc/observatory"
STATE_DIR="/var/lib/observatory"
UNIT_PATH="/etc/systemd/system/observatory.service"

info()  { printf '\033[1;36m==>\033[0m %s\n' "$*"; }
warn()  { printf '\033[1;33mwarning:\033[0m %s\n' "$*" >&2; }
die()   { printf '\033[1;31merror:\033[0m %s\n' "$*" >&2; exit 1; }

usage() { sed -n '2,19p' "$0" | sed 's/^# \{0,1\}//'; exit 0; }

while [[ $# -gt 0 ]]; do
    case "$1" in
        --prefix) PREFIX="$2"; shift 2 ;;
        --python) PYTHON="$2"; shift 2 ;;
        --no-service) INSTALL_SERVICE=0; shift ;;
        --no-group-user) ADD_USER=0; shift ;;
        --drivetemp) DRIVETEMP=1; shift ;;
        --rate) RATE="$2"; shift 2 ;;
        -h|--help) usage ;;
        *) die "unknown option: $1 (see --help)" ;;
    esac
done

[[ $EUID -eq 0 ]] || die "run as root: sudo $0 $*"
[[ "$(uname -s)" == "Linux" ]] || die "Observatory supports Linux only"
[[ -f "$SRC_DIR/pyproject.toml" ]] || die "cannot find pyproject.toml next to this script ($SRC_DIR)"

DISTRO="unknown"
if [[ -r /etc/os-release ]]; then
    # shellcheck disable=SC1091
    . /etc/os-release
    DISTRO="${PRETTY_NAME:-${ID:-unknown}}"
fi
[[ -d /etc/pve ]] && DISTRO="$DISTRO (Proxmox VE)"
info "Installing Observatory on $DISTRO"

# ------------------------------------------------------------------ python
python_ok() {
    "$1" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 12) else 1)' 2>/dev/null
}

if [[ -n "$PYTHON" ]]; then
    python_ok "$PYTHON" || die "$PYTHON is not Python 3.12 or newer"
else
    for candidate in python3.13 python3.12 python3; do
        if command -v "$candidate" >/dev/null 2>&1 && python_ok "$(command -v "$candidate")"; then
            PYTHON="$(command -v "$candidate")"
            break
        fi
    done
fi

VENV="$PREFIX/venv"
mkdir -p "$PREFIX"

if [[ -n "$PYTHON" ]]; then
    info "Using $PYTHON ($("$PYTHON" --version 2>&1))"
    if ! "$PYTHON" -m venv --help >/dev/null 2>&1 || ! "$PYTHON" -c 'import ensurepip' 2>/dev/null; then
        if command -v apt-get >/dev/null 2>&1; then
            PYVER="$("$PYTHON" -c 'import sys; print(f"{sys.version_info[0]}.{sys.version_info[1]}")')"
            info "Installing python${PYVER}-venv"
            apt-get update -qq
            apt-get install -y -qq "python${PYVER}-venv" || apt-get install -y -qq python3-venv
        else
            die "Python's venv module is missing; install your distribution's python3-venv package"
        fi
    fi
    rm -rf "$VENV"
    "$PYTHON" -m venv "$VENV"
    "$VENV/bin/python" -m pip install --quiet --upgrade pip
    PIP=("$VENV/bin/python" -m pip install --quiet)
else
    # Debian 12 / Proxmox VE 8 ship Python 3.11: fetch a standalone 3.12 with uv.
    warn "No Python 3.12+ found (Debian 12 and Proxmox VE 8 ship 3.11); using uv to provision Python 3.12"
    if ! command -v uv >/dev/null 2>&1; then
        command -v curl >/dev/null 2>&1 || die "curl is required to install uv (apt-get install curl)"
        info "Installing uv to /usr/local/bin"
        curl -LsSf https://astral.sh/uv/install.sh | env UV_INSTALL_DIR=/usr/local/bin UV_NO_MODIFY_PATH=1 sh
    fi
    export UV_PYTHON_INSTALL_DIR="$PREFIX/python"
    rm -rf "$VENV"
    uv venv --python 3.12 "$VENV"
    PIP=(uv pip install --quiet --python "$VENV/bin/python")
fi

# ------------------------------------------------------------------ package
info "Installing Observatory into $VENV"
rm -rf "$PREFIX/src"
mkdir -p "$PREFIX/src"
cp -a "$SRC_DIR/." "$PREFIX/src/"
rm -rf "$PREFIX/src/.venv" "$PREFIX/src/.git"
"${PIP[@]}" "$PREFIX/src"
cp -f "$SRC_DIR/README.md" "$PREFIX/README.md"
ln -sf "$VENV/bin/observatory" /usr/local/bin/observatory

# ------------------------------------------------------------------ group, dirs, config
if ! getent group observatory >/dev/null; then
    info "Creating group 'observatory'"
    groupadd --system observatory
fi
TARGET_USER="${SUDO_USER:-}"
if [[ $ADD_USER -eq 1 && -n "$TARGET_USER" && "$TARGET_USER" != "root" ]]; then
    if ! id -nG "$TARGET_USER" | tr ' ' '\n' | grep -qx observatory; then
        info "Adding $TARGET_USER to group 'observatory' (log out and back in to take effect)"
        usermod -aG observatory "$TARGET_USER"
    fi
fi

install -d -m 2775 -o root -g observatory "$STATE_DIR"
install -d -m 2775 -o root -g observatory "$CONF_DIR"
if [[ ! -f "$CONF_DIR/config.toml" ]]; then
    info "Writing $CONF_DIR/config.toml"
    install -m 0664 -o root -g observatory "$SRC_DIR/config/observatory.example.toml" "$CONF_DIR/config.toml"
    if [[ -n "$RATE" ]]; then
        sed -i "s/^rate_per_kwh = .*/rate_per_kwh = ${RATE}/" "$CONF_DIR/config.toml"
    fi
else
    info "Keeping existing $CONF_DIR/config.toml"
fi
install -m 0644 "$SRC_DIR/config/observatory.example.toml" "$CONF_DIR/config.example.toml"
# Existing database files must stay group-writable for TUI sessions (WAL needs write access).
find "$STATE_DIR" -maxdepth 1 -name 'observatory.db*' -exec chgrp observatory {} + -exec chmod g+rw {} + 2>/dev/null || true

# ------------------------------------------------------------------ drivetemp
if [[ $DRIVETEMP -eq 1 ]]; then
    if modinfo drivetemp >/dev/null 2>&1; then
        info "Loading drivetemp kernel module (SATA drive temperatures)"
        modprobe drivetemp || warn "could not load drivetemp"
        echo drivetemp > /etc/modules-load.d/observatory.conf
    else
        warn "drivetemp module not available in this kernel"
    fi
fi

# ------------------------------------------------------------------ systemd
if [[ $INSTALL_SERVICE -eq 1 ]]; then
    if [[ -d /run/systemd/system ]]; then
        info "Installing systemd service"
        sed "s#/opt/observatory#${PREFIX}#g" "$SRC_DIR/packaging/systemd/observatory.service" > "$UNIT_PATH"
        chmod 0644 "$UNIT_PATH"
        systemctl daemon-reload
        systemctl enable --now observatory.service
        sleep 2
        if systemctl is-active --quiet observatory.service; then
            info "observatory.service is running"
        else
            warn "observatory.service failed to start; check: journalctl -u observatory -n 50"
        fi
    else
        warn "systemd not detected; skipping the service. Run 'observatory daemon' under your init system."
    fi
fi

# ------------------------------------------------------------------ summary
cat <<EOF

Observatory installed.

  Launch the UI:      observatory          (or: sudo observatory, to manage all processes)
  One-shot summary:   observatory status
  Hardware & power:   observatory hardware
  Service logs:       journalctl -u observatory -f
  Configuration:      $CONF_DIR/config.toml  (set your utility rate under [cost])
  History database:   $STATE_DIR/observatory.db

EOF
if [[ $ADD_USER -eq 1 && -n "$TARGET_USER" && "$TARGET_USER" != "root" ]]; then
    echo "  Note: log out and back in (or run 'newgrp observatory') so $TARGET_USER can share the database."
fi
if id -nG "${TARGET_USER:-root}" 2>/dev/null | tr ' ' '\n' | grep -qx docker; then
    :
elif [[ -S /var/run/docker.sock && -n "$TARGET_USER" && "$TARGET_USER" != "root" ]]; then
    echo "  Docker controls in the UI need access to the Docker socket: sudo usermod -aG docker $TARGET_USER"
fi
