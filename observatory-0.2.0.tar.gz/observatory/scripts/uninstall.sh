#!/usr/bin/env bash
# Remove Observatory.
#
# Usage: sudo ./scripts/uninstall.sh [--purge]
#   --purge   also delete /etc/observatory, /var/lib/observatory (all history) and the 'observatory' group

set -euo pipefail

PREFIX="${PREFIX:-/opt/observatory}"
PURGE=0
[[ "${1:-}" == "--purge" ]] && PURGE=1
[[ $EUID -eq 0 ]] || { echo "run as root: sudo $0 $*" >&2; exit 1; }

if [[ -d /run/systemd/system ]] && systemctl list-unit-files observatory.service >/dev/null 2>&1; then
    systemctl disable --now observatory.service 2>/dev/null || true
    rm -f /etc/systemd/system/observatory.service
    systemctl daemon-reload
fi
rm -f /usr/local/bin/observatory
rm -rf "$PREFIX"
rm -f /etc/modules-load.d/observatory.conf

if [[ $PURGE -eq 1 ]]; then
    rm -rf /etc/observatory /var/lib/observatory
    getent group observatory >/dev/null && groupdel observatory || true
    echo "Observatory removed, including configuration and history."
else
    echo "Observatory removed. Kept /etc/observatory and /var/lib/observatory (use --purge to delete)."
fi
