"""Typed read/write access to the Observatory database."""

from __future__ import annotations

import json
import time
from dataclasses import dataclass
from typing import Any

from observatory.models import Alert, ProcessInfo
from observatory.storage.database import ROLLUP_TABLES, Database


@dataclass(slots=True)
class SeriesPoint:
    ts: float
    avg: float
    min: float
    max: float


@dataclass(slots=True)
class SeriesStats:
    avg: float | None
    min: float | None
    max: float | None
    count: int


@dataclass(slots=True)
class EnergyDay:
    day_start: float
    kwh: float
    cost: float
    hours_covered: float


@dataclass(slots=True)
class EventRecord:
    id: int
    ts: float
    kind: str
    severity: str
    source: str
    subject: str
    message: str
    details: dict[str, Any] | None


def local_midnight(ts: float | None = None) -> float:
    lt = time.localtime(ts if ts is not None else time.time())
    return time.mktime((lt.tm_year, lt.tm_mon, lt.tm_mday, 0, 0, 0, 0, 0, -1))


def local_month_start(ts: float | None = None) -> float:
    lt = time.localtime(ts if ts is not None else time.time())
    return time.mktime((lt.tm_year, lt.tm_mon, 1, 0, 0, 0, 0, 0, -1))


def pick_table(span_seconds: float) -> tuple[str, int]:
    """Choose the finest table that still keeps a range query cheap.

    Returns (table, native_step_seconds). Raw data has no fixed step; 0 means
    "use the timestamps as they are".
    """
    if span_seconds <= 3 * 3600:
        return "metrics_raw", 0
    if span_seconds <= 3 * 86400:
        return "metrics_1m", 60
    if span_seconds <= 90 * 86400:
        return "metrics_1h", 3600
    return "metrics_1d", 86400


class Repository:
    def __init__(self, db: Database) -> None:
        self.db = db

    # ------------------------------------------------------------------ meta
    def get_meta(self, key: str, default: str | None = None) -> str | None:
        row = self.db.query_one("SELECT value FROM meta WHERE key = ?", (key,))
        return row["value"] if row else default

    def set_meta(self, key: str, value: Any) -> None:
        self.db.execute(
            "INSERT INTO meta(key, value) VALUES(?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value",
            (key, str(value)),
        )

    def heartbeat(self, role: str, ts: float | None = None) -> None:
        self.set_meta(f"heartbeat.{role}", ts if ts is not None else time.time())

    def last_heartbeat(self, role: str) -> float:
        value = self.get_meta(f"heartbeat.{role}")
        try:
            return float(value) if value else 0.0
        except ValueError:
            return 0.0

    # --------------------------------------------------------------- metrics
    def insert_metrics(self, ts: float, rows: list[tuple[str, str, float]]) -> int:
        stamp = int(ts)
        clean = [(stamp, m, l, float(v)) for m, l, v in rows if v is not None and v == v]  # drop NaN
        if clean:
            self.db.executemany("INSERT INTO metrics_raw(ts, metric, label, value) VALUES(?, ?, ?, ?)", clean)
        return len(clean)

    def series(self, metric: str, label: str = "", start: float | None = None, end: float | None = None,
               max_points: int = 300) -> list[SeriesPoint]:
        end = end if end is not None else time.time()
        start = start if start is not None else end - 3600
        span = max(end - start, 1.0)
        table, native = pick_table(span)
        step = max(int(span / max(max_points, 1)), native, 1)
        if table == "metrics_raw":
            sql = (
                "SELECT (ts / :step) * :step AS b, AVG(value) AS avg, MIN(value) AS min, MAX(value) AS max "
                "FROM metrics_raw WHERE metric = :metric AND label = :label AND ts >= :start AND ts <= :end "
                "GROUP BY b ORDER BY b"
            )
        else:
            sql = (
                f"SELECT (bucket / :step) * :step AS b, SUM(avg * count) / SUM(count) AS avg, "
                f"MIN(min) AS min, MAX(max) AS max FROM {table} "
                "WHERE metric = :metric AND label = :label AND bucket >= :start AND bucket <= :end "
                "GROUP BY b ORDER BY b"
            )
        rows = self.db.query(sql, {"step": step, "metric": metric, "label": label,
                                   "start": int(start), "end": int(end)})
        points = [SeriesPoint(float(r["b"]), float(r["avg"]), float(r["min"]), float(r["max"])) for r in rows]
        if not points and table != "metrics_raw":
            # Fresh install: rollups are still empty, but raw data may cover the range.
            return self._raw_downsampled(metric, label, start, end, step)
        return points

    def _raw_downsampled(self, metric: str, label: str, start: float, end: float, step: int) -> list[SeriesPoint]:
        rows = self.db.query(
            "SELECT (ts / :step) * :step AS b, AVG(value) AS avg, MIN(value) AS min, MAX(value) AS max "
            "FROM metrics_raw WHERE metric = :metric AND label = :label AND ts >= :start AND ts <= :end "
            "GROUP BY b ORDER BY b",
            {"step": step, "metric": metric, "label": label, "start": int(start), "end": int(end)},
        )
        return [SeriesPoint(float(r["b"]), float(r["avg"]), float(r["min"]), float(r["max"])) for r in rows]

    def stats(self, metric: str, label: str = "", start: float | None = None,
              end: float | None = None) -> SeriesStats:
        points = self.series(metric, label, start, end, max_points=2000)
        if not points:
            return SeriesStats(None, None, None, 0)
        return SeriesStats(
            avg=sum(p.avg for p in points) / len(points),
            min=min(p.min for p in points),
            max=max(p.max for p in points),
            count=len(points),
        )

    def labels(self, metric: str, since: float | None = None) -> list[str]:
        since = since if since is not None else time.time() - 86400
        rows = self.db.query(
            "SELECT DISTINCT label FROM metrics_raw WHERE metric = ? AND ts >= ? ORDER BY label",
            (metric, int(since)),
        )
        labels = [r["label"] for r in rows]
        if not labels:
            rows = self.db.query(
                "SELECT DISTINCT label FROM metrics_1h WHERE metric = ? AND bucket >= ? ORDER BY label",
                (metric, int(since)),
            )
            labels = [r["label"] for r in rows]
        return labels

    def first_sample_ts(self) -> float | None:
        candidates = []
        for table, column in (("metrics_raw", "ts"), ("metrics_1m", "bucket"), ("metrics_1h", "bucket"),
                              ("metrics_1d", "bucket")):
            row = self.db.query_one(f"SELECT MIN({column}) AS t FROM {table}")
            if row and row["t"] is not None:
                candidates.append(float(row["t"]))
        return min(candidates) if candidates else None

    # ---------------------------------------------------------------- energy
    def add_energy(self, ts: float, watts: float, seconds: float, rate_per_kwh: float) -> None:
        """Accumulate ``watts`` held for ``seconds`` into the hour containing ``ts``."""
        if seconds <= 0 or watts < 0:
            return
        hour = int(ts) // 3600 * 3600
        wh = watts * seconds / 3600.0
        cost = wh / 1000.0 * rate_per_kwh
        self.db.execute(
            "INSERT INTO energy_hourly(hour, wh, cost, seconds) VALUES(?, ?, ?, ?) "
            "ON CONFLICT(hour) DO UPDATE SET wh = wh + excluded.wh, cost = cost + excluded.cost, "
            "seconds = seconds + excluded.seconds",
            (hour, wh, cost, seconds),
        )

    def energy_between(self, start: float, end: float) -> tuple[float, float, float]:
        """Return (Wh, cost, covered_seconds) for hours starting in [start, end)."""
        row = self.db.query_one(
            "SELECT COALESCE(SUM(wh), 0) AS wh, COALESCE(SUM(cost), 0) AS cost, "
            "COALESCE(SUM(seconds), 0) AS s FROM energy_hourly WHERE hour >= ? AND hour < ?",
            (int(start) // 3600 * 3600, int(end)),
        )
        return (float(row["wh"]), float(row["cost"]), float(row["s"])) if row else (0.0, 0.0, 0.0)

    def energy_daily(self, days: int = 30, now: float | None = None) -> list[EnergyDay]:
        now = now if now is not None else time.time()
        result: list[EnergyDay] = []
        day_start = local_midnight(now)
        for _ in range(days):
            # Next local midnight, computed via mktime so DST days are 23/25 h long.
            day_end = local_midnight(day_start + 26 * 3600)
            wh, cost, secs = self.energy_between(day_start, day_end)
            result.append(EnergyDay(day_start, wh / 1000.0, cost, secs / 3600.0))
            day_start = local_midnight(day_start - 3600)
        return result

    # ------------------------------------------------------------- processes
    def insert_process_samples(self, ts: float, processes: list[ProcessInfo], top_n: int = 5) -> None:
        if not processes:
            return
        by_cpu = sorted(processes, key=lambda p: p.cpu_percent, reverse=True)[:top_n]
        by_mem = sorted(processes, key=lambda p: p.rss, reverse=True)[:top_n]
        chosen = {p.pid: p for p in by_cpu + by_mem}.values()
        self.db.executemany(
            "INSERT INTO process_samples(ts, pid, name, cpu, rss) VALUES(?, ?, ?, ?, ?)",
            [(int(ts), p.pid, p.name, p.cpu_percent, p.rss) for p in chosen],
        )

    def top_processes(self, start: float, end: float, limit: int = 10) -> list[dict[str, Any]]:
        rows = self.db.query(
            "SELECT name, AVG(cpu) AS avg_cpu, MAX(cpu) AS max_cpu, MAX(rss) AS max_rss, COUNT(*) AS n "
            "FROM process_samples WHERE ts >= ? AND ts <= ? GROUP BY name "
            "ORDER BY SUM(cpu) DESC LIMIT ?",
            (int(start), int(end), limit),
        )
        return [dict(r) for r in rows]

    # ---------------------------------------------------------------- events
    def insert_event(self, kind: str, message: str, severity: str = "info", subject: str = "",
                     source: str = "observatory", details: dict[str, Any] | None = None,
                     ts: float | None = None) -> int:
        cur = self.db.execute(
            "INSERT INTO events(ts, kind, severity, source, subject, message, details) VALUES(?, ?, ?, ?, ?, ?, ?)",
            (ts if ts is not None else time.time(), kind, severity, source, subject, message,
             json.dumps(details) if details else None),
        )
        return int(cur.lastrowid)

    def events(self, limit: int = 200, since: float | None = None, kind: str | None = None) -> list[EventRecord]:
        sql = "SELECT * FROM events WHERE 1=1"
        params: list[Any] = []
        if since is not None:
            sql += " AND ts >= ?"
            params.append(since)
        if kind:
            sql += " AND kind = ?"
            params.append(kind)
        sql += " ORDER BY ts DESC, id DESC LIMIT ?"
        params.append(limit)
        out = []
        for r in self.db.query(sql, params):
            details = None
            if r["details"]:
                try:
                    details = json.loads(r["details"])
                except ValueError:
                    details = {"raw": r["details"]}
            out.append(EventRecord(r["id"], r["ts"], r["kind"], r["severity"], r["source"], r["subject"],
                                   r["message"], details))
        return out

    # ---------------------------------------------------------------- alerts
    def insert_alert(self, alert: Alert) -> int:
        cur = self.db.execute(
            "INSERT INTO alerts(kind, severity, subject, message, value, started_at, ended_at, state, acknowledged) "
            "VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (alert.kind, alert.severity, alert.subject, alert.message, alert.value, alert.started_at,
             alert.ended_at, alert.state, int(alert.acknowledged)),
        )
        alert.id = int(cur.lastrowid)
        return alert.id

    def update_alert(self, alert: Alert) -> None:
        if alert.id is None:
            self.insert_alert(alert)
            return
        self.db.execute(
            "UPDATE alerts SET severity = ?, message = ?, value = ?, ended_at = ?, state = ?, acknowledged = ? "
            "WHERE id = ?",
            (alert.severity, alert.message, alert.value, alert.ended_at, alert.state, int(alert.acknowledged),
             alert.id),
        )

    def acknowledge_alert(self, alert_id: int) -> None:
        self.db.execute("UPDATE alerts SET acknowledged = 1 WHERE id = ?", (alert_id,))

    def acknowledge_all(self) -> None:
        self.db.execute("UPDATE alerts SET acknowledged = 1 WHERE acknowledged = 0")

    def clear_resolved(self) -> int:
        cur = self.db.execute("DELETE FROM alerts WHERE state = 'resolved'")
        return cur.rowcount

    def resolve_stale_alerts(self, now: float | None = None) -> int:
        """Close alerts left 'active' by a previous run that exited uncleanly."""
        cur = self.db.execute(
            "UPDATE alerts SET state = 'resolved', ended_at = ? WHERE state = 'active'",
            (now if now is not None else time.time(),),
        )
        return cur.rowcount

    def alerts(self, active_only: bool = False, limit: int = 300) -> list[Alert]:
        sql = "SELECT * FROM alerts"
        if active_only:
            sql += " WHERE state = 'active'"
        sql += " ORDER BY (state = 'active') DESC, started_at DESC LIMIT ?"
        return [
            Alert(
                kind=r["kind"], severity=r["severity"], subject=r["subject"], message=r["message"],
                value=r["value"], started_at=r["started_at"], ended_at=r["ended_at"], state=r["state"],
                acknowledged=bool(r["acknowledged"]), id=r["id"],
            )
            for r in self.db.query(sql, (limit,))
        ]

    def alert_counts(self) -> dict[str, int]:
        rows = self.db.query("SELECT severity, COUNT(*) AS n FROM alerts WHERE state = 'active' GROUP BY severity")
        return {r["severity"]: int(r["n"]) for r in rows}

    # --------------------------------------------------------- window queries
    def window_avg(self, metric: str, label: str, start: float, end: float) -> float | None:
        """Average over [start, end] from the finest table that covers it."""
        points = self.series(metric, label, start, end, max_points=500)
        if not points:
            return None
        return sum(p.avg for p in points) / len(points)

    def peak(self, metric: str, label: str, start: float, end: float) -> tuple[float, float] | None:
        """(max value, timestamp of its bucket) in the window."""
        points = self.series(metric, label, start, end, max_points=500)
        if not points:
            return None
        best = max(points, key=lambda p: p.max)
        return best.max, best.ts

    def count_events(self, kind: str, since: float, subject: str | None = None) -> int:
        sql = "SELECT COUNT(*) AS n FROM events WHERE kind = ? AND ts >= ?"
        params: list[Any] = [kind, since]
        if subject is not None:
            sql += " AND subject = ?"
            params.append(subject)
        row = self.db.query_one(sql, params)
        return int(row["n"]) if row else 0

    def event_subject_counts(self, kind: str, since: float) -> dict[str, int]:
        rows = self.db.query("SELECT subject, COUNT(*) AS n FROM events WHERE kind = ? AND ts >= ? "
                             "GROUP BY subject ORDER BY n DESC", (kind, since))
        return {r["subject"]: int(r["n"]) for r in rows}

    # ------------------------------------------------------- network devices
    def upsert_neighbors(self, neighbors: list[tuple[str, str, str]], now: float) -> list[str]:
        """Record (mac, ip, interface) sightings; return MACs never seen before."""
        if not neighbors:
            return []
        known = {r["mac"] for r in self.db.query("SELECT mac FROM network_devices")}
        first_ever = not known
        new = []
        with self.db.transaction() as cur:
            for mac, ip, iface in neighbors:
                if mac not in known:
                    new.append(mac)
                cur.execute(
                    "INSERT INTO network_devices(mac, ip, interface, first_seen, last_seen) VALUES(?, ?, ?, ?, ?) "
                    "ON CONFLICT(mac) DO UPDATE SET ip = excluded.ip, interface = excluded.interface, "
                    "last_seen = excluded.last_seen",
                    (mac, ip, iface, now, now),
                )
        # The very first scan establishes the baseline; nothing is "new" yet.
        return [] if first_ever else new

    def new_devices(self, since: float) -> list[dict[str, Any]]:
        baseline = self.db.query_one("SELECT MIN(first_seen) AS t FROM network_devices")
        if not baseline or baseline["t"] is None:
            return []
        rows = self.db.query("SELECT * FROM network_devices WHERE first_seen >= ? AND first_seen > ? "
                             "ORDER BY first_seen DESC", (since, float(baseline["t"]) + 60))
        return [dict(r) for r in rows]

    def device_count(self, active_since: float) -> int:
        row = self.db.query_one("SELECT COUNT(*) AS n FROM network_devices WHERE last_seen >= ?", (active_since,))
        return int(row["n"]) if row else 0

    # ----------------------------------------------------------------- SMART
    def insert_smart(self, device: str, ts: float, serial: str, model: str, score: int, risk: str,
                     temperature: float | None, data: dict[str, Any]) -> None:
        self.db.execute(
            "INSERT OR REPLACE INTO smart_snapshots(device, ts, serial, model, health_score, risk, temperature, data) "
            "VALUES(?, ?, ?, ?, ?, ?, ?, ?)",
            (device, ts, serial, model, score, risk, temperature, json.dumps(data, default=str)),
        )

    def smart_history(self, device: str, since: float) -> list[dict[str, Any]]:
        rows = self.db.query("SELECT ts, health_score, risk, temperature FROM smart_snapshots "
                             "WHERE device = ? AND ts >= ? ORDER BY ts", (device, since))
        return [dict(r) for r in rows]

    # ------------------------------------------------------------------ sizes
    def row_counts(self) -> dict[str, int]:
        counts = {}
        for table in ("metrics_raw", *[f"metrics_{n}" for n in ROLLUP_TABLES], "energy_hourly",
                      "process_samples", "events", "alerts", "network_devices", "smart_snapshots"):
            row = self.db.query_one(f"SELECT COUNT(*) AS n FROM {table}")
            counts[table] = int(row["n"]) if row else 0
        return counts
