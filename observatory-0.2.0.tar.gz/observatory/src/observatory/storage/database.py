"""SQLite storage: schema, migrations and a thread-safe connection wrapper.

Tables
------
meta              key/value store (schema version, rollup watermarks, heartbeat)
metrics_raw       narrow time series: (ts, metric, label, value) at the sample interval
metrics_1m/1h/1d  rollups: (metric, label, bucket) -> avg/min/max/count
energy_hourly     integrated energy (Wh) and cost per hour
process_samples   top processes per sample, for "who was busy" analytics
events            structured event log (alerts, container restarts, config changes)
alerts            alert lifecycle (active/resolved, acknowledged)
"""

from __future__ import annotations

import logging
import os
import sqlite3
import stat
import threading
from collections.abc import Iterable, Iterator
from contextlib import contextmanager
from pathlib import Path
from typing import Any

log = logging.getLogger(__name__)

SCHEMA_VERSION = 2

ROLLUP_TABLES = {"1m": 60, "1h": 3600, "1d": 86400}

MIGRATIONS: dict[int, list[str]] = {
    1: [
        """
        CREATE TABLE IF NOT EXISTS meta (
            key   TEXT PRIMARY KEY,
            value TEXT NOT NULL
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS metrics_raw (
            ts     INTEGER NOT NULL,
            metric TEXT    NOT NULL,
            label  TEXT    NOT NULL DEFAULT '',
            value  REAL    NOT NULL
        )
        """,
        "CREATE INDEX IF NOT EXISTS idx_raw_series ON metrics_raw(metric, label, ts)",
        "CREATE INDEX IF NOT EXISTS idx_raw_ts ON metrics_raw(ts)",
        *[
            f"""
            CREATE TABLE IF NOT EXISTS metrics_{name} (
                metric TEXT    NOT NULL,
                label  TEXT    NOT NULL DEFAULT '',
                bucket INTEGER NOT NULL,
                avg    REAL    NOT NULL,
                min    REAL    NOT NULL,
                max    REAL    NOT NULL,
                count  INTEGER NOT NULL,
                PRIMARY KEY (metric, label, bucket)
            ) WITHOUT ROWID
            """
            for name in ROLLUP_TABLES
        ],
        *[f"CREATE INDEX IF NOT EXISTS idx_{name}_bucket ON metrics_{name}(bucket)" for name in ROLLUP_TABLES],
        """
        CREATE TABLE IF NOT EXISTS energy_hourly (
            hour    INTEGER PRIMARY KEY,   -- unix time of the hour start (UTC epoch aligned)
            wh      REAL NOT NULL DEFAULT 0,
            cost    REAL NOT NULL DEFAULT 0,
            seconds REAL NOT NULL DEFAULT 0
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS process_samples (
            ts   INTEGER NOT NULL,
            pid  INTEGER NOT NULL,
            name TEXT    NOT NULL,
            cpu  REAL    NOT NULL,
            rss  INTEGER NOT NULL
        )
        """,
        "CREATE INDEX IF NOT EXISTS idx_proc_ts ON process_samples(ts)",
        """
        CREATE TABLE IF NOT EXISTS events (
            id       INTEGER PRIMARY KEY AUTOINCREMENT,
            ts       REAL    NOT NULL,
            kind     TEXT    NOT NULL,
            severity TEXT    NOT NULL DEFAULT 'info',
            source   TEXT    NOT NULL DEFAULT 'observatory',
            subject  TEXT    NOT NULL DEFAULT '',
            message  TEXT    NOT NULL DEFAULT '',
            details  TEXT
        )
        """,
        "CREATE INDEX IF NOT EXISTS idx_events_ts ON events(ts)",
        """
        CREATE TABLE IF NOT EXISTS alerts (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            kind         TEXT NOT NULL,
            severity     TEXT NOT NULL,
            subject      TEXT NOT NULL,
            message      TEXT NOT NULL,
            value        REAL,
            started_at   REAL NOT NULL,
            ended_at     REAL,
            state        TEXT NOT NULL DEFAULT 'active',
            acknowledged INTEGER NOT NULL DEFAULT 0
        )
        """,
        "CREATE INDEX IF NOT EXISTS idx_alerts_state ON alerts(state, started_at)",
    ],
    2: [
        """
        CREATE TABLE IF NOT EXISTS network_devices (
            mac        TEXT PRIMARY KEY,
            ip         TEXT NOT NULL,
            interface  TEXT NOT NULL DEFAULT '',
            first_seen REAL NOT NULL,
            last_seen  REAL NOT NULL
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS smart_snapshots (
            device       TEXT NOT NULL,
            ts           REAL NOT NULL,
            serial       TEXT NOT NULL DEFAULT '',
            model        TEXT NOT NULL DEFAULT '',
            health_score INTEGER NOT NULL,
            risk         TEXT NOT NULL,
            temperature  REAL,
            data         TEXT,
            PRIMARY KEY (device, ts)
        )
        """,
    ],
}


class Database:
    """One shared SQLite connection guarded by a lock.

    SQLite in WAL mode lets the background daemon write while TUI instances
    read. All access from Observatory goes through :meth:`execute`,
    :meth:`query` or :meth:`transaction`, which serialise use of the
    connection across threads.
    """

    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        if str(self.path) != ":memory:":
            self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._conn = sqlite3.connect(str(self.path), check_same_thread=False, timeout=10.0,
                                     isolation_level=None)
        self._conn.row_factory = sqlite3.Row
        self._configure()
        self.migrate()
        if str(self.path) != ":memory:":
            self._share_with_group()

    def _share_with_group(self) -> None:
        """In a setgid shared directory (the installed /var/lib/observatory), make
        sure the database stays group-writable so the daemon and TUI sessions
        can all open it. SQLite creates its -wal/-shm files with the same
        permissions as the database file, so fixing the main file is enough
        for future files; existing ones are fixed too."""
        try:
            parent = self.path.parent.stat()
        except OSError:
            return
        if not parent.st_mode & stat.S_ISGID:
            return
        for suffix in ("", "-wal", "-shm"):
            p = Path(str(self.path) + suffix)
            try:
                st = p.stat()
                if st.st_uid == os.geteuid() and (st.st_mode & 0o060) != 0o060:
                    p.chmod(st.st_mode | 0o060)
            except OSError:
                pass

    def _configure(self) -> None:
        with self._lock:
            cur = self._conn.cursor()
            if str(self.path) != ":memory:":
                cur.execute("PRAGMA journal_mode=WAL")
            cur.execute("PRAGMA synchronous=NORMAL")
            cur.execute("PRAGMA busy_timeout=10000")
            cur.execute("PRAGMA foreign_keys=ON")
            cur.execute("PRAGMA temp_store=MEMORY")

    # ------------------------------------------------------------ migrations
    @property
    def schema_version(self) -> int:
        with self._lock:
            return int(self._conn.execute("PRAGMA user_version").fetchone()[0])

    def migrate(self) -> None:
        current = self.schema_version
        if current > SCHEMA_VERSION:
            raise RuntimeError(
                f"Database {self.path} has schema v{current}, newer than this Observatory "
                f"(v{SCHEMA_VERSION}). Upgrade Observatory or point it at another database."
            )
        for version in range(current + 1, SCHEMA_VERSION + 1):
            log.info("database: migrating to schema v%d", version)
            with self.transaction() as cur:
                for statement in MIGRATIONS[version]:
                    cur.execute(statement)
                cur.execute(f"PRAGMA user_version={version}")

    # --------------------------------------------------------------- access
    @contextmanager
    def transaction(self) -> Iterator[sqlite3.Cursor]:
        with self._lock:
            cur = self._conn.cursor()
            cur.execute("BEGIN IMMEDIATE")
            try:
                yield cur
            except BaseException:
                cur.execute("ROLLBACK")
                raise
            else:
                cur.execute("COMMIT")
            finally:
                cur.close()

    def execute(self, sql: str, params: Iterable[Any] | dict[str, Any] = ()) -> sqlite3.Cursor:
        with self._lock:
            return self._conn.execute(sql, params)

    def executemany(self, sql: str, rows: Iterable[Iterable[Any]]) -> None:
        with self.transaction() as cur:
            cur.executemany(sql, rows)

    def query(self, sql: str, params: Iterable[Any] | dict[str, Any] = ()) -> list[sqlite3.Row]:
        with self._lock:
            return self._conn.execute(sql, params).fetchall()

    def query_one(self, sql: str, params: Iterable[Any] | dict[str, Any] = ()) -> sqlite3.Row | None:
        with self._lock:
            return self._conn.execute(sql, params).fetchone()

    def size_bytes(self) -> int:
        if str(self.path) == ":memory:":
            row = self.query_one("SELECT page_count * page_size FROM pragma_page_count(), pragma_page_size()")
            return int(row[0]) if row else 0
        total = 0
        for suffix in ("", "-wal", "-shm"):
            p = Path(str(self.path) + suffix)
            if p.exists():
                total += p.stat().st_size
        return total

    def vacuum(self) -> None:
        with self._lock:
            self._conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
            self._conn.execute("VACUUM")

    def close(self) -> None:
        with self._lock:
            try:
                self._conn.execute("PRAGMA optimize")
            except sqlite3.Error:
                pass
            self._conn.close()
