"""Rollups (raw → 1 minute → 1 hour → 1 day) and retention pruning.

Each tier is built only from complete buckets of the tier below, tracked by a
watermark in the ``meta`` table, so the job is idempotent and cheap to run
every minute. Weighted averages are carried up the tiers using ``count``.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass

from observatory.config import StorageConfig
from observatory.storage.database import Database
from observatory.storage.repository import Repository

log = logging.getLogger(__name__)

RAW_GRACE_SECONDS = 60  # late samples within this window still land in the right minute


@dataclass(slots=True)
class RollupResult:
    minute_rows: int = 0
    hour_rows: int = 0
    day_rows: int = 0


@dataclass(slots=True)
class PruneResult:
    raw: int = 0
    minute: int = 0
    hour: int = 0
    day: int = 0
    processes: int = 0
    events: int = 0
    alerts: int = 0


class Aggregator:
    def __init__(self, db: Database, storage: StorageConfig) -> None:
        self.db = db
        self.repo = Repository(db)
        self.storage = storage

    # --------------------------------------------------------------- helpers
    def _watermark(self, name: str) -> int | None:
        value = self.repo.get_meta(f"rollup.{name}")
        return int(float(value)) if value else None

    def _min_bucket(self, table: str, column: str) -> int | None:
        row = self.db.query_one(f"SELECT MIN({column}) AS t FROM {table}")
        return int(row["t"]) if row and row["t"] is not None else None

    # ---------------------------------------------------------------- rollup
    def rollup(self, now: float | None = None) -> RollupResult:
        now = now if now is not None else time.time()
        result = RollupResult()

        # raw -> 1m
        end_1m = (int(now) - RAW_GRACE_SECONDS) // 60 * 60
        start_1m = self._watermark("1m")
        if start_1m is None:
            first = self._min_bucket("metrics_raw", "ts")
            start_1m = first // 60 * 60 if first is not None else end_1m
        if end_1m > start_1m:
            with self.db.transaction() as cur:
                cur.execute(
                    "INSERT OR REPLACE INTO metrics_1m(metric, label, bucket, avg, min, max, count) "
                    "SELECT metric, label, (ts / 60) * 60 AS b, AVG(value), MIN(value), MAX(value), COUNT(*) "
                    "FROM metrics_raw WHERE ts >= ? AND ts < ? GROUP BY metric, label, b",
                    (start_1m, end_1m),
                )
                result.minute_rows = cur.rowcount
                cur.execute(
                    "INSERT INTO meta(key, value) VALUES('rollup.1m', ?) "
                    "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
                    (str(end_1m),),
                )

        # 1m -> 1h  (only hours whose minutes are all rolled up)
        end_1h = min(int(now) // 3600 * 3600, end_1m // 3600 * 3600)
        result.hour_rows = self._cascade("metrics_1m", "metrics_1h", 3600, "1h", end_1h)

        # 1h -> 1d
        end_1d = min(int(now) // 86400 * 86400, end_1h // 86400 * 86400)
        result.day_rows = self._cascade("metrics_1h", "metrics_1d", 86400, "1d", end_1d)
        return result

    def _cascade(self, source: str, target: str, step: int, name: str, end: int) -> int:
        start = self._watermark(name)
        if start is None:
            first = self._min_bucket(source, "bucket")
            start = first // step * step if first is not None else end
        if end <= start:
            return 0
        with self.db.transaction() as cur:
            cur.execute(
                f"INSERT OR REPLACE INTO {target}(metric, label, bucket, avg, min, max, count) "
                f"SELECT metric, label, (bucket / {step}) * {step} AS b, "
                "SUM(avg * count) / SUM(count), MIN(min), MAX(max), SUM(count) "
                f"FROM {source} WHERE bucket >= ? AND bucket < ? GROUP BY metric, label, b",
                (start, end),
            )
            rows = cur.rowcount
            cur.execute(
                "INSERT INTO meta(key, value) VALUES(?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value",
                (f"rollup.{name}", str(end)),
            )
        return rows

    # ----------------------------------------------------------------- prune
    def prune(self, now: float | None = None) -> PruneResult:
        now = now if now is not None else time.time()
        s = self.storage
        result = PruneResult()
        raw_cutoff = int(now - s.retention_raw_days * 86400)
        # Never prune raw data that has not been rolled up yet.
        watermark = self._watermark("1m")
        if watermark is not None:
            raw_cutoff = min(raw_cutoff, watermark)
        else:
            raw_cutoff = 0  # nothing rolled up yet: keep all raw data
        with self.db.transaction() as cur:
            cur.execute("DELETE FROM metrics_raw WHERE ts < ?", (raw_cutoff,))
            result.raw = cur.rowcount
            cur.execute("DELETE FROM process_samples WHERE ts < ?", (raw_cutoff,))
            result.processes = cur.rowcount
            cur.execute("DELETE FROM metrics_1m WHERE bucket < ?", (int(now - s.retention_1m_days * 86400),))
            result.minute = cur.rowcount
            cur.execute("DELETE FROM metrics_1h WHERE bucket < ?", (int(now - s.retention_1h_days * 86400),))
            result.hour = cur.rowcount
            if s.retention_1d_days > 0:
                cur.execute("DELETE FROM metrics_1d WHERE bucket < ?", (int(now - s.retention_1d_days * 86400),))
                result.day = cur.rowcount
            cur.execute("DELETE FROM events WHERE ts < ?", (now - 365 * 86400,))
            result.events = cur.rowcount
            cur.execute("DELETE FROM alerts WHERE state = 'resolved' AND ended_at < ?", (now - 90 * 86400,))
            result.alerts = cur.rowcount
            cur.execute("DELETE FROM smart_snapshots WHERE ts < ?", (now - 2 * 365 * 86400,))
            cur.execute("DELETE FROM network_devices WHERE last_seen < ?", (now - 180 * 86400,))
        if any((result.raw, result.minute, result.hour, result.day)):
            log.debug("prune: %s", result)
        return result
