"""Command-line entry point.

    observatory                 launch the TUI
    observatory daemon          run the headless collector (systemd)
    observatory status [--json] one-shot summary
    observatory hardware        detected hardware and power estimate
    observatory init-config     write a default configuration file
    observatory db stats|rollup|prune|vacuum
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import sys
import time
from dataclasses import asdict
from pathlib import Path

from observatory import APP_NAME, MISSION, __version__
from observatory.config import Config, SYSTEM_CONFIG_PATH, load_config, save_config, user_config_path
from observatory.util.format import fmt_bytes, fmt_duration, fmt_money, fmt_rate, fmt_watts


def state_dir() -> Path:
    base = os.environ.get("XDG_STATE_HOME") or str(Path.home() / ".local" / "state")
    return Path(base) / "observatory"


def setup_logging(level: str, log_file: str | None = None, to_stderr: bool = True) -> None:
    handlers: list[logging.Handler] = []
    if log_file:
        path = Path(log_file).expanduser()
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            handlers.append(logging.FileHandler(path, encoding="utf-8"))
        except OSError:
            pass
    if to_stderr:
        handlers.append(logging.StreamHandler(sys.stderr))
    if not handlers:
        handlers.append(logging.NullHandler())
    logging.basicConfig(
        level=getattr(logging, level.upper(), logging.INFO),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
        handlers=handlers,
        force=True,
    )


def _common_options(parser: argparse.ArgumentParser, suppress: bool) -> None:
    """Global options, accepted both before and after the subcommand."""
    default = (lambda value: argparse.SUPPRESS) if suppress else (lambda value: value)
    parser.add_argument("-c", "--config", default=default(None), help="path to config.toml")
    parser.add_argument("--db", default=default(None), help="override the SQLite database path")
    parser.add_argument("--log-level", default=default("INFO"), help="DEBUG, INFO, WARNING, ERROR")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="observatory", description=f"{APP_NAME} — {MISSION}")
    parser.add_argument("--version", action="version", version=f"{APP_NAME} {__version__}")
    _common_options(parser, suppress=False)
    common = argparse.ArgumentParser(add_help=False)
    _common_options(common, suppress=True)
    sub = parser.add_subparsers(dest="command")

    tui = sub.add_parser("tui", parents=[common], help="launch the terminal UI (default)")
    for p, suppress in ((parser, False), (tui, True)):
        none = argparse.SUPPRESS if suppress else None
        flag = argparse.SUPPRESS if suppress else False
        p.add_argument("--tab", default=none, help="section to open first (dashboard, processes, disks, "
                                                   "network, docker, analytics, alerts, settings)")
        p.add_argument("--no-record", action="store_true", default=flag, help="view only: never write history")
        p.add_argument("--no-docker", action="store_true", default=flag, help="disable Docker integration")
        p.add_argument("--demo", action="store_true", default=flag,
                       help="run the UI against a simulated homelab (no real data is read or changed)")
        p.add_argument("--theme", default=none, help="theme to start with (see the T key)")
        p.add_argument("--log-file", default=none,
                       help="log file for the TUI (default ~/.local/state/observatory/tui.log)")

    daemon = sub.add_parser("daemon", parents=[common], help="run the headless collector (systemd service)")
    daemon.add_argument("--once", action="store_true", help="collect a single cycle and exit")

    status = sub.add_parser("status", parents=[common], help="print a one-shot summary")
    status.add_argument("--json", action="store_true", help="machine-readable output")

    sub.add_parser("hardware", parents=[common], help="show detected hardware and the power estimate")

    init = sub.add_parser("init-config", parents=[common], help="write a default configuration file")
    init.add_argument("--system", action="store_true", help=f"write {SYSTEM_CONFIG_PATH} (needs root)")
    init.add_argument("--path", help="write to this path instead")
    init.add_argument("--force", action="store_true", help="overwrite an existing file")

    db = sub.add_parser("db", parents=[common], help="database maintenance")
    db.add_argument("action", choices=["stats", "rollup", "prune", "vacuum"])
    return parser


# ----------------------------------------------------------------- commands
def cmd_tui(cfg: Config, args: argparse.Namespace) -> int:
    from observatory.services.monitor import MonitorService
    from observatory.ui.app import ObservatoryApp

    setup_logging(args.log_level, args.log_file or str(state_dir() / "tui.log"), to_stderr=False)
    if getattr(args, "theme", None):
        cfg.ui.theme = args.theme
    if getattr(args, "demo", False):
        from observatory.demo import DemoService

        service = DemoService(cfg)
    else:
        mode = "never" if args.no_record else "auto"
        service = MonitorService(cfg, mode=mode, db_path=args.db,
                                 enable_docker=False if args.no_docker else None)
    try:
        ObservatoryApp(service, initial_tab=args.tab).run()
    finally:
        service.close()
    return 0


def cmd_daemon(cfg: Config, args: argparse.Namespace) -> int:
    from observatory.services.daemon import run_daemon

    setup_logging(args.log_level)
    if args.db:
        cfg.storage.db_path = args.db
    return run_daemon(cfg, max_cycles=1 if args.once else None, config_path=args.config)


def _two_samples(cfg: Config, args: argparse.Namespace):
    from observatory.services.monitor import MonitorService

    service = MonitorService(cfg, mode="never", db_path=args.db)
    try:
        service.collect()
        time.sleep(1.0)
        return service, service.collect()
    except BaseException:
        service.close()
        raise


def cmd_status(cfg: Config, args: argparse.Namespace) -> int:
    setup_logging("WARNING")
    service, snap = _two_samples(cfg, args)
    try:
        if args.json:
            payload = {
                "host": snap.hostname,
                "ts": snap.ts,
                "uptime_s": snap.uptime_s,
                "cpu_percent": snap.cpu.percent,
                "memory": asdict(snap.memory),
                "swap": asdict(snap.swap),
                "load": [snap.load.load1, snap.load.load5, snap.load.load15],
                "disks": [asdict(d) for d in snap.disks],
                "temperatures": [asdict(t) for t in snap.temps],
                "gpus": [asdict(g) for g in snap.gpus],
                "power": asdict(snap.power),
                "cost": asdict(snap.cost),
                "health": asdict(snap.health),
                "containers": [asdict(c) for c in snap.containers],
                "alerts": [asdict(a) for a in snap.alerts],
            }
            print(json.dumps(payload, indent=2, default=str))
            return 0
        sym = snap.cost.currency_symbol
        rx, tx = snap.net_totals()
        hot = snap.hottest()
        top = snap.top_process()
        print(f"{APP_NAME} {__version__} — {snap.hostname}  (up {fmt_duration(snap.uptime_s)})")
        print(f"  Health        {snap.health.score}/100 {snap.health.grade}: {'; '.join(snap.health.reasons[:3])}")
        print(f"  CPU           {snap.cpu.percent:.1f}%  load {snap.load.load1:.2f} {snap.load.load5:.2f} {snap.load.load15:.2f}")
        print(f"  Memory        {snap.memory.percent:.1f}%  ({fmt_bytes(snap.memory.used)} / {fmt_bytes(snap.memory.total)})")
        print(f"  Swap          {snap.swap.percent:.1f}%")
        print(f"  Network       ↓ {fmt_rate(rx)}  ↑ {fmt_rate(tx)}")
        print(f"  Hottest       {f'{hot.current:.0f}°C ({hot.name})' if hot else 'no sensors'}")
        print(f"  Top process   {f'{top.name} ({top.cpu_percent:.0f}% CPU)' if top else '—'}")
        print(f"  Power         {fmt_watts(snap.power.wall_watts)} ({snap.power.low_watts:.0f}–{snap.power.high_watts:.0f} W, {snap.power.method})")
        print(f"  Cost          {fmt_money(snap.cost.hourly_cost, sym, 3)}/h · today {fmt_money(snap.cost.today_cost, sym)}"
              f" · month ≈ {fmt_money(snap.cost.monthly_estimate, sym)} · year ≈ {fmt_money(snap.cost.annual_estimate, sym)}")
        for d in snap.disks:
            print(f"  Disk          {d.mountpoint:<20} {d.percent:5.1f}%  of {fmt_bytes(d.total)}")
        if snap.docker_available:
            running = sum(1 for c in snap.containers if c.state == "running")
            print(f"  Docker        {running}/{len(snap.containers)} containers running")
        else:
            print(f"  Docker        {snap.docker_error}")
        return 0
    finally:
        service.close()


def cmd_hardware(cfg: Config, args: argparse.Namespace) -> int:
    from observatory.engines.power import energy_projection

    setup_logging("WARNING")
    service, snap = _two_samples(cfg, args)
    try:
        print("Detected hardware")
        for line in service.hardware.summary_lines():
            print("  " + line)
        print("\nPower estimate (current load)")
        for comp in snap.power.components:
            print(f"  {comp.name:<36} {comp.watts:7.1f} W  {comp.method}")
        p = snap.power
        print(f"  {'DC total':<36} {p.dc_watts:7.1f} W")
        print(f"  {'Wall (÷ PSU ' + format(p.psu_efficiency, '.2f') + ')':<36} {p.wall_watts:7.1f} W  "
              f"range {p.low_watts:.0f}–{p.high_watts:.0f} W")
        proj = energy_projection(p.wall_watts)
        rate = cfg.cost.rate_per_kwh
        sym = cfg.cost.currency_symbol
        print(f"\nAt this draw: {proj['daily_kwh']:.2f} kWh/day ({fmt_money(proj['daily_kwh'] * rate, sym)}), "
              f"{proj['monthly_kwh']:.1f} kWh/month ({fmt_money(proj['monthly_kwh'] * rate, sym)}), "
              f"{proj['annual_kwh']:.0f} kWh/year ({fmt_money(proj['annual_kwh'] * rate, sym)}) "
              f"at {fmt_money(rate, sym, 3)}/kWh")
        return 0
    finally:
        service.close()


def cmd_init_config(args: argparse.Namespace) -> int:
    if args.path:
        target = Path(args.path).expanduser()
    elif args.system:
        target = SYSTEM_CONFIG_PATH
    else:
        target = user_config_path()
    if target.exists() and not args.force:
        print(f"{target} already exists (use --force to overwrite)", file=sys.stderr)
        return 1
    try:
        save_config(Config(), target)
    except OSError as exc:
        print(f"Cannot write {target}: {exc}", file=sys.stderr)
        return 1
    print(f"Wrote default configuration to {target}")
    return 0


def cmd_db(cfg: Config, args: argparse.Namespace) -> int:
    from observatory.storage import Aggregator, Database, Repository

    setup_logging(args.log_level)
    path = Path(args.db).expanduser() if args.db else cfg.resolved_db_path()
    if not path.exists():
        print(f"No database at {path}", file=sys.stderr)
        return 1
    db = Database(path)
    try:
        repo = Repository(db)
        agg = Aggregator(db, cfg.storage)
        if args.action == "stats":
            print(f"Database {path} — {fmt_bytes(db.size_bytes())}, schema v{db.schema_version}")
            for table, count in repo.row_counts().items():
                print(f"  {table:<18} {count:>12,}")
            first = repo.first_sample_ts()
            if first:
                print(f"  history since      {time.strftime('%Y-%m-%d %H:%M', time.localtime(first))}")
            daemon = repo.last_heartbeat("daemon")
            if daemon:
                print(f"  daemon heartbeat   {time.time() - daemon:.0f}s ago")
        elif args.action == "rollup":
            print(agg.rollup())
        elif args.action == "prune":
            print(agg.prune())
        elif args.action == "vacuum":
            before = db.size_bytes()
            db.vacuum()
            print(f"Vacuumed: {fmt_bytes(before)} → {fmt_bytes(db.size_bytes())}")
        return 0
    finally:
        db.close()


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if sys.platform != "linux":
        print("Observatory supports Linux only.", file=sys.stderr)
        return 1
    if args.command == "init-config":
        return cmd_init_config(args)
    cfg = load_config(args.config)
    if args.db:
        cfg.storage.db_path = args.db
    command = args.command or "tui"
    try:
        if command == "tui":
            return cmd_tui(cfg, args)
        if command == "daemon":
            return cmd_daemon(cfg, args)
        if command == "status":
            return cmd_status(cfg, args)
        if command == "hardware":
            return cmd_hardware(cfg, args)
        if command == "db":
            return cmd_db(cfg, args)
    except KeyboardInterrupt:
        return 130
    except BrokenPipeError:  # e.g. `observatory status | head`
        devnull = os.open(os.devnull, os.O_WRONLY)
        os.dup2(devnull, sys.stdout.fileno())
        return 0
    parser.print_help()
    return 2


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
