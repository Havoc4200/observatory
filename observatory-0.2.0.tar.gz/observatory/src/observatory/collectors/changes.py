"""Change Journal sources outside Observatory itself: package installs and
upgrades (dpkg/apt, dnf, pacman logs) and reboots.

These answer "what changed?" for problems that start after an upgrade.
Log files are world-readable on the supported distributions; missing files
are simply skipped.
"""

from __future__ import annotations

import re
import time
from dataclasses import dataclass
from pathlib import Path

DPKG_LOG = Path("/var/log/dpkg.log")
DNF_LOG = Path("/var/log/dnf.rpm.log")
PACMAN_LOG = Path("/var/log/pacman.log")

_DPKG_RE = re.compile(r"^(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d) (install|upgrade|remove) (\S+) (\S+) (\S+)")
_DNF_RE = re.compile(r"^(\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d)\S* \w+ (Upgrade|Upgraded|Installed|Erase|Removed): (\S+)")
_PACMAN_RE = re.compile(r"^\[(\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d)[^\]]*\] \[ALPM\] (installed|upgraded|removed) (\S+)")

NOTABLE = ("linux-image", "linux-", "pve-kernel", "proxmox-kernel", "kernel", "docker", "containerd", "systemd",
           "openssh", "nvidia", "zfs", "libc6", "glibc", "openssl", "plex", "jellyfin")


@dataclass(frozen=True, slots=True)
class PackageChange:
    ts: float
    action: str        # install | upgrade | remove
    package: str
    version: str = ""

    @property
    def notable(self) -> bool:
        return self.package.startswith(NOTABLE)


def _parse_ts(text: str, fmt: str) -> float:
    return time.mktime(time.strptime(text, fmt))


def parse_dpkg_log(text: str, since: float) -> list[PackageChange]:
    out = []
    for line in text.splitlines():
        m = _DPKG_RE.match(line)
        if not m:
            continue
        ts = _parse_ts(m.group(1), "%Y-%m-%d %H:%M:%S")
        if ts < since:
            continue
        action, pkg, old, new = m.group(2), m.group(3).split(":")[0], m.group(4), m.group(5)
        version = new if action != "remove" else old
        out.append(PackageChange(ts, action, pkg, "" if version == "<none>" else version))
    return out


def parse_dnf_log(text: str, since: float) -> list[PackageChange]:
    out = []
    mapping = {"Upgrade": "upgrade", "Upgraded": "upgrade", "Installed": "install", "Erase": "remove",
               "Removed": "remove"}
    for line in text.splitlines():
        m = _DNF_RE.match(line)
        if m:
            ts = _parse_ts(m.group(1), "%Y-%m-%dT%H:%M:%S")
            if ts >= since and m.group(2) != "Upgraded":  # "Upgraded" is the old half of an upgrade pair
                out.append(PackageChange(ts, mapping[m.group(2)], m.group(3)))
    return out


def parse_pacman_log(text: str, since: float) -> list[PackageChange]:
    out = []
    mapping = {"installed": "install", "upgraded": "upgrade", "removed": "remove"}
    for line in text.splitlines():
        m = _PACMAN_RE.match(line)
        if m:
            ts = _parse_ts(m.group(1), "%Y-%m-%dT%H:%M:%S")
            if ts >= since:
                out.append(PackageChange(ts, mapping[m.group(2)], m.group(3)))
    return out


def _tail(path: Path, max_bytes: int = 2_000_000) -> str:
    try:
        with path.open("rb") as fh:
            fh.seek(0, 2)
            size = fh.tell()
            fh.seek(max(size - max_bytes, 0))
            return fh.read().decode("utf-8", errors="replace")
    except OSError:
        return ""


def recent_package_changes(since: float) -> list[PackageChange]:
    changes: list[PackageChange] = []
    if DPKG_LOG.exists():
        changes += parse_dpkg_log(_tail(DPKG_LOG), since)
    if DNF_LOG.exists():
        changes += parse_dnf_log(_tail(DNF_LOG), since)
    if PACMAN_LOG.exists():
        changes += parse_pacman_log(_tail(PACMAN_LOG), since)
    changes.sort(key=lambda c: c.ts)
    return changes


@dataclass(frozen=True, slots=True)
class ChangeGroup:
    """Package changes collapsed into one timeline entry per apt/dnf run."""

    ts: float
    count: int
    notable: tuple[str, ...]
    action: str

    @property
    def message(self) -> str:
        verb = {"upgrade": "upgraded", "install": "installed", "remove": "removed"}.get(self.action, self.action)
        head = f"{self.count} package{'s' if self.count != 1 else ''} {verb}"
        if self.notable:
            head += " incl. " + ", ".join(self.notable[:3])
        return head


def group_changes(changes: list[PackageChange], gap: float = 600.0) -> list[ChangeGroup]:
    """Merge changes less than ``gap`` seconds apart (one upgrade run)."""
    groups: list[ChangeGroup] = []
    batch: list[PackageChange] = []

    def flush() -> None:
        if not batch:
            return
        actions = [c.action for c in batch]
        action = max(set(actions), key=actions.count)
        notable = tuple(dict.fromkeys(c.package for c in batch if c.notable))
        groups.append(ChangeGroup(batch[-1].ts, len(batch), notable, action))
        batch.clear()

    for change in changes:
        if batch and change.ts - batch[-1].ts > gap:
            flush()
        batch.append(change)
    flush()
    return groups
