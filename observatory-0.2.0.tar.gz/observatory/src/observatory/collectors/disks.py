"""Filesystem usage, block-device I/O rates and storage device inventory."""

from __future__ import annotations

import os
import time
from pathlib import Path

import psutil

from observatory.models import DiskIO, DiskUsage, StorageDevice
from observatory.util.rates import RateTracker

SYS_BLOCK = Path("/sys/block")

# Filesystems that hold real data. Everything else (tmpfs, overlay, proc...) is skipped.
REAL_FSTYPES = {
    "ext2", "ext3", "ext4", "xfs", "btrfs", "zfs", "f2fs", "vfat", "exfat", "ntfs",
    "ntfs3", "fuseblk", "nfs", "nfs4", "cifs", "smb3", "fuse.mergerfs", "fuse.shfs",
    "jfs", "reiserfs", "bcachefs", "hfsplus", "fuse.sshfs", "9p", "virtiofs", "ceph",
    "glusterfs", "fuse.glusterfs", "fuse.rclone",
}
SKIP_MOUNT_PREFIXES = ("/snap/", "/var/lib/docker/", "/var/lib/containers/", "/run/", "/proc", "/sys")
SKIP_BLOCK_PREFIXES = ("loop", "ram", "zram", "sr", "fd", "md127p")


def is_real_mount(device: str, mountpoint: str, fstype: str) -> bool:
    if fstype not in REAL_FSTYPES:
        return False
    if mountpoint != "/" and mountpoint.startswith(SKIP_MOUNT_PREFIXES):
        return False
    if device.startswith("/dev/loop"):
        return False
    return True


def zfs_pool(device: str) -> str:
    return device.split("/", 1)[0]


class DiskCollector:
    def __init__(self, sys_block: Path = SYS_BLOCK) -> None:
        self._rates = RateTracker()
        self._sys_block = sys_block
        self._devices_cache: list[StorageDevice] = []
        self._devices_cache_at = 0.0

    # ----------------------------------------------------------------- usage
    def usage(self) -> list[DiskUsage]:
        results: list[DiskUsage] = []
        seen: set[tuple[str, int]] = set()
        zfs_best: dict[str, DiskUsage] = {}
        try:
            partitions = psutil.disk_partitions(all=True)
        except OSError:
            return results
        for part in partitions:
            if not is_real_mount(part.device, part.mountpoint, part.fstype):
                continue
            try:
                du = psutil.disk_usage(part.mountpoint)
            except (PermissionError, FileNotFoundError, OSError):
                continue
            if du.total == 0:
                continue
            usage = DiskUsage(
                device=part.device,
                mountpoint=part.mountpoint,
                fstype=part.fstype,
                total=du.total,
                used=du.used,
                free=du.free,
                percent=round(du.percent, 2),
            )
            if part.fstype == "zfs":
                # One row per pool: the shallowest mounted dataset represents it.
                pool = zfs_pool(part.device)
                current = zfs_best.get(pool)
                if current is None or len(part.mountpoint) < len(current.mountpoint):
                    zfs_best[pool] = usage
                continue
            key = (part.device, du.total)
            if key in seen:  # bind mount or duplicate
                continue
            seen.add(key)
            results.append(usage)
        results.extend(zfs_best.values())
        results.sort(key=lambda d: d.mountpoint)
        return results

    # -------------------------------------------------------------------- io
    def _is_whole_disk(self, name: str) -> bool:
        if name.startswith(SKIP_BLOCK_PREFIXES):
            return False
        return (self._sys_block / name).exists()

    def io(self) -> list[DiskIO]:
        try:
            counters = psutil.disk_io_counters(perdisk=True) or {}
        except (OSError, RuntimeError):
            return []
        now = time.monotonic()
        results: list[DiskIO] = []
        live: set = set()
        for name, c in counters.items():
            if not self._is_whole_disk(name):
                continue
            keys = [(name, k) for k in ("rb", "wb", "rc", "wc", "busy")]
            live.update(keys)
            busy_ms = float(getattr(c, "busy_time", 0) or 0)
            busy_rate = self._rates.rate((name, "busy"), busy_ms, now)  # ms busy per second
            results.append(
                DiskIO(
                    device=self.display_name(name),
                    read_bps=self._rates.rate((name, "rb"), c.read_bytes, now),
                    write_bps=self._rates.rate((name, "wb"), c.write_bytes, now),
                    read_iops=self._rates.rate((name, "rc"), c.read_count, now),
                    write_iops=self._rates.rate((name, "wc"), c.write_count, now),
                    util_percent=round(min(busy_rate / 10.0, 100.0), 1),
                )
            )
        self._rates.forget_missing(live)
        results.sort(key=lambda d: d.device)
        return results

    def display_name(self, name: str) -> str:
        """Device-mapper devices get their mapper name (e.g. ``dm-0`` → ``pve-root``)."""
        if name.startswith("dm-"):
            try:
                mapped = (self._sys_block / name / "dm" / "name").read_text().strip()
                if mapped:
                    return mapped
            except OSError:
                pass
        return name

    # ------------------------------------------------------------- inventory
    def devices(self, max_age: float = 300.0) -> list[StorageDevice]:
        now = time.monotonic()
        if self._devices_cache and now - self._devices_cache_at < max_age:
            return self._devices_cache
        self._devices_cache = scan_storage_devices(self._sys_block)
        self._devices_cache_at = now
        return self._devices_cache


def _read(path: Path, default: str = "") -> str:
    try:
        return path.read_text(errors="replace").strip()
    except OSError:
        return default


def classify_device(name: str, rotational: bool, removable: bool, transport: str) -> str:
    if name.startswith("nvme"):
        return "nvme"
    if name.startswith(("vd", "xvd")) or name.startswith("dm-") or name.startswith("md"):
        return "virtual"
    if transport == "usb" or removable:
        return "usb"
    if name.startswith(("sd", "hd", "mmcblk")):
        return "hdd" if rotational else "ssd"
    return "unknown"


def scan_storage_devices(sys_block: Path = SYS_BLOCK) -> list[StorageDevice]:
    devices: list[StorageDevice] = []
    if not sys_block.is_dir():
        return devices
    for entry in sorted(sys_block.iterdir()):
        name = entry.name
        if name.startswith(SKIP_BLOCK_PREFIXES) or name.startswith(("dm-", "md")):
            continue
        rotational = _read(entry / "queue" / "rotational", "0") == "1"
        removable = _read(entry / "removable", "0") == "1"
        try:
            size_bytes = int(_read(entry / "size", "0")) * 512
        except ValueError:
            size_bytes = 0
        if size_bytes == 0:
            continue
        model = _read(entry / "device" / "model") or _read(entry / "device" / "name")
        transport = ""
        try:
            resolved = os.path.realpath(entry / "device")
            if "/usb" in resolved:
                transport = "usb"
        except OSError:
            pass
        devices.append(
            StorageDevice(
                name=name,
                model=" ".join(model.split()),
                kind=classify_device(name, rotational, removable, transport),
                size_bytes=size_bytes,
                rotational=rotational,
                removable=removable,
            )
        )
    return devices
