"""CPU, memory, swap, load average and uptime."""

from __future__ import annotations

import os
import socket
import time
from pathlib import Path

import psutil

from observatory.models import CpuStats, LoadStats, MemoryStats, SwapStats
from observatory.util.rates import RateTracker

CPUINFO = Path("/proc/cpuinfo")


def parse_cpu_model(cpuinfo_text: str) -> str:
    """Extract a human CPU model name from /proc/cpuinfo contents.

    x86 exposes ``model name``; many ARM boards expose only ``Hardware`` or
    ``Model`` (e.g. "Raspberry Pi 4 Model B Rev 1.4") and per-core
    ``CPU part`` codes.
    """
    keys_in_priority = ("model name", "Model", "Hardware", "cpu model", "Processor")
    found: dict[str, str] = {}
    for line in cpuinfo_text.splitlines():
        if ":" not in line:
            continue
        key, _, value = line.partition(":")
        key = key.strip()
        value = value.strip()
        if key in keys_in_priority and value and key not in found:
            found[key] = value
    for key in keys_in_priority:
        if key in found:
            return " ".join(found[key].split())
    return ""


def read_cpu_model(path: Path = CPUINFO) -> str:
    try:
        model = parse_cpu_model(path.read_text(errors="replace"))
    except OSError:
        model = ""
    if not model:
        import platform

        model = platform.processor() or platform.machine() or "Unknown CPU"
    return model


class SystemCollector:
    """CPU, memory, swap, load and uptime in one pass."""

    def __init__(self) -> None:
        self._rates = RateTracker()
        self.cpu_model = read_cpu_model()
        self.cores_logical = psutil.cpu_count(logical=True) or 1
        self.cores_physical = psutil.cpu_count(logical=False) or self.cores_logical
        self.hostname = socket.gethostname()
        self.boot_time = psutil.boot_time()
        # Prime psutil's internal CPU counters so the first real call is meaningful.
        psutil.cpu_percent(percpu=True)
        psutil.cpu_times_percent()

    # ------------------------------------------------------------------ CPU
    def cpu(self) -> CpuStats:
        per_core = psutil.cpu_percent(percpu=True)
        total = sum(per_core) / len(per_core) if per_core else 0.0
        times = psutil.cpu_times_percent()
        freq_now = freq_max = 0.0
        try:
            freq = psutil.cpu_freq()
            if freq:
                freq_now = float(freq.current or 0.0)
                freq_max = float(freq.max or 0.0)
        except (OSError, NotImplementedError, FileNotFoundError):
            pass
        return CpuStats(
            percent=round(total, 2),
            per_core=[round(v, 1) for v in per_core],
            user=getattr(times, "user", 0.0),
            system=getattr(times, "system", 0.0),
            iowait=getattr(times, "iowait", 0.0),
            steal=getattr(times, "steal", 0.0),
            freq_mhz=freq_now,
            freq_max_mhz=freq_max,
            cores_logical=self.cores_logical,
            cores_physical=self.cores_physical,
            model=self.cpu_model,
        )

    # --------------------------------------------------------------- memory
    @staticmethod
    def memory() -> MemoryStats:
        vm = psutil.virtual_memory()
        return MemoryStats(
            total=vm.total,
            used=vm.total - vm.available,
            available=vm.available,
            percent=round(vm.percent, 2),
            cached=getattr(vm, "cached", 0),
            buffers=getattr(vm, "buffers", 0),
        )

    def swap(self) -> SwapStats:
        sw = psutil.swap_memory()
        now = time.monotonic()
        return SwapStats(
            total=sw.total,
            used=sw.used,
            percent=round(sw.percent, 2),
            sin_bps=self._rates.rate("swap_in", sw.sin, now),
            sout_bps=self._rates.rate("swap_out", sw.sout, now),
        )

    # ------------------------------------------------------------ load/uptime
    def load(self) -> LoadStats:
        try:
            l1, l5, l15 = os.getloadavg()
        except OSError:
            l1 = l5 = l15 = 0.0
        return LoadStats(load1=l1, load5=l5, load15=l15, cores=self.cores_logical)

    def uptime(self) -> float:
        return max(time.time() - self.boot_time, 0.0)
