"""Media stack awareness: detect Plex, Jellyfin, the *arr apps and qBittorrent,
and (when credentials are configured) read streams, queues, health and
transfer rates from their HTTP APIs.

Detection needs no configuration: containers are matched by image name,
host processes by name, and known ports by listening sockets. API polling
uses only the standard library and short timeouts, and runs from a
background thread via :meth:`MediaCollector.refresh`.
"""

from __future__ import annotations

import http.cookiejar
import json
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass, field
from typing import Any

import psutil

from observatory.models import ContainerInfo, ProcessInfo


@dataclass(frozen=True, slots=True)
class AppSpec:
    key: str
    name: str
    port: int
    images: tuple[str, ...]
    processes: tuple[str, ...]
    api: str  # plex | jellyfin | arr3 | arr1 | qbittorrent


APPS: tuple[AppSpec, ...] = (
    AppSpec("plex", "Plex", 32400, ("plex",), ("plex media server", "plexmediaserver"), "plex"),
    AppSpec("jellyfin", "Jellyfin", 8096, ("jellyfin",), ("jellyfin",), "jellyfin"),
    AppSpec("radarr", "Radarr", 7878, ("radarr",), ("radarr",), "arr3"),
    AppSpec("sonarr", "Sonarr", 8989, ("sonarr",), ("sonarr",), "arr3"),
    AppSpec("lidarr", "Lidarr", 8686, ("lidarr",), ("lidarr",), "arr1"),
    AppSpec("readarr", "Readarr", 8787, ("readarr",), ("readarr",), "arr1"),
    AppSpec("qbittorrent", "qBittorrent", 8080, ("qbittorrent",), ("qbittorrent", "qbittorrent-nox"), "qbittorrent"),
)
SPEC_BY_KEY = {s.key: s for s in APPS}
LIBRARY_ENDPOINT = {"radarr": "movie", "sonarr": "series", "lidarr": "artist", "readarr": "author"}


@dataclass(slots=True)
class Stream:
    user: str
    title: str
    state: str          # playing | paused | buffering
    transcode: bool
    bitrate_kbps: float | None = None
    hardware: bool | None = None


@dataclass(slots=True)
class QueueItem:
    title: str
    status: str
    progress: float     # 0..100


@dataclass(slots=True)
class MediaApp:
    key: str
    name: str
    detected_via: str = ""          # container | process | port | config
    container: str = ""
    container_state: str = ""
    container_health: str = ""
    url: str = ""
    configured: bool = False
    reachable: bool | None = None
    error: str = ""
    version: str = ""
    streams: list[Stream] = field(default_factory=list)
    queue: list[QueueItem] = field(default_factory=list)
    queue_total: int = 0
    health_issues: list[str] = field(default_factory=list)
    download_bps: float | None = None
    upload_bps: float | None = None
    active_torrents: int | None = None
    library_items: int | None = None
    library_bytes: int | None = None
    checked_at: float = 0.0

    @property
    def service_health(self) -> str:
        if self.container_state and self.container_state != "running":
            return "down"
        if self.container_health == "unhealthy" or self.reachable is False:
            return "unhealthy"
        if self.health_issues:
            return "warning"
        if self.reachable:
            return "healthy"
        return "detected"


def detect_apps(containers: list[ContainerInfo], processes: list[ProcessInfo],
                listening_ports: set[int] | None = None,
                configured: dict[str, str] | None = None) -> dict[str, MediaApp]:
    """Return media apps found on this host, keyed by AppSpec.key."""
    found: dict[str, MediaApp] = {}
    configured = configured or {}
    for spec in APPS:
        app: MediaApp | None = None
        for c in containers:
            image = c.image.lower()
            if any(token in image for token in spec.images) or c.name.lower() == spec.key:
                app = MediaApp(spec.key, spec.name, "container", container=c.name, container_state=c.state,
                               container_health=c.health)
                break
        if app is None:
            for p in processes:
                pname = p.name.lower()
                cmd = p.cmdline.lower()
                if any(token == pname or token in cmd.split("/")[-1] for token in spec.processes):
                    app = MediaApp(spec.key, spec.name, "process")
                    break
        if app is None and listening_ports and spec.port in listening_ports and spec.key != "qbittorrent":
            app = MediaApp(spec.key, spec.name, "port")
        if app is None and configured.get(spec.key):
            app = MediaApp(spec.key, spec.name, "config")
        if app is not None:
            app.url = configured.get(spec.key) or f"http://127.0.0.1:{spec.port}"
            found[spec.key] = app
    return found


def listening_ports() -> set[int]:
    try:
        return {c.laddr.port for c in psutil.net_connections(kind="tcp") if c.status == psutil.CONN_LISTEN}
    except (psutil.AccessDenied, PermissionError, OSError):
        return set()


# ----------------------------------------------------------------------- HTTP
class HttpClient:
    def __init__(self, timeout: float = 4.0) -> None:
        self.timeout = timeout
        self.cookies = http.cookiejar.CookieJar()
        self.opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(self.cookies))

    def request(self, url: str, headers: dict[str, str] | None = None, data: dict[str, str] | None = None) -> Any:
        body = urllib.parse.urlencode(data).encode() if data is not None else None
        req = urllib.request.Request(url, data=body, headers={"Accept": "application/json", **(headers or {})})
        with self.opener.open(req, timeout=self.timeout) as resp:
            raw = resp.read()
        text = raw.decode("utf-8", errors="replace")
        try:
            return json.loads(text)
        except ValueError:
            return text


# --------------------------------------------------------------- API parsing
def parse_plex_sessions(payload: dict[str, Any]) -> list[Stream]:
    streams = []
    for item in (payload.get("MediaContainer") or {}).get("Metadata", []) or []:
        title = item.get("title", "")
        if item.get("grandparentTitle"):
            title = f"{item['grandparentTitle']} — {title}"
        transcode = item.get("TranscodeSession")
        decision = (transcode or {}).get("videoDecision", "directplay")
        hw = None
        if transcode:
            hw = bool(transcode.get("transcodeHwRequested") or transcode.get("transcodeHwFullPipeline"))
        bitrate = (item.get("Session") or {}).get("bandwidth")
        streams.append(Stream(
            user=(item.get("User") or {}).get("title", "?"),
            title=title,
            state=(item.get("Player") or {}).get("state", "playing"),
            transcode=decision == "transcode",
            bitrate_kbps=float(bitrate) if bitrate else None,
            hardware=hw,
        ))
    return streams


def parse_jellyfin_sessions(payload: list[dict[str, Any]]) -> list[Stream]:
    streams = []
    for s in payload or []:
        item = s.get("NowPlayingItem")
        if not item:
            continue
        title = item.get("Name", "")
        if item.get("SeriesName"):
            title = f"{item['SeriesName']} — {title}"
        info = s.get("TranscodingInfo")
        paused = (s.get("PlayState") or {}).get("IsPaused", False)
        streams.append(Stream(
            user=s.get("UserName", "?"),
            title=title,
            state="paused" if paused else "playing",
            transcode=bool(info) and not info.get("IsVideoDirect", False),
            bitrate_kbps=(info or {}).get("Bitrate", 0) / 1000 if info and info.get("Bitrate") else None,
            hardware=bool(info.get("HardwareAccelerationType")) if info else None,
        ))
    return streams


def parse_arr_queue(payload: Any) -> tuple[list[QueueItem], int]:
    records = payload.get("records", []) if isinstance(payload, dict) else (payload or [])
    total = payload.get("totalRecords", len(records)) if isinstance(payload, dict) else len(records)
    items = []
    for r in records:
        size = float(r.get("size") or 0)
        left = float(r.get("sizeleft") or 0)
        progress = (1 - left / size) * 100 if size else 0.0
        status = r.get("trackedDownloadState") or r.get("status") or ""
        items.append(QueueItem(title=r.get("title", "?"), status=str(status), progress=round(progress, 1)))
    return items, int(total)


def parse_arr_library(payload: list[dict[str, Any]]) -> tuple[int, int]:
    total_bytes = 0
    for item in payload or []:
        stats = item.get("statistics") or {}
        total_bytes += int(item.get("sizeOnDisk") or stats.get("sizeOnDisk") or 0)
    return len(payload or []), total_bytes


class MediaCollector:
    """Detects media apps and polls the configured ones."""

    LIBRARY_EVERY = 1800.0

    def __init__(self, credentials: dict[str, dict[str, str]] | None = None, timeout: float = 4.0) -> None:
        self.credentials = credentials or {}
        self.timeout = timeout
        self.apps: dict[str, MediaApp] = {}
        self._clients: dict[str, HttpClient] = {}
        self._library_at: dict[str, float] = {}
        self._library_cache: dict[str, tuple[int, int]] = {}
        self._lock = threading.Lock()
        self.last_run = 0.0

    def update_credentials(self, credentials: dict[str, dict[str, str]]) -> None:
        self.credentials = credentials
        self._clients.clear()

    def _client(self, key: str) -> HttpClient:
        client = self._clients.get(key)
        if client is None:
            client = self._clients[key] = HttpClient(self.timeout)
        return client

    def refresh(self, containers: list[ContainerInfo], processes: list[ProcessInfo]) -> dict[str, MediaApp]:
        self.last_run = time.time()
        urls = {k: v.get("url", "") for k, v in self.credentials.items() if v.get("url")}
        apps = detect_apps(containers, processes, listening_ports(), urls)
        for key, app in apps.items():
            creds = self.credentials.get(key, {})
            secret = creds.get("api_key") or creds.get("token") or creds.get("password") or ""
            app.configured = bool(secret) or key == "qbittorrent"
            if app.configured and (app.container_state in ("", "running")):
                try:
                    self._poll(app, creds)
                    app.reachable = True
                except (urllib.error.URLError, OSError, ValueError, KeyError, TypeError) as exc:
                    app.reachable = False
                    app.error = _short_error(exc)
            app.checked_at = time.time()
        with self._lock:
            self.apps = apps
        return apps

    def snapshot(self) -> dict[str, MediaApp]:
        with self._lock:
            return dict(self.apps)

    # ---------------------------------------------------------------- polling
    def _poll(self, app: MediaApp, creds: dict[str, str]) -> None:
        spec = SPEC_BY_KEY[app.key]
        client = self._client(app.key)
        base = app.url.rstrip("/")
        if spec.api == "plex":
            headers = {"X-Plex-Token": creds.get("token", "")}
            ident = client.request(f"{base}/identity", headers)
            app.version = (ident.get("MediaContainer") or {}).get("version", "") if isinstance(ident, dict) else ""
            app.streams = parse_plex_sessions(client.request(f"{base}/status/sessions", headers))
        elif spec.api == "jellyfin":
            headers = {"X-Emby-Token": creds.get("api_key", "")}
            info = client.request(f"{base}/System/Info", headers)
            app.version = info.get("Version", "") if isinstance(info, dict) else ""
            app.streams = parse_jellyfin_sessions(client.request(f"{base}/Sessions", headers))
            counts = client.request(f"{base}/Items/Counts", headers)
            if isinstance(counts, dict):
                app.library_items = int(counts.get("MovieCount", 0)) + int(counts.get("EpisodeCount", 0)) + \
                    int(counts.get("SongCount", 0))
        elif spec.api in ("arr3", "arr1"):
            version = "v3" if spec.api == "arr3" else "v1"
            headers = {"X-Api-Key": creds.get("api_key", "")}
            status = client.request(f"{base}/api/{version}/system/status", headers)
            app.version = status.get("version", "") if isinstance(status, dict) else ""
            app.queue, app.queue_total = parse_arr_queue(
                client.request(f"{base}/api/{version}/queue?pageSize=20", headers))
            health = client.request(f"{base}/api/{version}/health", headers) or []
            app.health_issues = [h.get("message", "") for h in health if h.get("type") in ("warning", "error")]
            now = time.time()
            if now - self._library_at.get(app.key, 0) >= self.LIBRARY_EVERY:
                self._library_at[app.key] = now
                payload = client.request(f"{base}/api/{version}/{LIBRARY_ENDPOINT[app.key]}", headers)
                if isinstance(payload, list):
                    self._library_cache[app.key] = parse_arr_library(payload)
            if app.key in self._library_cache:
                app.library_items, app.library_bytes = self._library_cache[app.key]
        elif spec.api == "qbittorrent":
            if creds.get("username"):
                client.request(f"{base}/api/v2/auth/login", {"Referer": base},
                               {"username": creds.get("username", ""), "password": creds.get("password", "")})
            info = client.request(f"{base}/api/v2/transfer/info", {"Referer": base})
            if not isinstance(info, dict):
                raise ValueError("qBittorrent login required")
            app.download_bps = float(info.get("dl_info_speed", 0))
            app.upload_bps = float(info.get("up_info_speed", 0))
            active = client.request(f"{base}/api/v2/torrents/info?filter=active", {"Referer": base})
            app.active_torrents = len(active) if isinstance(active, list) else None
            downloading = client.request(f"{base}/api/v2/torrents/info?filter=downloading", {"Referer": base})
            if isinstance(downloading, list):
                app.queue = [QueueItem(t.get("name", "?"), t.get("state", ""), round(float(t.get("progress", 0)) * 100, 1))
                             for t in downloading[:20]]
                app.queue_total = len(downloading)
            version = client.request(f"{base}/api/v2/app/version", {"Referer": base})
            app.version = version if isinstance(version, str) else ""


def _short_error(exc: Exception) -> str:
    if isinstance(exc, urllib.error.HTTPError):
        if exc.code in (401, 403):
            return "authentication failed — check the API key"
        return f"HTTP {exc.code}"
    if isinstance(exc, urllib.error.URLError):
        return f"unreachable ({exc.reason})"
    return str(exc)[:80]
