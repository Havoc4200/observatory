"""SMART drive health via ``smartctl --json`` (smartmontools 7+).

Requires root (or CAP_SYS_RAWIO) and smartmontools. Drives in standby are not
woken (``-n standby``). Results are cached; call :meth:`SmartCollector.refresh`
from a background thread.

Health score (0-100) starts at 100 and subtracts capped penalties driven by
the attributes Backblaze's published fleet data found most predictive of
failure (5, 187, 188, 197, 198), NVMe wear/spare/media errors, temperature
and age. A failed overall SMART self-assessment caps the score at 10.
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import threading
import time
from dataclasses import dataclass, field
from typing import Any

ATTR_REALLOCATED = 5
ATTR_REPORTED_UNCORRECT = 187
ATTR_COMMAND_TIMEOUT = 188
ATTR_PENDING = 197
ATTR_OFFLINE_UNCORRECT = 198
ATTR_CRC = 199


@dataclass(slots=True)
class SmartInfo:
    device: str
    model: str = ""
    serial: str = ""
    kind: str = ""                 # ata | nvme | scsi
    passed: bool | None = None
    temperature_c: float | None = None
    power_on_hours: int | None = None
    reallocated: int = 0
    pending: int = 0
    offline_uncorrectable: int = 0
    reported_uncorrectable: int = 0
    command_timeouts: int = 0
    crc_errors: int = 0
    nvme_percentage_used: int | None = None
    nvme_available_spare: int | None = None
    nvme_spare_threshold: int | None = None
    nvme_media_errors: int = 0
    nvme_critical_warning: int = 0
    standby: bool = False
    health_score: int = 100
    risk: str = "low"              # low | elevated | high | critical | unknown
    reasons: list[str] = field(default_factory=list)
    checked_at: float = 0.0

    @property
    def age_years(self) -> float | None:
        return self.power_on_hours / 8766 if self.power_on_hours is not None else None

    @property
    def status(self) -> str:
        if self.standby:
            return "standby"
        if self.passed is False:
            return "FAILED"
        if self.passed is None:
            return "unknown"
        return "PASSED"


def _ata_raw(data: dict[str, Any], attr_id: int) -> int:
    for entry in (data.get("ata_smart_attributes") or {}).get("table", []) or []:
        if entry.get("id") == attr_id:
            raw = entry.get("raw") or {}
            value = raw.get("value", 0)
            try:
                # Some vendors pack extra counters in the high bytes; the low 32 bits hold the count.
                return int(value) & 0xFFFFFFFF
            except (TypeError, ValueError):
                return 0
    return 0


def parse_smartctl(device: str, data: dict[str, Any]) -> SmartInfo:
    info = SmartInfo(device=device, checked_at=time.time())
    info.model = data.get("model_name") or data.get("scsi_model_name") or ""
    info.serial = data.get("serial_number") or ""
    dev = data.get("device") or {}
    info.kind = (dev.get("protocol") or dev.get("type") or "").lower()
    status = data.get("smart_status")
    if isinstance(status, dict) and "passed" in status:
        info.passed = bool(status["passed"])
    temp = (data.get("temperature") or {}).get("current")
    if temp is not None:
        info.temperature_c = float(temp)
    poh = (data.get("power_on_time") or {}).get("hours")
    if poh is not None:
        info.power_on_hours = int(poh)
    if "ata_smart_attributes" in data:
        info.reallocated = _ata_raw(data, ATTR_REALLOCATED)
        info.pending = _ata_raw(data, ATTR_PENDING)
        info.offline_uncorrectable = _ata_raw(data, ATTR_OFFLINE_UNCORRECT)
        info.reported_uncorrectable = _ata_raw(data, ATTR_REPORTED_UNCORRECT)
        info.command_timeouts = _ata_raw(data, ATTR_COMMAND_TIMEOUT)
        info.crc_errors = _ata_raw(data, ATTR_CRC)
    nvme = data.get("nvme_smart_health_information_log")
    if nvme:
        info.kind = "nvme"
        info.nvme_percentage_used = nvme.get("percentage_used")
        info.nvme_available_spare = nvme.get("available_spare")
        info.nvme_spare_threshold = nvme.get("available_spare_threshold")
        info.nvme_media_errors = int(nvme.get("media_errors") or 0)
        info.nvme_critical_warning = int(nvme.get("critical_warning") or 0)
        if info.temperature_c is None and nvme.get("temperature") is not None:
            info.temperature_c = float(nvme["temperature"])
    score_drive(info)
    return info


def score_drive(info: SmartInfo, warn_temp: float = 55.0) -> SmartInfo:
    score = 100.0
    reasons: list[str] = []

    def take(amount: float, cap: float, reason: str) -> None:
        nonlocal score
        amount = min(amount, cap)
        if amount > 0:
            score -= amount
            reasons.append(reason)

    take(info.reallocated * 2, 30, f"{info.reallocated} reallocated sectors")
    take(info.reported_uncorrectable * 10, 30, f"{info.reported_uncorrectable} reported uncorrectable errors")
    take(info.command_timeouts / 10, 10, f"{info.command_timeouts} command timeouts")
    take(info.pending * 5, 35, f"{info.pending} pending sectors")
    take(info.offline_uncorrectable * 5, 35, f"{info.offline_uncorrectable} offline uncorrectable sectors")
    take(info.crc_errors / 50, 10, f"{info.crc_errors} CRC errors (check the cable)")
    if info.nvme_percentage_used is not None and info.nvme_percentage_used > 50:
        take((info.nvme_percentage_used - 50) * 0.4, 30, f"{info.nvme_percentage_used}% of rated endurance used")
    take(info.nvme_media_errors * 10, 40, f"{info.nvme_media_errors} NVMe media errors")
    if info.temperature_c is not None and info.temperature_c >= warn_temp:
        take(5, 5, f"running hot ({info.temperature_c:.0f}°C)")
    years = info.age_years
    if years is not None and info.kind != "nvme" and years > 5:
        take(years - 5, 10, f"{years:.1f} years powered on")

    hard_fail = False
    if info.passed is False:
        hard_fail = True
        reasons.insert(0, "SMART overall self-assessment FAILED")
    if info.nvme_critical_warning & ~0x02:  # any bit except the temperature warning
        hard_fail = True
        reasons.insert(0, f"NVMe critical warning 0x{info.nvme_critical_warning:02x}")
    if (info.nvme_available_spare is not None and info.nvme_spare_threshold is not None
            and info.nvme_available_spare < info.nvme_spare_threshold):
        hard_fail = True
        reasons.insert(0, "NVMe spare capacity below threshold")
    if hard_fail:
        score = min(score, 10)

    info.health_score = int(round(max(score, 0)))
    if info.passed is None and not info.reasons and info.kind == "":
        info.risk = "unknown"
    elif info.health_score <= 20:
        info.risk = "critical"
    elif info.health_score <= 50 or info.pending or info.offline_uncorrectable:
        info.risk = "high"
    elif info.health_score <= 80 or info.reallocated:
        info.risk = "elevated"
    else:
        info.risk = "low"
    info.reasons = reasons
    return info


class SmartCollector:
    """Background SMART polling with a cache keyed by device name."""

    def __init__(self, interval: float = 1800.0) -> None:
        self.interval = interval
        self.binary = shutil.which("smartctl")
        self.results: dict[str, SmartInfo] = {}
        self.error = ""
        self.last_run = 0.0
        self._lock = threading.Lock()
        if self.binary is None:
            self.error = "smartmontools not installed"
        elif os.geteuid() != 0:
            self.error = "SMART needs root (the Observatory service collects it)"

    @property
    def available(self) -> bool:
        return self.binary is not None and os.geteuid() == 0

    def due(self, now: float | None = None) -> bool:
        now = now if now is not None else time.time()
        return self.available and now - self.last_run >= self.interval

    def refresh(self, devices: list[str]) -> dict[str, SmartInfo]:
        if not self.available:
            return self.results
        self.last_run = time.time()
        results: dict[str, SmartInfo] = {}
        for name in devices:
            if name.startswith(("vd", "xvd", "loop", "dm-", "md", "zram", "sr")):
                continue
            path = f"/dev/{name}"
            try:
                proc = subprocess.run([self.binary, "--json", "-a", "-n", "standby", path],
                                      capture_output=True, text=True, timeout=20, check=False)
            except (OSError, subprocess.TimeoutExpired):
                continue
            # Exit bit 1 (value 2) = device open failed; standby makes smartctl exit with 2 as well.
            try:
                data = json.loads(proc.stdout or "{}")
            except ValueError:
                continue
            messages = " ".join(m.get("string", "") for m in (data.get("smartctl") or {}).get("messages", []) or [])
            if "STANDBY" in messages.upper():
                previous = self.results.get(name)
                info = previous or SmartInfo(device=name)
                info.standby = True
                results[name] = info
                continue
            if not data.get("device") and proc.returncode & 0x2:
                continue
            results[name] = parse_smartctl(name, data)
        with self._lock:
            self.results = results
        return results

    def snapshot(self) -> dict[str, SmartInfo]:
        with self._lock:
            return dict(self.results)
