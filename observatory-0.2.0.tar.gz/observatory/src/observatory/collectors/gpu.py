"""GPU metrics: NVIDIA via nvidia-smi, AMD via amdgpu sysfs, Intel listed by name.

nvidia-smi is called with a strict timeout; if it is missing or fails, it is
not retried for a back-off period so a broken driver never stalls the UI.
"""

from __future__ import annotations

import shutil
import subprocess
import time
from pathlib import Path

from observatory.models import GpuStats
from observatory.util.pci import pci_name

SYS_DRM = Path("/sys/class/drm")
NVIDIA_QUERY = "index,name,utilization.gpu,memory.used,memory.total,temperature.gpu,power.draw,power.limit"


def _num(text: str) -> float | None:
    text = text.strip()
    if not text or text.startswith("[") or text.lower() in {"n/a", "not supported"}:
        return None
    try:
        return float(text)
    except ValueError:
        return None


def parse_nvidia_smi(output: str) -> list[GpuStats]:
    gpus: list[GpuStats] = []
    for line in output.strip().splitlines():
        parts = [p.strip() for p in line.split(",")]
        if len(parts) < 8:
            continue
        index = _num(parts[0])
        mem_used = _num(parts[3])
        mem_total = _num(parts[4])
        gpus.append(
            GpuStats(
                index=int(index) if index is not None else len(gpus),
                name=parts[1],
                vendor="NVIDIA",
                util_percent=_num(parts[2]),
                mem_used=int(mem_used * 1024 * 1024) if mem_used is not None else None,
                mem_total=int(mem_total * 1024 * 1024) if mem_total is not None else None,
                temp_c=_num(parts[5]),
                power_w=_num(parts[6]),
                power_limit_w=_num(parts[7]),
            )
        )
    return gpus


def _read_int(path: Path) -> int | None:
    try:
        return int(path.read_text().strip())
    except (OSError, ValueError):
        return None


class GpuCollector:
    def __init__(self, sys_drm: Path = SYS_DRM, backoff: float = 120.0) -> None:
        self._sys_drm = sys_drm
        self._backoff = backoff
        self._nvidia_bin = shutil.which("nvidia-smi")
        self._nvidia_retry_at = 0.0

    # ---------------------------------------------------------------- NVIDIA
    def _nvidia(self) -> list[GpuStats]:
        if not self._nvidia_bin or time.monotonic() < self._nvidia_retry_at:
            return []
        try:
            proc = subprocess.run(
                [self._nvidia_bin, f"--query-gpu={NVIDIA_QUERY}", "--format=csv,noheader,nounits"],
                capture_output=True,
                text=True,
                timeout=2.0,
                check=False,
            )
        except (OSError, subprocess.TimeoutExpired):
            self._nvidia_retry_at = time.monotonic() + self._backoff
            return []
        if proc.returncode != 0:
            self._nvidia_retry_at = time.monotonic() + self._backoff
            return []
        return parse_nvidia_smi(proc.stdout)

    # ------------------------------------------------------------ AMD/Intel
    def _sysfs_cards(self) -> list[GpuStats]:
        gpus: list[GpuStats] = []
        if not self._sys_drm.is_dir():
            return gpus
        for card in sorted(self._sys_drm.glob("card[0-9]*")):
            if "-" in card.name:  # connectors like card0-HDMI-A-1
                continue
            device = card / "device"
            try:
                vendor = (device / "vendor").read_text().strip().lower().removeprefix("0x")
                device_id = (device / "device").read_text().strip().lower().removeprefix("0x")
            except OSError:
                continue
            if vendor == "1002":
                gpus.append(self._amd(card.name, device, device_id))
            elif vendor == "8086":
                gpus.append(GpuStats(index=len(gpus), name=pci_name(vendor, device_id), vendor="Intel"))
        return gpus

    @staticmethod
    def _amd(card: str, device: Path, device_id: str) -> GpuStats:
        util = _read_int(device / "gpu_busy_percent")
        vram_used = _read_int(device / "mem_info_vram_used")
        vram_total = _read_int(device / "mem_info_vram_total")
        temp = power = power_cap = None
        for hwmon in sorted((device / "hwmon").glob("hwmon*")):
            t = _read_int(hwmon / "temp1_input")
            if t is not None:
                temp = t / 1000.0
            p = _read_int(hwmon / "power1_average")
            if p is None:
                p = _read_int(hwmon / "power1_input")
            if p is not None:
                power = p / 1_000_000.0
            cap = _read_int(hwmon / "power1_cap")
            if cap is not None:
                power_cap = cap / 1_000_000.0
        return GpuStats(
            index=int(card.removeprefix("card") or 0),
            name=pci_name("1002", device_id),
            vendor="AMD",
            util_percent=float(util) if util is not None else None,
            mem_used=vram_used,
            mem_total=vram_total,
            temp_c=temp,
            power_w=power,
            power_limit_w=power_cap,
        )

    def collect(self) -> list[GpuStats]:
        gpus = self._nvidia()
        gpus.extend(self._sysfs_cards())
        for i, gpu in enumerate(gpus):
            gpu.index = i
        return gpus
