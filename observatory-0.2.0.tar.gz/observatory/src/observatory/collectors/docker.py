"""Minimal Docker Engine API client over the unix socket (stdlib only) and a
container collector that turns raw stats into rates and percentages.

Only the endpoints Observatory needs are implemented:
``/_ping``, ``/containers/json``, ``/containers/{id}/json``,
``/containers/{id}/stats`` and the start/stop/restart actions.
"""

from __future__ import annotations

import http.client
import json
import os
import socket
import time
from concurrent.futures import ThreadPoolExecutor
from typing import Any
from urllib.parse import quote, urlencode

from observatory.models import ContainerInfo
from observatory.util.rates import RateTracker

API_VERSION = "v1.41"  # Docker 20.10+; the daemon accepts older API versions too


class DockerError(Exception):
    """Raised for any Docker API or socket failure, with a user-facing message."""


class UnixHTTPConnection(http.client.HTTPConnection):
    def __init__(self, socket_path: str, timeout: float = 3.0) -> None:
        super().__init__("localhost", timeout=timeout)
        self.socket_path = socket_path

    def connect(self) -> None:  # pragma: no cover - exercised against a real daemon
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sock.settimeout(self.timeout)
        sock.connect(self.socket_path)
        self.sock = sock


def socket_from_env(default: str) -> str:
    host = os.environ.get("DOCKER_HOST", "")
    if host.startswith("unix://"):
        return host.removeprefix("unix://")
    return default


class DockerClient:
    def __init__(self, socket_path: str = "/var/run/docker.sock", timeout: float = 3.0) -> None:
        self.socket_path = socket_from_env(socket_path)
        self.timeout = timeout

    # ------------------------------------------------------------- transport
    def _request(self, method: str, path: str, params: dict[str, Any] | None = None,
                 timeout: float | None = None) -> Any:
        if not os.path.exists(self.socket_path):
            raise DockerError(f"Docker socket not found at {self.socket_path}")
        url = f"/{API_VERSION}{path}"
        if params:
            url += "?" + urlencode(params)
        conn = UnixHTTPConnection(self.socket_path, timeout=timeout or self.timeout)
        try:
            conn.request(method, url, headers={"Host": "docker", "Accept": "application/json"})
            response = conn.getresponse()
            body = response.read()
        except PermissionError as exc:
            raise DockerError(
                f"Permission denied on {self.socket_path}. Add your user to the 'docker' group "
                "(sudo usermod -aG docker $USER) or run with sudo."
            ) from exc
        except (OSError, http.client.HTTPException) as exc:
            raise DockerError(f"Docker API error: {exc}") from exc
        finally:
            conn.close()
        if response.status >= 400:
            message = body.decode(errors="replace")
            try:
                message = json.loads(message).get("message", message)
            except (ValueError, AttributeError):
                pass
            raise DockerError(f"Docker API {response.status}: {message}")
        if not body:
            return None
        try:
            return json.loads(body)
        except ValueError:
            return body.decode(errors="replace")

    # -------------------------------------------------------------- queries
    def ping(self) -> bool:
        """Return True when the daemon answers; raise DockerError otherwise."""
        self._request("GET", "/_ping")
        return True

    def containers(self, all_: bool = True) -> list[dict[str, Any]]:
        return self._request("GET", "/containers/json", {"all": "1" if all_ else "0"}) or []

    def inspect(self, container_id: str) -> dict[str, Any]:
        return self._request("GET", f"/containers/{quote(container_id)}/json") or {}

    def stats(self, container_id: str) -> dict[str, Any]:
        return self._request(
            "GET", f"/containers/{quote(container_id)}/stats", {"stream": "false", "one-shot": "true"}
        ) or {}

    # -------------------------------------------------------------- actions
    def restart(self, container_id: str, timeout_s: int = 10) -> None:
        self._request("POST", f"/containers/{quote(container_id)}/restart", {"t": timeout_s},
                      timeout=timeout_s + self.timeout + 5)

    def start(self, container_id: str) -> None:
        self._request("POST", f"/containers/{quote(container_id)}/start", timeout=self.timeout + 10)

    def stop(self, container_id: str, timeout_s: int = 10) -> None:
        self._request("POST", f"/containers/{quote(container_id)}/stop", {"t": timeout_s},
                      timeout=timeout_s + self.timeout + 5)


# ------------------------------------------------------------------ parsing
def health_from_status(status: str) -> str:
    lowered = status.lower()
    if "(unhealthy)" in lowered:
        return "unhealthy"
    if "(healthy)" in lowered:
        return "healthy"
    if "health: starting" in lowered:
        return "starting"
    return ""


def format_ports(ports: list[dict[str, Any]] | None) -> str:
    if not ports:
        return ""
    seen: list[str] = []
    for p in ports:
        public = p.get("PublicPort")
        private = p.get("PrivatePort")
        proto = p.get("Type", "tcp")
        text = f"{public}->{private}/{proto}" if public else f"{private}/{proto}"
        if text not in seen:
            seen.append(text)
    return ", ".join(seen)


def memory_usage(stats: dict[str, Any]) -> tuple[int, int]:
    """Return (usage_without_page_cache, limit) like ``docker stats`` does."""
    mem = stats.get("memory_stats") or {}
    usage = int(mem.get("usage") or 0)
    detail = mem.get("stats") or {}
    cache = detail.get("inactive_file")  # cgroup v2
    if cache is None:
        cache = detail.get("total_inactive_file", detail.get("cache", 0))  # cgroup v1
    usage = max(usage - int(cache or 0), 0)
    return usage, int(mem.get("limit") or 0)


def network_totals(stats: dict[str, Any]) -> tuple[int, int]:
    rx = tx = 0
    for net in (stats.get("networks") or {}).values():
        rx += int(net.get("rx_bytes") or 0)
        tx += int(net.get("tx_bytes") or 0)
    return rx, tx


def cpu_counters(stats: dict[str, Any]) -> tuple[int, int, int]:
    cpu = stats.get("cpu_stats") or {}
    total = int((cpu.get("cpu_usage") or {}).get("total_usage") or 0)
    system = int(cpu.get("system_cpu_usage") or 0)
    online = int(cpu.get("online_cpus") or len((cpu.get("cpu_usage") or {}).get("percpu_usage") or []) or 1)
    return total, system, online


class DockerCollector:
    """Polls container inventory and stats; remembers counters to compute rates."""

    INSPECT_TTL = 30.0

    def __init__(self, client: DockerClient, workers: int = 6) -> None:
        self.client = client
        self._rates = RateTracker()
        self._cpu_prev: dict[str, tuple[int, int]] = {}
        self._inspect_cache: dict[str, tuple[float, dict[str, Any]]] = {}
        self._pool = ThreadPoolExecutor(max_workers=workers, thread_name_prefix="obs-docker")
        self.last_error = ""

    def close(self) -> None:
        self._pool.shutdown(wait=False, cancel_futures=True)

    def _inspect_cached(self, cid: str, state: str) -> dict[str, Any]:
        cached = self._inspect_cache.get(cid)
        now = time.monotonic()
        if cached and now - cached[0] < self.INSPECT_TTL and cached[1].get("_state") == state:
            return cached[1]
        try:
            data = self.client.inspect(cid)
        except DockerError:
            return cached[1] if cached else {}
        data["_state"] = state
        self._inspect_cache[cid] = (now, data)
        return data

    def _stats_safe(self, cid: str) -> dict[str, Any]:
        try:
            return self.client.stats(cid)
        except DockerError:
            return {}

    def collect(self) -> tuple[list[ContainerInfo], bool, str]:
        """Return (containers, docker_available, error_message)."""
        try:
            raw = self.client.containers(all_=True)
        except DockerError as exc:
            self.last_error = str(exc)
            return [], False, self.last_error
        self.last_error = ""
        running_ids = [c["Id"] for c in raw if c.get("State") == "running"]
        stats_by_id = dict(zip(running_ids, self._pool.map(self._stats_safe, running_ids)))
        now = time.monotonic()
        containers: list[ContainerInfo] = []
        live_keys: set = set()
        for c in raw:
            cid = c.get("Id", "")
            state = c.get("State", "")
            names = c.get("Names") or [cid[:12]]
            labels = c.get("Labels") or {}
            info = ContainerInfo(
                id=cid,
                name=names[0].lstrip("/"),
                image=c.get("Image", ""),
                state=state,
                status=c.get("Status", ""),
                health=health_from_status(c.get("Status", "")),
                compose_project=labels.get("com.docker.compose.project", ""),
                ports=format_ports(c.get("Ports")),
            )
            inspect = self._inspect_cached(cid, state)
            info.restart_count = int(inspect.get("RestartCount") or 0)
            info.started_at = (inspect.get("State") or {}).get("StartedAt", "")
            health = ((inspect.get("State") or {}).get("Health") or {}).get("Status")
            if health:
                info.health = health
            stats = stats_by_id.get(cid)
            if stats:
                total, system, online = cpu_counters(stats)
                prev = self._cpu_prev.get(cid)
                self._cpu_prev[cid] = (total, system)
                if prev and system > prev[1] and total >= prev[0]:
                    info.cpu_percent = round((total - prev[0]) / (system - prev[1]) * online * 100.0, 2)
                usage, limit = memory_usage(stats)
                info.mem_usage = usage
                info.mem_limit = limit
                info.mem_percent = round(usage / limit * 100.0, 2) if limit else 0.0
                rx, tx = network_totals(stats)
                info.net_rx_bps = self._rates.rate((cid, "rx"), rx, now)
                info.net_tx_bps = self._rates.rate((cid, "tx"), tx, now)
                live_keys.update({(cid, "rx"), (cid, "tx")})
            containers.append(info)
        self._rates.forget_missing(live_keys)
        live_ids = {c.id for c in containers}
        for cid in list(self._cpu_prev):
            if cid not in live_ids:
                del self._cpu_prev[cid]
        for cid in list(self._inspect_cache):
            if cid not in live_ids:
                del self._inspect_cache[cid]
        containers.sort(key=lambda c: (c.state != "running", c.name))
        return containers, True, ""

    # ---------------------------------------------------------- actions
    def act(self, action: str, container_id: str) -> tuple[bool, str]:
        try:
            if action == "restart":
                self.client.restart(container_id)
            elif action == "start":
                self.client.start(container_id)
            elif action == "stop":
                self.client.stop(container_id)
            else:
                return False, f"Unknown action {action!r}"
        except DockerError as exc:
            return False, str(exc)
        self._inspect_cache.pop(container_id, None)
        return True, f"{action.capitalize()} sent to {container_id[:12]}."
