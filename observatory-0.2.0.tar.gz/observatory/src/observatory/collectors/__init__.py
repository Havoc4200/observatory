"""Collectors read the kernel (via psutil, /proc and /sys) and external tools.

Each collector is a small stateful object: it keeps whatever previous counter
values it needs to turn counters into rates, and returns plain dataclasses
from :mod:`observatory.models`. Collectors never raise for missing hardware;
they return empty results instead.
"""
