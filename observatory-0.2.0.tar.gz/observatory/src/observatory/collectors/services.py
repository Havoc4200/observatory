"""systemd service summary: how many services run, which ones failed, and
whether the host is waiting for a reboot.

``systemctl list-units`` works without root. Called from a background job.
"""

from __future__ import annotations

import shutil
import subprocess
import time
from dataclasses import dataclass, field
from pathlib import Path

REBOOT_FLAG = Path("/var/run/reboot-required")
REBOOT_PKGS = Path("/var/run/reboot-required.pkgs")


@dataclass(slots=True)
class FailedUnit:
    name: str
    description: str


@dataclass(slots=True)
class ServiceSummary:
    available: bool = False
    running: int = 0
    total: int = 0
    failed: list[FailedUnit] = field(default_factory=list)
    reboot_required: bool = False
    reboot_packages: list[str] = field(default_factory=list)
    checked_at: float = 0.0
    error: str = ""

    @property
    def failed_count(self) -> int:
        return len(self.failed)


def parse_list_units(output: str) -> tuple[int, int, list[FailedUnit]]:
    """Parse ``systemctl list-units --type=service --all --no-legend --plain``.

    Columns: UNIT LOAD ACTIVE SUB DESCRIPTION...
    """
    running = total = 0
    failed: list[FailedUnit] = []
    for line in output.splitlines():
        parts = line.split(None, 4)
        if len(parts) < 4 or not parts[0].endswith(".service"):
            continue
        unit, load, active, sub = parts[:4]
        if load == "not-found":
            continue
        total += 1
        if sub == "running":
            running += 1
        if active == "failed":
            failed.append(FailedUnit(unit.removesuffix(".service"), parts[4].strip() if len(parts) > 4 else ""))
    return running, total, failed


class ServiceCollector:
    def __init__(self, interval: float = 60.0) -> None:
        self.interval = interval
        self.binary = shutil.which("systemctl")
        self.summary = ServiceSummary()

    def due(self, now: float | None = None) -> bool:
        now = now if now is not None else time.time()
        return now - self.summary.checked_at >= self.interval

    def refresh(self) -> ServiceSummary:
        summary = ServiceSummary(checked_at=time.time())
        summary.reboot_required = REBOOT_FLAG.exists()
        if summary.reboot_required:
            try:
                summary.reboot_packages = sorted(set(REBOOT_PKGS.read_text().split()))
            except OSError:
                pass
        if self.binary is None or not Path("/run/systemd/system").exists():
            summary.error = "systemd not running"
            self.summary = summary
            return summary
        try:
            proc = subprocess.run(
                [self.binary, "list-units", "--type=service", "--all", "--no-legend", "--plain", "--no-pager"],
                capture_output=True, text=True, timeout=10, check=False,
            )
        except (OSError, subprocess.TimeoutExpired) as exc:
            summary.error = str(exc)
            self.summary = summary
            return summary
        if proc.returncode == 0:
            summary.running, summary.total, summary.failed = parse_list_units(proc.stdout)
            summary.available = True
        else:
            summary.error = (proc.stderr or "systemctl failed").strip()[:120]
        self.summary = summary
        return summary
