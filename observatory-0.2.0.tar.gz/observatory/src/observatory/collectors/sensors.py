"""Temperature sensors via hwmon (psutil.sensors_temperatures)."""

from __future__ import annotations

import psutil

from observatory.models import TempReading

CPU_CHIPS = {"coretemp", "k10temp", "zenpower", "cpu_thermal", "cpu-thermal", "soc_thermal",
             "x86_pkg_temp", "cpu", "soc-thermal", "armada_thermal"}
GPU_CHIPS = {"amdgpu", "radeon", "nouveau", "i915", "xe", "gpu_thermal", "gpu-thermal"}
DRIVE_CHIPS = {"nvme", "drivetemp"}
BOARD_PREFIXES = ("acpitz", "pch_", "nct", "it87", "it86", "f71", "w83", "asus", "thinkpad",
                  "dell_smm", "gigabyte", "iwlwifi", "mt79", "ath1")

# Readings outside this window are sensor glitches or unconnected inputs.
MIN_VALID_C = 1.0
MAX_VALID_C = 150.0


def classify_chip(chip: str) -> str:
    lowered = chip.lower()
    if lowered in CPU_CHIPS:
        return "cpu"
    if lowered in GPU_CHIPS:
        return "gpu"
    if lowered in DRIVE_CHIPS or lowered.startswith("nvme"):
        return "drive"
    if lowered.startswith(BOARD_PREFIXES):
        return "board"
    return "other"


def _valid_threshold(value: float | None) -> float | None:
    if value is None or value <= 0 or value > 200:
        return None
    return float(value)


def normalize(raw: dict) -> list[TempReading]:
    """Convert psutil's ``{chip: [shwtemp...]}`` into TempReading objects.

    Duplicated chips (e.g. one ``nvme`` entry per drive) get a numeric suffix
    so every reading has a unique name.
    """
    readings: list[TempReading] = []
    chip_counts: dict[str, int] = {}
    for chip, entries in raw.items():
        chip_counts[chip] = chip_counts.get(chip, 0) + 1
        chip_name = chip if chip_counts[chip] == 1 else f"{chip}{chip_counts[chip] - 1}"
        kind = classify_chip(chip)
        for index, entry in enumerate(entries):
            current = getattr(entry, "current", None)
            if current is None or not (MIN_VALID_C <= current <= MAX_VALID_C):
                continue
            label = (getattr(entry, "label", "") or "").strip() or (f"temp{index + 1}" if len(entries) > 1 else "")
            readings.append(
                TempReading(
                    chip=chip_name,
                    label=label,
                    current=round(float(current), 1),
                    high=_valid_threshold(getattr(entry, "high", None)),
                    critical=_valid_threshold(getattr(entry, "critical", None)),
                    kind=kind,
                )
            )
    return readings


class SensorCollector:
    def __init__(self) -> None:
        self.available = hasattr(psutil, "sensors_temperatures")

    def collect(self) -> list[TempReading]:
        if not self.available:
            return []
        try:
            raw = psutil.sensors_temperatures(fahrenheit=False) or {}
        except (OSError, RuntimeError, ValueError):
            return []
        return normalize(raw)


def cpu_package_temp(readings: list[TempReading]) -> float | None:
    """Best single CPU temperature: package/Tctl reading if present, else max core."""
    cpu = [r for r in readings if r.kind == "cpu"]
    if not cpu:
        return None
    for preferred in ("package", "tctl", "tdie"):
        for r in cpu:
            if r.label.lower().startswith(preferred):
                return r.current
    return max(r.current for r in cpu)
