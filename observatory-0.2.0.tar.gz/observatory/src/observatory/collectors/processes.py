"""Process listing and process control (terminate / kill)."""

from __future__ import annotations

import os
import signal

import psutil

from observatory.models import ProcessInfo

ATTRS = [
    "pid", "name", "username", "cpu_percent", "memory_percent", "memory_info",
    "num_threads", "status", "cmdline", "create_time",
]


class ProcessCollector:
    def __init__(self) -> None:
        # Prime per-process CPU counters; psutil caches Process objects across
        # process_iter() calls so the next call returns real percentages.
        for _ in psutil.process_iter(["cpu_percent"]):
            pass

    def collect(self, limit: int = 0) -> tuple[list[ProcessInfo], int]:
        """Return (processes, total_count). ``limit`` keeps the top N by CPU+RSS."""
        procs: list[ProcessInfo] = []
        for proc in psutil.process_iter(ATTRS, ad_value=None):
            info = proc.info
            mem = info.get("memory_info")
            cmdline = info.get("cmdline") or []
            name = info.get("name") or "?"
            procs.append(
                ProcessInfo(
                    pid=info["pid"],
                    name=name,
                    username=info.get("username") or "",
                    cpu_percent=float(info.get("cpu_percent") or 0.0),
                    memory_percent=float(info.get("memory_percent") or 0.0),
                    rss=int(mem.rss) if mem else 0,
                    threads=int(info.get("num_threads") or 0),
                    status=info.get("status") or "",
                    cmdline=" ".join(cmdline) if cmdline else f"[{name}]",
                    create_time=float(info.get("create_time") or 0.0),
                )
            )
        total = len(procs)
        if limit and total > limit:
            by_cpu = sorted(procs, key=lambda p: p.cpu_percent, reverse=True)[: limit // 2]
            by_mem = sorted(procs, key=lambda p: p.rss, reverse=True)[: limit // 2]
            merged = {p.pid: p for p in by_cpu + by_mem}
            procs = list(merged.values())
        return procs, total


def is_kernel_thread(p: ProcessInfo) -> bool:
    return p.cmdline.startswith("[") and p.rss == 0


def kill_process(pid: int, force: bool = False) -> tuple[bool, str]:
    """Send SIGTERM (or SIGKILL when ``force``) to ``pid``.

    Refuses PID 1 and Observatory itself. Returns (ok, human message).
    """
    if pid <= 1:
        return False, "Refusing to signal PID 0/1 (init)."
    if pid == os.getpid():
        return False, "Refusing to kill Observatory itself."
    sig = signal.SIGKILL if force else signal.SIGTERM
    try:
        proc = psutil.Process(pid)
        name = proc.name()
        proc.send_signal(sig)
    except psutil.NoSuchProcess:
        return False, f"Process {pid} no longer exists."
    except psutil.AccessDenied:
        return False, f"Permission denied signalling PID {pid}; run Observatory with sudo to manage other users' processes."
    except (OSError, ValueError) as exc:
        return False, f"Failed to signal PID {pid}: {exc}"
    verb = "Killed" if force else "Sent SIGTERM to"
    return True, f"{verb} {name} (PID {pid})."
