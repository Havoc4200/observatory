"""Network interface throughput, totals, errors and addresses."""

from __future__ import annotations

import socket
import time
from pathlib import Path

import psutil

from observatory.models import NetInterface
from observatory.util.rates import RateTracker

SYS_NET = Path("/sys/class/net")
VIRTUAL_PREFIXES = ("lo", "veth", "docker", "br-", "virbr", "vmbr", "tap", "tun", "fwbr", "fwpr",
                    "fwln", "wg", "tailscale", "zt", "cni", "flannel", "kube", "vnet", "dummy")


def is_virtual_interface(name: str, sys_net: Path = SYS_NET) -> bool:
    """Physical NICs have a ``device`` link in sysfs; bridges, veths and tunnels do not."""
    if name == "lo":
        return True
    device_link = sys_net / name / "device"
    if sys_net.is_dir() and (sys_net / name).exists():
        return not device_link.exists()
    return name.startswith(VIRTUAL_PREFIXES)


class NetworkCollector:
    def __init__(self, sys_net: Path = SYS_NET) -> None:
        self._rates = RateTracker()
        self._sys_net = sys_net

    def collect(self) -> list[NetInterface]:
        try:
            counters = psutil.net_io_counters(pernic=True) or {}
            stats = psutil.net_if_stats()
            addrs = psutil.net_if_addrs()
        except OSError:
            return []
        now = time.monotonic()
        live: set = set()
        result: list[NetInterface] = []
        for name, c in counters.items():
            live.update({(name, "rx"), (name, "tx")})
            st = stats.get(name)
            addresses = [
                a.address
                for a in addrs.get(name, [])
                if a.family in (socket.AF_INET, socket.AF_INET6) and not a.address.startswith("fe80")
            ]
            result.append(
                NetInterface(
                    name=name,
                    is_up=bool(st.isup) if st else False,
                    speed_mbps=int(st.speed) if st and st.speed else 0,
                    addresses=addresses,
                    rx_bps=self._rates.rate((name, "rx"), c.bytes_recv, now),
                    tx_bps=self._rates.rate((name, "tx"), c.bytes_sent, now),
                    rx_total=c.bytes_recv,
                    tx_total=c.bytes_sent,
                    errors=c.errin + c.errout,
                    drops=c.dropin + c.dropout,
                    virtual=is_virtual_interface(name, self._sys_net),
                )
            )
        self._rates.forget_missing(live)
        result.sort(key=lambda n: (n.virtual, n.name))
        return result


def connection_summary() -> dict[str, int]:
    """Count TCP connections by state (all processes need root; degrade to own)."""
    counts: dict[str, int] = {}
    try:
        conns = psutil.net_connections(kind="tcp")
    except (psutil.AccessDenied, PermissionError, OSError):
        return counts
    for conn in conns:
        counts[conn.status] = counts.get(conn.status, 0) + 1
    return counts
