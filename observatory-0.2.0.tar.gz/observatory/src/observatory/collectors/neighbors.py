"""Network intelligence helpers: LAN neighbours (ARP/NDP cache) and the
applications holding the most connections."""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from pathlib import Path

import psutil

PROC_ARP = Path("/proc/net/arp")


@dataclass(frozen=True, slots=True)
class Neighbor:
    ip: str
    mac: str
    interface: str


def parse_proc_arp(text: str) -> list[Neighbor]:
    """Parse /proc/net/arp; skip incomplete (00:00:...) entries."""
    neighbors: list[Neighbor] = []
    for line in text.splitlines()[1:]:
        parts = line.split()
        if len(parts) < 6:
            continue
        ip, _hw, flags, mac, _mask, iface = parts[:6]
        if mac == "00:00:00:00:00:00" or flags == "0x0":
            continue
        neighbors.append(Neighbor(ip=ip, mac=mac.lower(), interface=iface))
    return neighbors


def read_neighbors(path: Path = PROC_ARP) -> list[Neighbor]:
    try:
        return parse_proc_arp(path.read_text())
    except OSError:
        return []


@dataclass(slots=True)
class AppConnections:
    name: str
    connections: int
    remote_hosts: int


def top_connection_apps(limit: int = 5) -> list[AppConnections]:
    """Processes ranked by established TCP/UDP connections (all users when root)."""
    try:
        conns = psutil.net_connections(kind="inet")
    except (psutil.AccessDenied, PermissionError, OSError):
        return []
    per_pid: Counter[int] = Counter()
    remotes: dict[int, set[str]] = {}
    for c in conns:
        if not c.pid or not c.raddr:
            continue
        per_pid[c.pid] += 1
        remotes.setdefault(c.pid, set()).add(c.raddr.ip)
    per_name: Counter[str] = Counter()
    name_remotes: dict[str, set[str]] = {}
    for pid, count in per_pid.items():
        try:
            name = psutil.Process(pid).name()
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
        per_name[name] += count
        name_remotes.setdefault(name, set()).update(remotes.get(pid, set()))
    return [AppConnections(name, count, len(name_remotes.get(name, ())))
            for name, count in per_name.most_common(limit)]
