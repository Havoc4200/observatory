"""Turn monotonically increasing kernel counters into per-second rates."""

from __future__ import annotations

import time
from collections.abc import Hashable


class RateTracker:
    """Remember the last value of each counter and return its rate.

    Counter resets (value going backwards, e.g. after an interface is
    re-created or a 32-bit counter wraps) yield a rate of 0 for that cycle
    instead of a huge negative or positive spike.
    """

    def __init__(self, clock=time.monotonic) -> None:
        self._clock = clock
        self._last: dict[Hashable, tuple[float, float]] = {}

    def rate(self, key: Hashable, value: float, now: float | None = None) -> float:
        now = self._clock() if now is None else now
        previous = self._last.get(key)
        self._last[key] = (now, float(value))
        if previous is None:
            return 0.0
        last_time, last_value = previous
        elapsed = now - last_time
        delta = float(value) - last_value
        if elapsed <= 0 or delta < 0:
            return 0.0
        return delta / elapsed

    def forget_missing(self, live_keys: set[Hashable]) -> None:
        for key in list(self._last):
            if key not in live_keys:
                del self._last[key]

    def __contains__(self, key: Hashable) -> bool:
        return key in self._last
