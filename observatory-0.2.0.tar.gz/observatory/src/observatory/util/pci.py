"""PCI device discovery from sysfs and name lookup from the system pci.ids file."""

from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path

SYS_PCI = Path("/sys/bus/pci/devices")
PCI_IDS_PATHS = (
    Path("/usr/share/misc/pci.ids"),
    Path("/usr/share/hwdata/pci.ids"),
    Path("/usr/share/pci.ids"),
)

VENDOR_NAMES = {
    "10de": "NVIDIA",
    "1002": "AMD",
    "8086": "Intel",
    "1a03": "ASPEED",
    "102b": "Matrox",
    "1af4": "Red Hat (virtio)",
    "15ad": "VMware",
    "1234": "QEMU",
    "14e4": "Broadcom",
    "1000": "Broadcom/LSI",
}


@dataclass(slots=True)
class PciDevice:
    address: str
    vendor_id: str
    device_id: str
    class_code: str  # six hex digits, e.g. "030000"

    @property
    def is_display(self) -> bool:
        return self.class_code.startswith("03")

    @property
    def vendor(self) -> str:
        return VENDOR_NAMES.get(self.vendor_id, self.vendor_id)

    @property
    def name(self) -> str:
        return pci_name(self.vendor_id, self.device_id)


def _hex(path: Path) -> str:
    try:
        return path.read_text().strip().lower().removeprefix("0x")
    except OSError:
        return ""


def scan_pci(sys_pci: Path = SYS_PCI) -> list[PciDevice]:
    devices: list[PciDevice] = []
    if not sys_pci.is_dir():
        return devices
    for entry in sorted(sys_pci.iterdir()):
        vendor = _hex(entry / "vendor")
        device = _hex(entry / "device")
        klass = _hex(entry / "class")
        if vendor and device and klass:
            devices.append(PciDevice(entry.name, vendor, device, klass.zfill(6)))
    return devices


@lru_cache(maxsize=1)
def _load_pci_ids() -> dict[str, tuple[str, dict[str, str]]]:
    for path in PCI_IDS_PATHS:
        if path.is_file():
            try:
                return parse_pci_ids(path.read_text(errors="replace"), wanted_vendors=set(VENDOR_NAMES))
            except OSError:
                continue
    return {}


def parse_pci_ids(text: str, wanted_vendors: set[str] | None = None) -> dict[str, tuple[str, dict[str, str]]]:
    """Parse the pci.ids format (vendors unindented, devices one tab deep)."""
    table: dict[str, tuple[str, dict[str, str]]] = {}
    current_vendor: str | None = None
    for line in text.splitlines():
        if not line or line.startswith("#"):
            continue
        if line.startswith("C "):  # class section at the end of the file
            break
        if not line.startswith("\t"):
            vendor_id, _, vendor_name = line.partition("  ")
            vendor_id = vendor_id.strip().lower()
            if wanted_vendors is not None and vendor_id not in wanted_vendors:
                current_vendor = None
                continue
            current_vendor = vendor_id
            table[vendor_id] = (vendor_name.strip(), {})
        elif current_vendor and not line.startswith("\t\t"):
            device_id, _, device_name = line.strip().partition("  ")
            table[current_vendor][1][device_id.lower()] = device_name.strip()
    return table


def pci_name(vendor_id: str, device_id: str) -> str:
    table = _load_pci_ids()
    vendor_label = VENDOR_NAMES.get(vendor_id, vendor_id)
    entry = table.get(vendor_id)
    if entry:
        device_name = entry[1].get(device_id)
        if device_name:
            # pci.ids names look like "GA106 [GeForce RTX 3060 Lite Hash Rate]";
            # the bracketed marketing name is the useful part.
            if "[" in device_name and "]" in device_name:
                device_name = device_name[device_name.index("[") + 1 : device_name.rindex("]")]
            return f"{vendor_label} {device_name}"
    return f"{vendor_label} GPU [{vendor_id}:{device_id}]"
