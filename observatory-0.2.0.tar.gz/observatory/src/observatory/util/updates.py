"""Pending package update detection (apt, dnf, pacman, zypper, apk).

Runs read-only commands that do not require root and caches the result;
callers should invoke :meth:`UpdateChecker.check` from a background thread.
"""

from __future__ import annotations

import shutil
import subprocess
import time
from dataclasses import dataclass


@dataclass(slots=True)
class UpdateStatus:
    available: int | None = None      # None = unknown / unsupported
    security: int | None = None
    manager: str = ""
    checked_at: float = 0.0
    error: str = ""

    @property
    def label(self) -> str:
        if self.available is None:
            return "updates n/a"
        if self.available == 0:
            return "up to date"
        sec = f" ({self.security} security)" if self.security else ""
        return f"{self.available} update{'s' if self.available != 1 else ''}{sec}"


def _run(cmd: list[str], timeout: float = 60.0) -> subprocess.CompletedProcess | None:
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, check=False)
    except (OSError, subprocess.TimeoutExpired):
        return None


def parse_apt_check(stderr: str) -> tuple[int, int] | None:
    """``apt-check`` prints ``UPGRADES;SECURITY`` on stderr."""
    text = stderr.strip().splitlines()[-1] if stderr.strip() else ""
    parts = text.split(";")
    if len(parts) == 2 and all(p.strip().isdigit() for p in parts):
        return int(parts[0]), int(parts[1])
    return None


def parse_apt_simulate(stdout: str) -> tuple[int, int]:
    """Count ``Inst`` lines of ``apt-get -s upgrade``; security = from a *-security pocket."""
    total = security = 0
    for line in stdout.splitlines():
        if line.startswith("Inst "):
            total += 1
            if "-security" in line or "Debian-Security" in line:
                security += 1
    return total, security


def parse_dnf_check_update(stdout: str) -> int:
    count = 0
    for line in stdout.splitlines():
        parts = line.split()
        if len(parts) == 3 and "." in parts[0] and not line.startswith(("Last metadata", "Obsoleting", " ")):
            count += 1
    return count


class UpdateChecker:
    def __init__(self, interval: float = 6 * 3600) -> None:
        self.interval = interval
        self.status = UpdateStatus()

    def due(self, now: float | None = None) -> bool:
        now = now if now is not None else time.time()
        return now - self.status.checked_at >= self.interval

    def check(self) -> UpdateStatus:
        status = UpdateStatus(checked_at=time.time())
        if shutil.which("apt-get"):
            status.manager = "apt"
            apt_check = "/usr/lib/update-notifier/apt-check"
            result = _run([apt_check]) if shutil.which(apt_check) or _exists(apt_check) else None
            parsed = parse_apt_check(result.stderr) if result else None
            if parsed is None:
                sim = _run(["apt-get", "-s", "-o", "Debug::NoLocking=1", "upgrade"])
                if sim is not None and sim.returncode == 0:
                    parsed = parse_apt_simulate(sim.stdout)
            if parsed is not None:
                status.available, status.security = parsed
        elif shutil.which("dnf"):
            status.manager = "dnf"
            res = _run(["dnf", "-q", "--cacheonly", "check-update"])
            if res is not None and res.returncode in (0, 100):
                status.available = parse_dnf_check_update(res.stdout)
        elif shutil.which("checkupdates"):
            status.manager = "pacman"
            res = _run(["checkupdates"])
            if res is not None and res.returncode in (0, 2):
                status.available = len([ln for ln in res.stdout.splitlines() if ln.strip()])
        elif shutil.which("apk"):
            status.manager = "apk"
            res = _run(["apk", "version", "-l", "<"])
            if res is not None and res.returncode == 0:
                status.available = max(len(res.stdout.splitlines()) - 1, 0)
        else:
            status.error = "no supported package manager"
        self.status = status
        return status


def _exists(path: str) -> bool:
    from pathlib import Path

    return Path(path).exists()
