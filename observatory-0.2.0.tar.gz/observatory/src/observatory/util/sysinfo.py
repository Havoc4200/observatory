"""Static system identity: distribution, kernel, virtualization platform."""

from __future__ import annotations

import platform
import shutil
import subprocess
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path


@dataclass(frozen=True, slots=True)
class SystemIdentity:
    os_name: str        # e.g. "Ubuntu 24.04.1 LTS"
    os_id: str          # e.g. "ubuntu"
    kernel: str         # e.g. "6.8.0-45-generic"
    arch: str           # e.g. "x86_64"
    platform: str       # e.g. "Proxmox VE 8.2.4" or "" on plain Linux

    @property
    def display(self) -> str:
        base = self.platform or self.os_name
        return f"{base} · {self.kernel}"


def parse_os_release(text: str) -> dict[str, str]:
    values: dict[str, str] = {}
    for line in text.splitlines():
        if "=" not in line or line.startswith("#"):
            continue
        key, _, value = line.partition("=")
        values[key.strip()] = value.strip().strip('"').strip("'")
    return values


def _proxmox_version() -> str:
    if not Path("/etc/pve").exists() and not shutil.which("pveversion"):
        return ""
    binary = shutil.which("pveversion")
    if binary:
        try:
            out = subprocess.run([binary], capture_output=True, text=True, timeout=3, check=False).stdout
            # "pve-manager/8.2.4/faa83925c9641325 (running kernel: 6.8.12-1-pve)"
            if out.startswith("pve-manager/"):
                return "Proxmox VE " + out.split("/")[1]
        except (OSError, subprocess.TimeoutExpired):
            pass
    return "Proxmox VE"


@lru_cache(maxsize=1)
def system_identity(os_release: Path = Path("/etc/os-release")) -> SystemIdentity:
    try:
        info = parse_os_release(os_release.read_text())
    except OSError:
        info = {}
    os_name = info.get("PRETTY_NAME") or info.get("NAME") or "Linux"
    return SystemIdentity(
        os_name=os_name,
        os_id=info.get("ID", "linux"),
        kernel=platform.release(),
        arch=platform.machine(),
        platform=_proxmox_version(),
    )
