"""Small shared utilities."""
