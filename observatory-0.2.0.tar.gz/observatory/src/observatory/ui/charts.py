"""Terminal graphics primitives built on Rich Text.

* BrailleCanvas — 2×4 dots per character cell, with per-dot colour layers
* area_chart / line_chart — gradient-filled time series
* ring_gauge — circular progress ring with centred label
* radar_chart — spider chart with a baseline overlay
* heat_strip, spark_blocks, hbar — compact one-line visualisations
* big_text — 3-row block font for headline numbers

All functions return :class:`rich.text.Text` so they compose with any widget
and stay theme-aware: colours are passed in, never hard-coded.
"""

from __future__ import annotations

import math
from collections.abc import Sequence

from rich.color import Color
from rich.style import Style
from rich.text import Text

BRAILLE_BASE = 0x2800
_DOT_BITS = ((0x01, 0x08), (0x02, 0x10), (0x04, 0x20), (0x40, 0x80))  # [row][col]
BLOCKS = "▁▂▃▄▅▆▇█"


# ------------------------------------------------------------------ colours
def _rgb(color: str) -> tuple[int, int, int]:
    triplet = Color.parse(color).get_truecolor()
    return triplet.red, triplet.green, triplet.blue


def blend(c1: str, c2: str, t: float) -> str:
    """Linear blend between two colours (any Rich colour spec) → '#rrggbb'."""
    t = min(max(t, 0.0), 1.0)
    a, b = _rgb(c1), _rgb(c2)
    return "#{:02x}{:02x}{:02x}".format(*(round(x + (y - x) * t) for x, y in zip(a, b)))


def gradient(stops: Sequence[str], t: float) -> str:
    """Colour at position t (0..1) along a multi-stop gradient."""
    if not stops:
        return "white"
    if len(stops) == 1:
        return stops[0]
    t = min(max(t, 0.0), 1.0)
    scaled = t * (len(stops) - 1)
    i = min(int(scaled), len(stops) - 2)
    return blend(stops[i], stops[i + 1], scaled - i)


def gradient_text(text: str, stops: Sequence[str], bold: bool = True) -> Text:
    out = Text()
    n = max(len(text) - 1, 1)
    for i, ch in enumerate(text):
        out.append(ch, Style(color=gradient(stops, i / n), bold=bold))
    return out


# ------------------------------------------------------------------- canvas
class BrailleCanvas:
    """A dot grid rendered with Unicode braille. Each dot carries a colour
    layer; a cell takes the colour of its highest-priority dot."""

    def __init__(self, cols: int, rows: int) -> None:
        self.cols = max(cols, 1)
        self.rows = max(rows, 1)
        self.width = self.cols * 2
        self.height = self.rows * 4
        self._bits = [[0] * self.cols for _ in range(self.rows)]
        self._layer = [[-1] * self.cols for _ in range(self.rows)]
        self._cell_color: list[list[str | None]] = [[None] * self.cols for _ in range(self.rows)]
        self._overlay: dict[tuple[int, int], tuple[str, Style]] = {}

    def set(self, x: float, y: float, color: str | None = None, layer: int = 0) -> None:
        xi, yi = int(round(x)), int(round(y))
        if not (0 <= xi < self.width and 0 <= yi < self.height):
            return
        cx, cy = xi // 2, yi // 4
        self._bits[cy][cx] |= _DOT_BITS[yi % 4][xi % 2]
        if layer >= self._layer[cy][cx]:
            self._layer[cy][cx] = layer
            self._cell_color[cy][cx] = color

    def line(self, x0: float, y0: float, x1: float, y1: float, color: str | None = None, layer: int = 0) -> None:
        steps = int(max(abs(x1 - x0), abs(y1 - y0))) + 1
        for i in range(steps + 1):
            t = i / steps
            self.set(x0 + (x1 - x0) * t, y0 + (y1 - y0) * t, color, layer)

    def fill_polygon(self, points: Sequence[tuple[float, float]], color: str | None = None, layer: int = 0,
                     step: int = 2) -> None:
        """Scanline fill; ``step`` > 1 gives a stippled, translucent-looking fill."""
        if len(points) < 3:
            return
        ys = [p[1] for p in points]
        for y in range(int(min(ys)), int(max(ys)) + 1):
            xs = []
            for (xa, ya), (xb, yb) in zip(points, list(points[1:]) + [points[0]]):
                if (ya <= y < yb) or (yb <= y < ya):
                    xs.append(xa + (y - ya) * (xb - xa) / (yb - ya))
            xs.sort()
            for a, b in zip(xs[::2], xs[1::2]):
                for x in range(int(math.ceil(a)), int(b) + 1):
                    if (x + y) % step == 0:
                        self.set(x, y, color, layer)

    def text(self, col: int, row: int, text: str, style: Style | str = "") -> None:
        style = Style.parse(style) if isinstance(style, str) else style
        for i, ch in enumerate(text):
            if 0 <= col + i < self.cols and 0 <= row < self.rows:
                self._overlay[(col + i, row)] = (ch, style)

    def render(self, default_color: str | None = None) -> Text:
        out = Text()
        for cy in range(self.rows):
            for cx in range(self.cols):
                overlay = self._overlay.get((cx, cy))
                if overlay is not None:
                    out.append(overlay[0], overlay[1])
                    continue
                bits = self._bits[cy][cx]
                color = self._cell_color[cy][cx] or default_color
                out.append(chr(BRAILLE_BASE + bits) if bits else " ", Style(color=color) if color else None)
            if cy < self.rows - 1:
                out.append("\n")
        return out


# ------------------------------------------------------------------ charts
def _scale(values: Sequence[float], max_value: float | None, min_value: float = 0.0) -> tuple[float, float]:
    vmax = max_value if max_value is not None else max(values, default=0.0)
    vmax = max(vmax, min_value + 1e-9)
    return min_value, vmax


def resample(values: Sequence[float], n: int) -> list[float]:
    """Stretch or shrink a series to exactly n points (nearest/average)."""
    if n <= 0:
        return []
    if not values:
        return [0.0] * n
    m = len(values)
    if m == n:
        return list(values)
    if m > n:
        out = []
        for i in range(n):
            a = int(i * m / n)
            b = max(int((i + 1) * m / n), a + 1)
            chunk = values[a:b]
            out.append(sum(chunk) / len(chunk))
        return out
    # fewer points than columns: keep them right-aligned (most recent at the right edge)
    return [0.0] * (n - m) + list(values)


def area_chart(values: Sequence[float], cols: int, rows: int, stops: Sequence[str],
               max_value: float | None = None, fill: bool = True, baseline: float | None = None,
               baseline_color: str = "grey50") -> Text:
    """Gradient area chart. Colour runs bottom→top along ``stops``."""
    cols, rows = max(cols, 1), max(rows, 1)
    canvas = BrailleCanvas(cols, rows)
    data = resample(list(values), canvas.width)
    lo, hi = _scale(data, max_value)
    height = canvas.height
    prev_y = None
    for x, v in enumerate(data):
        frac = min(max((v - lo) / (hi - lo), 0.0), 1.0)
        top = height - 1 - frac * (height - 1)
        if v > lo or frac > 0:
            if fill:
                for y in range(int(round(top)), height):
                    canvas.set(x, y, gradient(stops, 1 - y / max(height - 1, 1)), layer=1)
            else:
                canvas.set(x, top, gradient(stops, frac), layer=1)
                if prev_y is not None:
                    canvas.line(x - 1, prev_y, x, top, gradient(stops, frac), layer=1)
        prev_y = top
    if baseline is not None and hi > lo:
        by = height - 1 - min(max((baseline - lo) / (hi - lo), 0.0), 1.0) * (height - 1)
        for x in range(0, canvas.width, 3):
            canvas.set(x, by, baseline_color, layer=0)
    return canvas.render()


def line_chart(values: Sequence[float], cols: int, rows: int, stops: Sequence[str],
               max_value: float | None = None) -> Text:
    return area_chart(values, cols, rows, stops, max_value, fill=False)


def stretch(values: Sequence[float], n: int) -> list[float]:
    """Resize a short series to n points by repeating values (no right-alignment)."""
    m = len(values)
    if m == 0 or n <= 0:
        return [0.0] * max(n, 0)
    if m >= n:
        return resample(values, n)
    return [values[min(int(i * m / n), m - 1)] for i in range(n)]


def spark_blocks(values: Sequence[float], width: int, stops: Sequence[str] | None = None,
                 max_value: float | None = None) -> Text:
    data = stretch(list(values), width)
    lo, hi = _scale(data, max_value)
    out = Text()
    for v in data:
        frac = min(max((v - lo) / (hi - lo), 0.0), 1.0)
        ch = BLOCKS[min(int(frac * (len(BLOCKS) - 1) + 0.5), len(BLOCKS) - 1)] if v > 0 else " "
        out.append(ch, Style(color=gradient(stops, frac)) if stops else None)
    return out


def heat_strip(values: Sequence[float], width: int, stops: Sequence[str], max_value: float | None = None,
               empty_color: str = "grey23") -> Text:
    """One row of coloured blocks; colour encodes magnitude (e.g. 24 h at a glance)."""
    data = resample(list(values), width)
    lo, hi = _scale(data, max_value)
    out = Text()
    for v in data:
        if v <= 0:
            out.append("▪", Style(color=empty_color))
        else:
            out.append("■", Style(color=gradient(stops, (v - lo) / (hi - lo))))
    return out


def hbar(fraction: float, width: int, color: str, track: str = "grey27", char: str = "━",
         track_char: str = "━") -> Text:
    fraction = min(max(fraction, 0.0), 1.0)
    filled = int(round(fraction * width))
    out = Text()
    out.append(char * filled, Style(color=color))
    out.append(track_char * (width - filled), Style(color=track))
    return out


def gradient_bar(fraction: float, width: int, stops: Sequence[str], track: str = "grey27") -> Text:
    """A bar whose filled part runs through the gradient (cool → hot)."""
    fraction = min(max(fraction, 0.0), 1.0)
    filled = int(round(fraction * width))
    out = Text()
    for i in range(filled):
        out.append("█", Style(color=gradient(stops, i / max(width - 1, 1))))
    out.append("░" * 0 + "·" * (width - filled), Style(color=track))
    return out


# --------------------------------------------------------------------- ring
def ring_gauge(fraction: float, cols: int, rows: int, color: str, track: str,
               center_lines: Sequence[Text] = (), thickness: int = 2,
               color_end: str | None = None) -> Text:
    """A circular progress ring starting at 12 o'clock, clockwise.

    ``center_lines`` are drawn centred inside the ring."""
    canvas = BrailleCanvas(cols, rows)
    cx, cy = (canvas.width - 1) / 2, (canvas.height - 1) / 2
    radius = min(cx, cy) - 0.5
    fraction = min(max(fraction, 0.0), 1.0)
    steps = int(2 * math.pi * radius * 3) + 24
    for i in range(steps):
        angle = 2 * math.pi * i / steps
        portion = i / steps
        on_arc = portion <= fraction and fraction > 0
        arc_color = gradient([color, color_end or color], portion) if on_arc else track
        for t in range(thickness):
            r = radius - t
            x = cx + r * math.sin(angle)
            y = cy - r * math.cos(angle)
            canvas.set(x, y, arc_color, layer=2 if on_arc else 0)
    start_row = int(round(rows / 2 - len(center_lines) / 2))
    for idx, line in enumerate(center_lines):
        plain = line.plain
        col = int(round((cols - len(plain)) / 2))
        for j, (ch, style) in enumerate(zip(plain, char_styles(line))):
            canvas.text(col + j, start_row + idx, ch, style)
    return canvas.render()


def char_styles(text: Text) -> list[Style]:
    """Resolve the effective style of every character of a Text."""
    def as_style(s) -> Style:
        if isinstance(s, Style):
            return s
        try:
            return Style.parse(s) if s else Style()
        except Exception:
            return Style()

    base = as_style(text.style)
    styles = [base] * len(text.plain)
    for span in text.spans:
        span_style = as_style(span.style)
        for k in range(max(span.start, 0), min(span.end, len(styles))):
            styles[k] = styles[k] + span_style
    return styles


# -------------------------------------------------------------------- radar
def radar_chart(axes: Sequence[tuple[str, float]], cols: int, rows: int, color: str, grid: str,
                label_style: str, baseline: Sequence[float] | None = None, baseline_color: str = "grey50",
                fill_color: str | None = None) -> Text:
    """Spider chart; values in 0..1. Labels sit just outside each axis."""
    n = len(axes)
    canvas = BrailleCanvas(cols, rows)
    if n < 3:
        return canvas.render()
    cx, cy = (canvas.width - 1) / 2, (canvas.height - 1) / 2
    # leave room for labels: one text row top/bottom, ~6 columns left/right
    radius = max(min(cx - 12, cy - 5), 3)

    def point(i: int, frac: float) -> tuple[float, float]:
        angle = -math.pi / 2 + 2 * math.pi * i / n
        return cx + radius * frac * math.cos(angle), cy + radius * frac * math.sin(angle)

    for ring in (0.5, 1.0):
        pts = [point(i, ring) for i in range(n)]
        for a, b in zip(pts, pts[1:] + pts[:1]):
            canvas.line(*a, *b, grid, layer=0)
    for i in range(n):
        canvas.line(cx, cy, *point(i, 1.0), grid, layer=0)
    if baseline is not None and len(baseline) == n:
        pts = [point(i, min(max(v, 0.0), 1.0)) for i, v in enumerate(baseline)]
        for a, b in zip(pts, pts[1:] + pts[:1]):
            canvas.line(*a, *b, baseline_color, layer=1)
    pts = [point(i, min(max(v, 0.02), 1.0)) for i, (_l, v) in enumerate(axes)]
    canvas.fill_polygon(pts, fill_color or color, layer=2, step=2)
    for a, b in zip(pts, pts[1:] + pts[:1]):
        canvas.line(*a, *b, color, layer=3)
    for i, (label, value) in enumerate(axes):
        lx, ly = point(i, 1.0)
        col = int(lx / 2)
        row = int(ly / 4)
        text = f"{label} {value * 100:.0f}%"
        if abs(lx - cx) < 2:  # top / bottom axis: centre the label
            col -= len(text) // 2
            row = row - 1 if ly < cy else row + 1
        elif lx > cx:
            col += 1
        else:
            col -= len(text)
        col = min(max(col, 0), cols - len(text))
        row = min(max(row, 0), rows - 1)
        canvas.text(col, row, text, label_style)
    return canvas.render()


# ----------------------------------------------------------------- big text
_FONT = {
    "0": ("█▀█", "█ █", "▀▀▀"), "1": ("▀█ ", " █ ", "▀▀▀"), "2": ("▀▀█", "█▀▀", "▀▀▀"),
    "3": ("▀▀█", " ▀█", "▀▀▀"), "4": ("█ █", "▀▀█", "  ▀"), "5": ("█▀▀", "▀▀█", "▀▀▀"),
    "6": ("█▀▀", "█▀█", "▀▀▀"), "7": ("▀▀█", "  █", "  ▀"), "8": ("█▀█", "█▀█", "▀▀▀"),
    "9": ("█▀█", "▀▀█", "▀▀▀"), ".": (" ", " ", "▀"), ",": (" ", " ", "▄"), "%": ("▀ █", " █ ", "█ ▄"),
    " ": (" ", " ", " "), "-": ("   ", "▀▀▀", "   "), "W": ("█ █", "█▄█", "▀ ▀"), "$": ("▄█▀", "▀█▄", "▀▀ "),
    "k": ("█  ", "█▄▀", "▀ ▀"), "°": ("▄▀▄", " ▀ ", "   "), "C": ("█▀▀", "█  ", "▀▀▀"),
    "/": ("  █", " █ ", "█  "),
}


def big_text(text: str, style: Style | str, spacing: int = 1) -> list[Text]:
    """Render text in a 3-row block font; unknown characters fall back to plain."""
    rows = [Text(), Text(), Text()]
    for ch in text:
        glyph = _FONT.get(ch) or _FONT.get(ch.upper())
        if glyph is None:
            glyph = (" ", ch, " ")
        for r in range(3):
            rows[r].append(glyph[r], style)
            rows[r].append(" " * spacing)
    return rows


def big_text_width(text: str, spacing: int = 1) -> int:
    return sum(len((_FONT.get(c) or _FONT.get(c.upper()) or (" ", c, " "))[0]) + spacing for c in text)


# ------------------------------------------------- segment numerals (clean)
# A thin, seven-segment-style display font drawn with box-drawing characters.
# Far more legible than block glyphs at three rows, and it reads as
# "instrument panel" rather than "ASCII art".
_SEG = {
    "0": ("┏━┓", "┃ ┃", "┗━┛"), "1": ("╺┓ ", " ┃ ", "╺┻╸"), "2": ("╺━┓", "┏━┛", "┗━╸"),
    "3": ("╺━┓", " ━┫", "╺━┛"), "4": ("╻ ╻", "┗━┫", "  ╹"), "5": ("┏━╸", "┗━┓", "╺━┛"),
    "6": ("┏━╸", "┣━┓", "┗━┛"), "7": ("╺━┓", "  ┃", "  ╹"), "8": ("┏━┓", "┣━┫", "┗━┛"),
    "9": ("┏━┓", "┗━┫", "╺━┛"), ".": (" ", " ", "•"), ",": (" ", " ", ","), " ": (" ", " ", " "),
    "-": ("   ", "╺━╸", "   "), "%": ("o╻", "┏┛", "╹o"), "$": ("┏╋╸", "┗╋┓", "╺╋┛"),
    "W": ("╻ ╻", "┃╻┃", "┗┻┛"), "k": ("╻  ", "┣┳┛", "╹┗╸"), "/": ("  ╻", " ┏┛", "╹  "),
    ":": (" ", "•", "•"),
}


def seg_text(text: str, style: Style | str, spacing: int = 1) -> list[Text]:
    """Three rows of segment numerals; unsupported characters are drawn small on the middle row."""
    rows = [Text(), Text(), Text()]
    for i, ch in enumerate(text):
        glyph = _SEG.get(ch)
        if glyph is None:
            glyph = (" " * len(ch), ch, " " * len(ch))
        for r in range(3):
            rows[r].append(glyph[r], style)
            if i < len(text) - 1:
                rows[r].append(" " * spacing)
    return rows


def seg_width(text: str, spacing: int = 1) -> int:
    widths = [len((_SEG.get(c) or (c,))[0]) for c in text]
    return sum(widths) + spacing * max(len(text) - 1, 0)


# ------------------------------------------------------- solid area charts
_EIGHTHS = " ▁▂▃▄▅▆▇█"


def block_area(values: Sequence[float], cols: int, rows: int, stops: Sequence[str],
               max_value: float | None = None, min_value: float = 0.0, baseline: float | None = None,
               baseline_color: str = "grey50", empty_color: str | None = None,
               marker_last: str | None = None) -> Text:
    """Solid area chart from eighth-block characters (8 levels per row).

    Colour follows the *height* of each cell (bottom = first stop, top = last),
    giving a smooth vertical gradient. ``baseline`` draws a dotted reference
    line (e.g. the 7-day average) where the area does not cover it.
    ``empty_color`` paints a faint floor under columns with no data.
    """
    cols, rows = max(cols, 1), max(rows, 1)
    data = resample(list(values), cols)
    lo = min_value
    hi = max_value if max_value is not None else max(data + [lo + 1e-9])
    hi = max(hi, lo + 1e-9)
    levels = rows * 8
    heights = [int(round(min(max((v - lo) / (hi - lo), 0.0), 1.0) * levels)) if v > lo else 0 for v in data]
    base_level = None
    if baseline is not None:
        base_level = min(max((baseline - lo) / (hi - lo), 0.0), 1.0) * levels
    out = Text()
    for r in range(rows):
        row_from_bottom = rows - 1 - r
        color = gradient(stops, (row_from_bottom + 0.5) / rows)
        for c, h in enumerate(heights):
            fill = h - row_from_bottom * 8
            last = marker_last is not None and c == cols - 1
            if fill >= 8:
                out.append("█", Style(color=marker_last if last else color))
            elif fill > 0:
                out.append(_EIGHTHS[fill], Style(color=marker_last if last else color))
            elif base_level is not None and int(base_level // 8) == row_from_bottom and c % 2 == 0:
                out.append("·", Style(color=baseline_color))
            elif r == rows - 1 and empty_color is not None and h == 0:
                out.append("▁", Style(color=empty_color))
            else:
                out.append(" ")
        if r < rows - 1:
            out.append("\n")
    return out


def mirror_area(up: Sequence[float], down: Sequence[float], cols: int, rows: int,
                up_color: str, down_color: str, max_value: float | None = None) -> Text:
    """Two series around a centre line (e.g. download above, upload below)."""
    top_rows = max(rows // 2, 1)
    bottom_rows = max(rows - top_rows, 1)
    a = resample(list(up), cols)
    b = resample(list(down), cols)
    hi = max_value if max_value is not None else max(a + b + [1e-9])
    out = Text()
    for r in range(top_rows):
        from_bottom = top_rows - 1 - r
        for v in a:
            fill = int(round(min(v / hi, 1.0) * top_rows * 8)) - from_bottom * 8
            out.append("█" if fill >= 8 else _EIGHTHS[fill] if fill > 0 else " ", Style(color=up_color))
        out.append("\n")
    # Unicode has no top-anchored eighth blocks, so the lower half uses half-block steps.
    for r in range(bottom_rows):
        for v in b:
            fill = int(round(min(v / hi, 1.0) * bottom_rows * 2)) - r * 2
            ch = "█" if fill >= 2 else "▀" if fill == 1 else " "
            out.append(ch, Style(color=down_color))
        if r < bottom_rows - 1:
            out.append("\n")
    return out


def stacked_bar(parts: Sequence[tuple[float, str]], width: int, track: str = "grey27") -> Text:
    """One-line bar split into coloured segments proportional to each value."""
    total = sum(max(v, 0.0) for v, _c in parts)
    out = Text()
    if total <= 0 or width <= 0:
        out.append("━" * max(width, 0), Style(color=track))
        return out
    used = 0
    for idx, (value, color) in enumerate(parts):
        n = int(round(max(value, 0.0) / total * width)) if idx < len(parts) - 1 else width - used
        n = max(min(n, width - used), 0)
        out.append("█" * n, Style(color=color))
        used += n
    return out


def heatmap_grid(matrix: Sequence[Sequence[float | None]], row_labels: Sequence[str], stops: Sequence[str],
                 empty_color: str, label_style: Style | str, cell: str = "■", max_value: float | None = None,
                 col_labels: str = "", highlight: tuple[int, int] | None = None, highlight_color: str = "white") -> Text:
    """Rows × columns of coloured cells (e.g. 7 days × 24 hours of CPU)."""
    values = [v for row in matrix for v in row if v is not None]
    hi = max_value if max_value is not None else (max(values) if values else 1.0)
    hi = max(hi, 1e-9)
    out = Text()
    for r, row in enumerate(matrix):
        out.append(f"{row_labels[r]:<4}", label_style)
        for c, v in enumerate(row):
            if highlight == (r, c):
                out.append("◆", Style(color=highlight_color, bold=True))
            elif v is None:
                out.append("·", Style(color=empty_color))
            else:
                out.append(cell, Style(color=gradient(stops, min(v / hi, 1.0))))
        out.append("\n")
    if col_labels:
        out.append("    " + col_labels, label_style)
    else:
        out.rstrip()
    return out


# ------------------------------------------------------------------ pulse
_BEAT = (0.0, 0.0, 0.18, 0.05, 0.0, 1.0, 0.0, 0.32, 0.12, 0.0)


def pulse_line(phase: int, width: int, activity: float, stops: Sequence[str], flat_color: str) -> Text:
    """One-line ECG trace made of block characters, scrolling with ``phase``.

    Busier systems beat faster (shorter period) and taller (amplitude)."""
    activity = min(max(activity, 0.0), 1.0)
    period = max(int(round(22 - 12 * activity)), len(_BEAT) + 1)
    amp = 0.45 + 0.55 * activity
    out = Text()
    for x in range(width):
        i = (x + phase) % period
        v = _BEAT[i] * amp if i < len(_BEAT) else 0.0
        if v <= 0.02:
            out.append("▁", Style(color=flat_color))
        else:
            idx = min(int(v * (len(BLOCKS) - 1) + 0.5), len(BLOCKS) - 1)
            out.append(BLOCKS[idx], Style(color=gradient(stops, x / max(width - 1, 1)), bold=True))
    return out


def pulse_wave(activity_history: Sequence[float], phase: int, cols: int, rows: int, stops: Sequence[str]) -> Text:
    """ECG-style trace: a heartbeat every ~12 dots whose amplitude follows activity (0..1)."""
    canvas = BrailleCanvas(cols, rows)
    width, height = canvas.width, canvas.height
    mid = height / 2
    beat = (0, 0, 0.15, -0.1, 0.0, 0.9, -0.6, 0.2, 0.05, 0, 0, 0)
    data = resample(list(activity_history), width) if activity_history else [0.0] * width
    prev = None
    for x in range(width):
        idx = (x + phase) % len(beat)
        amp = 0.25 + 0.75 * min(max(data[x], 0.0), 1.0)
        y = mid - beat[idx] * amp * (height / 2 - 1)
        color = gradient(stops, x / max(width - 1, 1))
        if prev is not None:
            canvas.line(x - 1, prev, x, y, color, layer=1)
        else:
            canvas.set(x, y, color, layer=1)
        prev = y
    return canvas.render()
