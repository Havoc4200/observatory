"""Command-center dashboard widgets."""
