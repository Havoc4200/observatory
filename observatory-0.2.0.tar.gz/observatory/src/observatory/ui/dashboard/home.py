"""The Home dashboard: Observatory's command center, and the product itself.

A user can live on this screen: it answers the four questions without
navigation, and every panel opens its deep-dive screen when clicked.

    ROW A  live resources — CPU · memory · swap · disk · network · GPU/load · thermal
           (each: now, trend arrow, 24 h chart ending at "now", peak, 7-day, week-over-week)
    ROW B  health center (scores, risk, why) · insights + "do next" · power & cost
    ROW C  storage (fill dates, SMART) · containers · services & media
    ROW D  radar · network · what changed · 30-day outlook · week heatmap (wide screens)

Rows have explicit heights computed from the terminal size: the whole
dashboard fits a 160×45 terminal, extra height is shared out so panels show
more detail, and terminals that are too small scroll instead of clipping.
"""

from __future__ import annotations

from textual.app import ComposeResult
from textual.containers import Grid, Horizontal, VerticalScroll
from textual.events import Resize

from observatory.models import Snapshot
from observatory.ui.dashboard.panels import (
    ChangesPanel, DashPanel, DockerCenter, HealthCenter, HeatmapPanel, InsightsPanel, MetricTile, NetworkCenter,
    OutlookPanel, PowerCenter, RadarPanel, ServicesPanel, StorageCenter,
)
from observatory.ui.panes.base import Pane

TILES = ("cpu", "mem", "swap", "disk", "net", "gpu", "temp")

# minimum heights (including borders)
MIN_A, MIN_B, MIN_C, MIN_D = 7, 14, 11, 11


def plan_layout(width: int, height: int) -> dict:
    """Pure layout computation (unit-tested): row heights, column widths, visibility."""
    narrow = width < 130
    side = 56 if width >= 190 else 54 if width >= 168 else 48 if width >= 148 else 44
    plan: dict = {"narrow": narrow, "side": side}
    if narrow:
        # stacked: two tile rows, each panel full width; the pane scrolls
        plan.update(tile_cols=4, tile_rows=2, a=14, b=14, c=12, d=12, radar=False, heatmap=False,
                    outlook=True)
        return plan
    extra = max(height - (MIN_A + MIN_B + MIN_C + MIN_D), 0)
    a = MIN_A + (1 if extra >= 12 else 0)
    extra -= a - MIN_A
    b = MIN_B + int(extra * 0.4)
    c = MIN_C + int(extra * 0.3)
    d = MIN_D + (extra - int(extra * 0.4) - int(extra * 0.3))
    plan.update(tile_cols=len(TILES), tile_rows=1, a=a, b=b, c=c, d=d,
                radar=width >= 176, heatmap=width >= 214, outlook=True)
    return plan


class HomePane(Pane):
    def compose(self) -> ComposeResult:
        with VerticalScroll(id="home-scroll"):
            with Grid(id="home-tiles"):
                for kind in TILES:
                    yield MetricTile(kind, id=f"tile-{kind}", classes="metric-tile")
            with Horizontal(id="home-row-b", classes="home-row"):
                yield HealthCenter(id="p-health")
                yield InsightsPanel(id="p-insights")
                yield PowerCenter(id="p-power")
            with Horizontal(id="home-row-c", classes="home-row"):
                yield StorageCenter(id="p-storage")
                yield DockerCenter(id="p-docker")
                yield ServicesPanel(id="p-services")
            with Horizontal(id="home-row-d", classes="home-row"):
                yield RadarPanel(id="p-radar")
                yield NetworkCenter(id="p-network")
                yield ChangesPanel(id="p-changes")
                yield OutlookPanel(id="p-outlook")
                yield HeatmapPanel(id="p-heatmap")

    def on_mount(self) -> None:
        self.call_after_refresh(self._relayout)

    def on_resize(self, event: Resize) -> None:
        self._relayout()

    def _relayout(self) -> None:
        width, height = self.size.width, self.size.height
        if width <= 0 or height <= 0:
            return
        plan = plan_layout(width, height)
        self.set_class(plan["narrow"], "-stacked")
        tiles = self.query_one("#home-tiles", Grid)
        tiles.styles.grid_size_columns = plan["tile_cols"]
        tiles.styles.grid_size_rows = plan["tile_rows"]
        tiles.styles.height = plan["a"]
        side = plan["side"]
        rows = {"#home-row-b": plan["b"], "#home-row-c": plan["c"], "#home-row-d": plan["d"]}
        for selector, h in rows.items():
            row = self.query_one(selector, Horizontal)
            row.styles.height = "auto" if plan["narrow"] else h
        fixed = {"#p-health": side, "#p-power": side, "#p-storage": side, "#p-services": side,
                 "#p-outlook": side, "#p-radar": 30, "#p-heatmap": 34}
        for selector, w in fixed.items():
            panel = self.query_one(selector)
            if plan["narrow"]:
                panel.styles.width = "100%"
                panel.styles.height = plan["b"] if selector in ("#p-health", "#p-power") else plan["c"]
            else:
                panel.styles.width = w
                panel.styles.height = "100%"
        for selector in ("#p-insights", "#p-docker", "#p-network", "#p-changes"):
            panel = self.query_one(selector)
            panel.styles.width = "100%" if plan["narrow"] else "1fr"
            panel.styles.height = plan["b"] if plan["narrow"] else "100%"
        self.query_one("#p-radar").display = plan["radar"]
        self.query_one("#p-heatmap").display = plan["heatmap"]

    def focus_default(self) -> None:
        self.query_one("#home-scroll").focus()

    def update_snapshot(self, snap: Snapshot) -> None:
        for panel in self.query(DashPanel):
            if panel.display:
                panel.update_snapshot(snap)
