"""Reusable Textual widgets and modal screens."""

from __future__ import annotations

from collections import deque

from rich.text import Text
from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Grid, Horizontal, Vertical
from textual.screen import ModalScreen
from textual.widgets import Button, Label, Sparkline, Static

from observatory.util.format import bar_text, level_style


class Tile(Static):
    """A dashboard tile: title, big value and a one-line detail."""

    DEFAULT_CLASSES = "tile"

    def __init__(self, title: str, *, id: str | None = None) -> None:
        super().__init__(id=id)
        self.title = title
        self._value = "—"
        self._detail = ""
        self._style = "bold"

    def set(self, value: str, detail: str = "", style: str = "bold") -> None:
        self._value, self._detail, self._style = value, detail, style
        text = Text()
        text.append(self.title.upper() + "\n", style="dim")
        text.append(value + "\n", style=style)
        text.append(detail, style="italic dim")
        self.update(text)

    def on_mount(self) -> None:
        self.set(self._value, self._detail, self._style)


class Meter(Static):
    """Label + bar + value on one line, e.g. ``CPU  ██████░░░░  58.2%``."""

    def __init__(self, label: str, *, id: str | None = None, warn: float = 70, crit: float = 90) -> None:
        super().__init__(id=id)
        self.label = label
        self.warn = warn
        self.crit = crit

    def set(self, percent: float, value_text: str, width: int = 24) -> None:
        text = Text()
        text.append(f"{self.label:<8}", style="bold")
        text.append_text(bar_text(percent, width, level_style(percent, self.warn, self.crit)))
        text.append(f"  {value_text}")
        self.update(text)


class History:
    """Fixed-length rolling buffers for dashboard sparklines."""

    def __init__(self, length: int = 120) -> None:
        self.length = length
        self.series: dict[str, deque[float]] = {}

    def push(self, name: str, value: float) -> None:
        self.series.setdefault(name, deque(maxlen=self.length)).append(float(value))

    def get(self, name: str) -> list[float]:
        return list(self.series.get(name, []))


class LabeledSparkline(Vertical):
    """A caption line above a sparkline."""

    DEFAULT_CLASSES = "labeled-spark"

    def __init__(self, caption: str, *, id: str | None = None) -> None:
        super().__init__(id=id)
        self.caption = caption

    def compose(self) -> ComposeResult:
        yield Static(self.caption, classes="spark-caption")
        yield Sparkline([], summary_function=max, classes="spark")

    def set(self, data: list[float], caption: str | None = None) -> None:
        if caption is not None:
            self.query_one(".spark-caption", Static).update(caption)
        self.query_one(Sparkline).data = data or [0.0]


class ConfirmScreen(ModalScreen[bool]):
    """Yes/No confirmation dialog. Dismisses with True on confirm."""

    BINDINGS = [
        Binding("y", "confirm", "Yes"),
        Binding("n,escape", "cancel", "No"),
    ]

    def __init__(self, title: str, message: str, confirm_label: str = "Yes", danger: bool = True) -> None:
        super().__init__()
        self.title_text = title
        self.message = message
        self.confirm_label = confirm_label
        self.danger = danger

    def compose(self) -> ComposeResult:
        with Vertical(id="dialog"):
            yield Label(self.title_text, id="dialog-title")
            yield Static(self.message, id="dialog-message")
            with Horizontal(id="dialog-buttons"):
                yield Button(f"{self.confirm_label} (y)", variant="error" if self.danger else "primary", id="yes")
                yield Button("Cancel (n)", variant="default", id="no")

    def on_mount(self) -> None:
        self.query_one("#no", Button).focus()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        self.dismiss(event.button.id == "yes")

    def action_confirm(self) -> None:
        self.dismiss(True)

    def action_cancel(self) -> None:
        self.dismiss(False)


HELP_TEXT = """\
[b]Navigation[/b] (letters or digits)
  H Home        P Processes   D Docker      S Storage
  N Network     W Power       A Analytics   F Forecasts
  L Alerts      M Media       , Settings    T Themes
  space  Pause / resume      ?  This help      q  Quit
  Inside a screen its own keys win (e.g. p sorts by PID on Processes);
  use the capital letter to switch screens from there.

[b]Processes[/b]
  /  Search    Esc  Clear    c m p n  Sort CPU / memory / PID / name
  k  Terminate (SIGTERM)    K  Kill (SIGKILL)

[b]Docker[/b]
  r  Restart container      x  Start / stop container

[b]Alerts[/b]
  a  Acknowledge selected   e  Acknowledge every alert   x  Clear resolved

[b]Settings[/b]
  Edit values, then Save (ctrl+s). Changes apply immediately.
"""


class ThemeScreen(ModalScreen[str | None]):
    """Theme picker with live preview: highlight to preview, Enter to keep, Esc to cancel."""

    BINDINGS = [Binding("escape", "cancel", "Cancel")]

    def __init__(self, current: str, available: list[str]) -> None:
        super().__init__()
        self.current = current
        from observatory.ui.themes import THEME_DESCRIPTIONS, THEMES

        ours = [name for name in THEMES if name in available]
        others = sorted(n for n in available if n not in THEMES and not n.startswith("textual-ansi"))
        self.names = ours + others
        self.descriptions = THEME_DESCRIPTIONS

    def compose(self) -> ComposeResult:
        from textual.widgets import OptionList
        from textual.widgets.option_list import Option

        with Vertical(id="dialog"):
            yield Label("Themes — preview with ↑/↓, Enter to keep, Esc to cancel", id="dialog-title")
            options = []
            for name in self.names:
                desc = self.descriptions.get(name, "Textual built-in theme")
                options.append(Option(f"{name:<20} {desc}", id=name))
            yield OptionList(*options, id="theme-list")

    def on_mount(self) -> None:
        from textual.widgets import OptionList

        option_list = self.query_one("#theme-list", OptionList)
        if self.current in self.names:
            option_list.highlighted = self.names.index(self.current)
        option_list.focus()

    def on_option_list_option_highlighted(self, event) -> None:
        if event.option.id:
            self.app.theme = event.option.id

    def on_option_list_option_selected(self, event) -> None:
        self.dismiss(event.option.id)

    def action_cancel(self) -> None:
        self.dismiss(None)


class HelpScreen(ModalScreen[None]):
    BINDINGS = [Binding("escape,q,question_mark", "close", "Close")]

    def compose(self) -> ComposeResult:
        with Vertical(id="dialog"):
            yield Label("Observatory — keys", id="dialog-title")
            yield Static(HELP_TEXT, id="dialog-message")
            with Horizontal(id="dialog-buttons"):
                yield Button("Close", variant="primary", id="close")

    def on_button_pressed(self, _event: Button.Pressed) -> None:
        self.dismiss(None)

    def action_close(self) -> None:
        self.dismiss(None)


class TileGrid(Grid):
    DEFAULT_CLASSES = "tile-grid"
