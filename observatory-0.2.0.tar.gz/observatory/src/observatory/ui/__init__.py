"""Textual user interface."""
