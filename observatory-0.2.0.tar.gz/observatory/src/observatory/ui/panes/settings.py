"""Settings: edit configuration (utility rate, power inputs, thresholds, storage)
and review detected hardware and the live power breakdown."""

from __future__ import annotations

from dataclasses import dataclass

from rich.text import Text
from textual import on
from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.widgets import Button, DataTable, Input, Label, Static, Switch

from observatory.config import Config, save_config
from observatory.engines.power import energy_projection
from observatory.models import Snapshot
from observatory.services.monitor import copy_config
from observatory.ui.panes.base import Pane, refill_table
from observatory.util.format import fmt_money


@dataclass(frozen=True, slots=True)
class FieldSpec:
    section: str
    key: str
    label: str
    kind: str  # float | int | str | bool | list
    help: str = ""

    @property
    def widget_id(self) -> str:
        return f"set-{self.section}-{self.key}"


FIELDS: list[tuple[str, list[FieldSpec]]] = [
    ("Electricity cost", [
        FieldSpec("cost", "rate_per_kwh", "Utility rate per kWh", "float", "From your bill: total ÷ kWh"),
        FieldSpec("cost", "currency", "Currency code", "str"),
        FieldSpec("cost", "currency_symbol", "Currency symbol", "str"),
        FieldSpec("cost", "fixed_daily_charge", "Fixed charge per day to include", "float", "0 = energy only"),
    ]),
    ("Power estimation", [
        FieldSpec("power", "cpu_model", "CPU model override", "str", "Blank = auto-detect"),
        FieldSpec("power", "gpu_model", "Discrete GPU override", "str", "Blank = auto, 'none' = no dGPU"),
        FieldSpec("power", "ram_gb", "RAM (GB)", "float", "0 = auto-detect"),
        FieldSpec("power", "dimm_count", "Memory modules (DIMMs)", "int", "0 = estimate from RAM size"),
        FieldSpec("power", "psu_efficiency", "PSU efficiency (0.50-0.99)", "float", "80+ Bronze ≈0.85, Gold ≈0.90"),
        FieldSpec("power", "platform_watts", "Board/fans allowance (W)", "float", "-1 = auto by chassis"),
        FieldSpec("power", "extra_watts", "Extra devices on same meter (W)", "float", "Switch, modem, HBA…"),
        FieldSpec("power", "spun_down_drives", "Drives normally spun down", "list", "Comma list, e.g. sdc,sdd"),
        FieldSpec("power", "use_rapl", "Use RAPL CPU energy counters", "bool"),
        FieldSpec("power", "use_gpu_sensors", "Use GPU power sensors", "bool"),
    ]),
    ("Alerts & anomaly detection", [
        FieldSpec("alerts", "enabled", "Anomaly detection enabled", "bool"),
        FieldSpec("alerts", "cpu_spike_percent", "CPU spike threshold (%)", "float"),
        FieldSpec("alerts", "cpu_spike_samples", "CPU spike sustained samples", "int"),
        FieldSpec("alerts", "memory_leak_window_minutes", "Memory leak window (min)", "int"),
        FieldSpec("alerts", "memory_leak_min_mb", "Memory leak minimum growth (MB)", "float"),
        FieldSpec("alerts", "disk_util_percent", "Disk busy threshold (%)", "float"),
        FieldSpec("alerts", "disk_busy_samples", "Disk busy sustained samples", "int"),
        FieldSpec("alerts", "network_spike_mbps", "Network spike minimum (Mbit/s)", "float"),
        FieldSpec("alerts", "temp_warning_c", "CPU/GPU warning temp (°C)", "float"),
        FieldSpec("alerts", "temp_critical_c", "CPU/GPU critical temp (°C)", "float"),
        FieldSpec("alerts", "drive_temp_warning_c", "Drive warning temp (°C)", "float"),
        FieldSpec("alerts", "cooldown_minutes", "Re-alert cool-down (min)", "int"),
    ]),
    ("Monitoring & storage", [
        FieldSpec("general", "refresh_interval", "UI refresh interval (s)", "float"),
        FieldSpec("storage", "sample_interval", "History sample interval (s)", "float"),
        FieldSpec("storage", "retention_raw_days", "Keep raw samples (days)", "int"),
        FieldSpec("storage", "retention_1m_days", "Keep 1-minute rollups (days)", "int"),
        FieldSpec("storage", "retention_1h_days", "Keep hourly rollups (days)", "int"),
        FieldSpec("storage", "retention_1d_days", "Keep daily rollups (days, 0 = forever)", "int"),
        FieldSpec("docker", "enabled", "Docker integration", "bool"),
        FieldSpec("docker", "socket", "Docker socket path", "str"),
        FieldSpec("ui", "confirm_actions", "Confirm kill/stop/restart", "bool"),
    ]),
]
ALL_FIELDS = [f for _title, group in FIELDS for f in group]


def value_to_text(value) -> str:
    if isinstance(value, list):
        return ", ".join(value)
    if isinstance(value, float):
        return f"{value:g}"
    return str(value)


def parse_field(spec: FieldSpec, raw) -> object:
    if spec.kind == "bool":
        return bool(raw)
    text = str(raw).strip()
    if spec.kind == "float":
        return float(text)
    if spec.kind == "int":
        return int(float(text))
    if spec.kind == "list":
        return [part.strip() for part in text.split(",") if part.strip()]
    return text


def apply_fields(base: Config, values: dict[str, object]) -> tuple[Config, list[str]]:
    """Return a new Config with ``values`` (widget_id → raw) applied, plus errors."""
    cfg = copy_config(base)
    errors: list[str] = []
    for spec in ALL_FIELDS:
        if spec.widget_id not in values:
            continue
        try:
            parsed = parse_field(spec, values[spec.widget_id])
        except (TypeError, ValueError):
            errors.append(f"{spec.label}: not a valid {spec.kind}")
            continue
        setattr(getattr(cfg, spec.section), spec.key, parsed)
    errors.extend(cfg.validate())
    return cfg, errors


class SettingsPane(Pane):
    BINDINGS = [Binding("ctrl+s", "save", "Save settings")]

    def compose(self) -> ComposeResult:
        with Horizontal(id="settings-body"):
            with VerticalScroll(id="settings-form"):
                with Horizontal(id="settings-buttons"):
                    yield Button("Save (ctrl+s)", variant="primary", id="settings-save")
                    yield Button("Revert", id="settings-revert")
                yield Static(id="settings-path", classes="status-line")
                for title, group in FIELDS:
                    yield Static(title, classes="panel-title")
                    for spec in group:
                        with Horizontal(classes="field-row"):
                            yield Label(spec.label, classes="field-label")
                            if spec.kind == "bool":
                                yield Switch(id=spec.widget_id)
                            else:
                                input_type = {"float": "number", "int": "integer"}.get(spec.kind, "text")
                                yield Input(id=spec.widget_id, type=input_type, classes="field-input")
                            yield Static(spec.help, classes="field-help")
            with Vertical(id="settings-side", classes="panel"):
                yield Static("Detected hardware", classes="panel-title")
                yield Static(id="hw-summary")
                yield Static("Live power breakdown", classes="panel-title")
                yield DataTable(id="power-table", cursor_type="row", zebra_stripes=True)
                yield Static(id="energy-summary")

    def on_mount(self) -> None:
        table = self.query_one("#power-table", DataTable)
        table.add_column("Component", key="name", width=28)
        table.add_column("Watts", key="w", width=8)
        table.add_column("Method", key="m", width=11)
        self.load_values(self.service.cfg)
        self._render_hardware()

    def load_values(self, cfg: Config) -> None:
        for spec in ALL_FIELDS:
            value = getattr(getattr(cfg, spec.section), spec.key)
            if spec.kind == "bool":
                self.query_one(f"#{spec.widget_id}", Switch).value = bool(value)
            else:
                self.query_one(f"#{spec.widget_id}", Input).value = value_to_text(value)
        path = cfg.source_path or "(defaults — Save will create a config file)"
        self.query_one("#settings-path", Static).update(Text(f"Config file: {path}", style="dim"))

    def _collect_values(self) -> dict[str, object]:
        values: dict[str, object] = {}
        for spec in ALL_FIELDS:
            if spec.kind == "bool":
                values[spec.widget_id] = self.query_one(f"#{spec.widget_id}", Switch).value
            else:
                values[spec.widget_id] = self.query_one(f"#{spec.widget_id}", Input).value
        return values

    @on(Button.Pressed, "#settings-save")
    def _save_pressed(self) -> None:
        self.action_save()

    @on(Button.Pressed, "#settings-revert")
    def _revert_pressed(self) -> None:
        self.load_values(self.service.cfg)
        self.app.notify("Reverted unsaved changes.")

    def action_save(self) -> None:
        new_cfg, errors = apply_fields(self.service.cfg, self._collect_values())
        hard_errors = [e for e in errors if "not a valid" in e]
        if hard_errors:
            self.app.notify("\n".join(hard_errors), title="Settings not saved", severity="error", timeout=8)
            return
        if errors:
            self.app.notify("\n".join(errors), title="Adjusted out-of-range values", severity="warning", timeout=8)
        try:
            path = save_config(new_cfg)
            message = f"Saved to {path}"
            severity = "information"
        except OSError as exc:
            message = f"Applied for this session, but could not write the config file: {exc}"
            severity = "warning"
        self.service.apply_config(new_cfg)
        self.obs_app.on_config_changed()
        self.load_values(new_cfg)
        self._render_hardware()
        self.app.notify(message, severity=severity, timeout=6)

    def _render_hardware(self) -> None:
        hw = self.service.hardware
        text = Text()
        for line in hw.summary_lines():
            key, _, rest = line.partition(": ")
            text.append(f"{key}: ", style="bold")
            text.append(rest + "\n")
        if hw.virtualization:
            text.append("Running virtualized: the estimate approximates this guest's share only.\n", style="yellow")
        self.query_one("#hw-summary", Static).update(text)

    def update_snapshot(self, snap: Snapshot) -> None:
        rows = []
        for comp in snap.power.components:
            style = {"measured": "green", "configured": "cyan"}.get(comp.method, "")
            rows.append((comp.name, (comp.name, Text(f"{comp.watts:.1f}", justify="right"),
                                     Text(comp.method, style=style))))
        refill_table(self.query_one("#power-table", DataTable), rows)
        p = snap.power
        proj = energy_projection(snap.cost.average_watts or p.wall_watts)
        sym = snap.cost.currency_symbol
        rate = snap.cost.rate_per_kwh
        text = Text()
        text.append("DC load ", style="bold")
        text.append(f"{p.dc_watts:.1f} W ÷ PSU {p.psu_efficiency:.2f} → ")
        text.append(f"{p.wall_watts:.1f} W at the wall", style="bold cyan")
        text.append(f" (range {p.low_watts:.0f}–{p.high_watts:.0f} W, {p.method})\n")
        text.append("Energy  ", style="bold")
        text.append(f"{proj['daily_kwh']:.2f} kWh/day · {proj['monthly_kwh']:.1f} kWh/month · "
                    f"{proj['annual_kwh']:.0f} kWh/year\n")
        text.append("Cost    ", style="bold")
        text.append(f"{fmt_money(proj['daily_kwh'] * rate, sym)}/day · {fmt_money(proj['monthly_kwh'] * rate, sym)}/month · "
                    f"{fmt_money(proj['annual_kwh'] * rate, sym)}/year at {fmt_money(rate, sym, 3)}/kWh")
        self.query_one("#energy-summary", Static).update(text)
