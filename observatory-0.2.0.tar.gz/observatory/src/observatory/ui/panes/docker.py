"""Docker: containers, resource usage, health, restart counts and controls."""

from __future__ import annotations

from rich.text import Text
from textual import on, work
from textual.app import ComposeResult
from textual.binding import Binding
from textual.widgets import DataTable, Static

from observatory.models import ContainerInfo, Snapshot
from observatory.ui.panes.base import Pane, refill_table, selected_row_key
from observatory.ui.widgets import ConfirmScreen
from observatory.util.format import fmt_bytes, fmt_rate, truncate

STATE_STYLES = {"running": "green", "exited": "red", "dead": "bold red", "paused": "yellow",
                "restarting": "bold yellow", "created": "dim"}
HEALTH_STYLES = {"healthy": "green", "unhealthy": "bold red", "starting": "yellow"}


class DockerPane(Pane):
    BINDINGS = [
        Binding("r", "container('restart')", "Restart"),
        Binding("x", "toggle", "Start/Stop"),
    ]

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self._containers: dict[str, ContainerInfo] = {}

    def compose(self) -> ComposeResult:
        yield Static(id="docker-status", classes="status-line")
        yield DataTable(id="docker-table", cursor_type="row", zebra_stripes=True)
        yield Static(id="docker-detail", classes="detail-panel")

    def on_mount(self) -> None:
        table = self.query_one("#docker-table", DataTable)
        for label, key, width in (("Name", "name", 22), ("State", "state", 10), ("Health", "health", 9),
                                  ("CPU %", "cpu", 7), ("Memory", "mem", 10), ("Mem %", "memp", 6),
                                  ("Net ↓/s", "rx", 10), ("Net ↑/s", "tx", 10), ("Restarts", "rs", 8),
                                  ("Stack", "stack", 12), ("Image", "image", None)):
            table.add_column(label, key=key, width=width)

    @on(DataTable.RowHighlighted, "#docker-table")
    def _highlighted(self, event: DataTable.RowHighlighted) -> None:
        self._show_detail(event.row_key.value if event.row_key else None)

    def _show_detail(self, key: str | None) -> None:
        c = self._containers.get(key or "")
        panel = self.query_one("#docker-detail", Static)
        if c is None:
            panel.update("")
            return
        text = Text()
        text.append(f"{c.name}", style="bold")
        text.append(f"  {c.id[:12]}  {c.status}\n")
        text.append("Image ", style="bold")
        text.append(f"{c.image}   ")
        text.append("Ports ", style="bold")
        text.append(f"{c.ports or '—'}\n")
        text.append("Started ", style="bold")
        text.append(f"{c.started_at[:19].replace('T', ' ') or '—'}   ")
        text.append("Limit ", style="bold")
        text.append(f"{fmt_bytes(c.mem_limit) if c.mem_limit else '—'}   ")
        text.append("Compose project ", style="bold")
        text.append(c.compose_project or "—")
        panel.update(text)

    def _selected(self) -> ContainerInfo | None:
        return self._containers.get(selected_row_key(self.query_one("#docker-table", DataTable)) or "")

    def action_toggle(self) -> None:
        c = self._selected()
        if c is None:
            self.app.notify("Select a container first.", severity="warning")
            return
        self.action_container("stop" if c.state in {"running", "restarting", "paused"} else "start")

    def action_container(self, action: str) -> None:
        c = self._selected()
        if c is None:
            self.app.notify("Select a container first.", severity="warning")
            return

        def done(confirmed: bool | None) -> None:
            if confirmed:
                self.app.notify(f"{action.capitalize()}ing {c.name}…")
                self._run_action(action, c.id, c.name)

        if self.service.cfg.ui.confirm_actions and action in {"restart", "stop"}:
            self.app.push_screen(ConfirmScreen(f"{action.capitalize()} container?",
                                               f"{action.capitalize()} {c.name} ({c.image})?",
                                               action.capitalize(), danger=action == "stop"), done)
        else:
            done(True)

    @work(thread=True, group="docker-action")
    def _run_action(self, action: str, container_id: str, name: str) -> None:
        ok, message = self.service.docker_action(action, container_id, name)
        self.app.call_from_thread(self.app.notify, f"{name}: {message}" if ok else message,
                                  severity="information" if ok else "error")

    def update_snapshot(self, snap: Snapshot) -> None:
        status = self.query_one("#docker-status", Static)
        if not snap.docker_available:
            status.update(Text(f"Docker unavailable — {snap.docker_error}", style="yellow"))
        else:
            running = sum(1 for c in snap.containers if c.state == "running")
            unhealthy = sum(1 for c in snap.containers if c.health == "unhealthy")
            total_cpu = sum(c.cpu_percent for c in snap.containers)
            total_mem = sum(c.mem_usage for c in snap.containers)
            line = Text(f"{running}/{len(snap.containers)} running · CPU {total_cpu:.0f}% · memory "
                        f"{fmt_bytes(total_mem)}")
            if unhealthy:
                line.append(f" · {unhealthy} unhealthy", style="bold red")
            line.append("   r restart · x start/stop", style="dim")
            status.update(line)
        self._containers = {c.id: c for c in snap.containers}
        rows = []
        for c in snap.containers:
            restarts_style = "bold yellow" if c.restart_count else ""
            rows.append((c.id, (
                truncate(c.name, 22),
                Text(c.state, style=STATE_STYLES.get(c.state, "")),
                Text(c.health or "—", style=HEALTH_STYLES.get(c.health, "dim")),
                Text(f"{c.cpu_percent:.1f}", justify="right"),
                Text(fmt_bytes(c.mem_usage) if c.state == "running" else "—", justify="right"),
                Text(f"{c.mem_percent:.0f}" if c.mem_limit else "—", justify="right"),
                Text(fmt_rate(c.net_rx_bps), justify="right"),
                Text(fmt_rate(c.net_tx_bps), justify="right"),
                Text(str(c.restart_count), style=restarts_style, justify="right"),
                truncate(c.compose_project or "—", 12),
                truncate(c.image, 60),
            )))
        table = self.query_one("#docker-table", DataTable)
        refill_table(table, rows)
        self._show_detail(selected_row_key(table))
