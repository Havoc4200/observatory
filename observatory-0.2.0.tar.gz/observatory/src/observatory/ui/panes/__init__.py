"""UI sections."""

from observatory.ui.panes.alerts import AlertsPane
from observatory.ui.panes.analytics import AnalyticsPane
from observatory.ui.panes.deep import ForecastPane, MediaPane, PowerPane
from observatory.ui.panes.disks import DisksPane
from observatory.ui.panes.docker import DockerPane
from observatory.ui.panes.network import NetworkPane
from observatory.ui.panes.processes import ProcessesPane
from observatory.ui.panes.settings import SettingsPane

__all__ = ["AlertsPane", "AnalyticsPane", "DisksPane", "DockerPane", "ForecastPane", "MediaPane", "NetworkPane",
           "PowerPane", "ProcessesPane", "SettingsPane"]
