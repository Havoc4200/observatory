"""Observatory visual identity: themes and the palette used by Rich renderers.

Textual themes drive the widget chrome (borders, backgrounds, text) through
CSS variables. Charts are drawn with Rich styles, so :class:`Palette` exposes
the same colours, plus gradient stops, for the active theme.
"""

from __future__ import annotations

from dataclasses import dataclass

from textual.theme import Theme

# name → (Theme, chart gradient cool→hot, grid colour, muted colour)
_THEMES: list[tuple[Theme, tuple[str, ...], str, str]] = [
    (Theme(name="observatory", primary="#4cc9f0", secondary="#7b61ff", accent="#f8c537",
           success="#3ddc97", warning="#f8c537", error="#ff5d73", foreground="#d7e3f4",
           background="#0a0f1c", surface="#0f1626", panel="#141d31", dark=True),
     ("#2563eb", "#4cc9f0", "#3ddc97", "#f8c537", "#ff5d73"), "#24304a", "#6b7a99"),
    (Theme(name="observatory-light", primary="#0b6bcb", secondary="#6d4aff", accent="#c2410c",
           success="#15803d", warning="#b45309", error="#c81e3a", foreground="#1b2333",
           background="#f4f6fb", surface="#ffffff", panel="#e8edf6", dark=False),
     ("#0b6bcb", "#0891b2", "#15803d", "#b45309", "#c81e3a"), "#cdd5e3", "#6b7280"),
    (Theme(name="oled", primary="#00d1ff", secondary="#8a5cff", accent="#ffd60a",
           success="#00f5a0", warning="#ffd60a", error="#ff3b5c", foreground="#e6edf3",
           background="#000000", surface="#000000", panel="#07090d", dark=True),
     ("#0057ff", "#00d1ff", "#00f5a0", "#ffd60a", "#ff3b5c"), "#151a22", "#5c6370"),
    (Theme(name="cyberpunk", primary="#05d9e8", secondary="#ff2a6d", accent="#f9f871",
           success="#01ffc3", warning="#f9f871", error="#ff2a6d", foreground="#e0e7ff",
           background="#0d0221", surface="#140433", panel="#1d0846", dark=True),
     ("#7b2ff7", "#05d9e8", "#01ffc3", "#f9f871", "#ff2a6d"), "#2b1055", "#8a7fb5"),
    (Theme(name="retro-amber", primary="#ffb000", secondary="#ff8c00", accent="#ffd27a",
           success="#ffc740", warning="#ff8c00", error="#ff4a1c", foreground="#ffcc66",
           background="#120a00", surface="#1a0f00", panel="#221400", dark=True),
     ("#7a4a00", "#b36b00", "#ffb000", "#ffd27a", "#ff4a1c"), "#3a2400", "#9c7a3c"),
    (Theme(name="retro-green", primary="#33ff66", secondary="#1fbf4c", accent="#b6ff9e",
           success="#33ff66", warning="#d4ff4a", error="#ff5f45", foreground="#7dff9b",
           background="#001a07", surface="#00220a", panel="#002b0e", dark=True),
     ("#0b5d22", "#1fbf4c", "#33ff66", "#d4ff4a", "#ff5f45"), "#0d3d1a", "#4f9a62"),
    (Theme(name="nebula", primary="#c77dff", secondary="#48bfe3", accent="#ffb4a2",
           success="#72efdd", warning="#ffd166", error="#ef476f", foreground="#e9e3ff",
           background="#100b1f", surface="#17112c", panel="#1f173a", dark=True),
     ("#5e60ce", "#48bfe3", "#72efdd", "#ffd166", "#ef476f"), "#2c2350", "#8b80b3"),
    (Theme(name="arctic", primary="#88c0d0", secondary="#81a1c1", accent="#ebcb8b",
           success="#a3be8c", warning="#ebcb8b", error="#bf616a", foreground="#e5e9f0",
           background="#1f2430", surface="#262c39", panel="#2e3442", dark=True),
     ("#5e81ac", "#88c0d0", "#a3be8c", "#ebcb8b", "#bf616a"), "#3b4252", "#7b8394"),
]

THEMES: dict[str, Theme] = {t.name: t for t, *_ in _THEMES}
THEME_EXTRAS: dict[str, tuple[tuple[str, ...], str, str]] = {t.name: (g, grid, muted) for t, g, grid, muted in _THEMES}
THEME_DESCRIPTIONS = {
    "observatory": "Deep-space navy, cyan and gold (default)",
    "observatory-light": "Bright daylight variant for light terminals",
    "oled": "Pure black for OLED displays and wall screens",
    "cyberpunk": "Neon magenta and cyan on violet",
    "retro-amber": "1980s amber phosphor monitor",
    "retro-green": "Green phosphor terminal",
    "nebula": "Violet and teal",
    "arctic": "Calm nord-like blues",
}
DEFAULT_THEME = "observatory"


def register_themes(app) -> None:
    for theme in THEMES.values():
        app.register_theme(theme)


@dataclass(frozen=True, slots=True)
class Palette:
    primary: str
    secondary: str
    accent: str
    ok: str
    warn: str
    crit: str
    text: str
    muted: str
    grid: str
    background: str
    heat: tuple[str, ...]          # cool → hot, for "more is worse" metrics
    cool: tuple[str, ...]          # brand gradient for neutral volume metrics

    def for_score(self, score: float) -> str:
        """Colour for a 0-100 health-style score (higher is better)."""
        if score >= 90:
            return self.ok
        if score >= 75:
            return self.primary
        if score >= 55:
            return self.warn
        return self.crit

    def for_load(self, fraction: float) -> str:
        """Colour for a 0..1 utilisation (higher is worse)."""
        if fraction >= 0.9:
            return self.crit
        if fraction >= 0.7:
            return self.warn
        return self.ok

    def for_severity(self, severity: str) -> str:
        return {"critical": self.crit, "warning": self.warn, "notice": self.accent, "good": self.ok}.get(
            severity, self.primary)


def palette_for(theme_name: str, theme: Theme | None = None) -> Palette:
    theme = theme or THEMES.get(theme_name) or THEMES[DEFAULT_THEME]
    extras = THEME_EXTRAS.get(theme.name)
    if extras is None:  # a built-in Textual theme chosen by the user
        heat = (theme.primary, theme.success or theme.primary, theme.warning or "#f8c537", theme.error or "#ff5d73")
        grid, muted = ("#3a3f4b", "#7a8090") if theme.dark else ("#d0d5dd", "#6b7280")
    else:
        heat, grid, muted = extras
    return Palette(
        primary=theme.primary,
        secondary=theme.secondary or theme.primary,
        accent=theme.accent or theme.primary,
        ok=theme.success or "#3ddc97",
        warn=theme.warning or "#f8c537",
        crit=theme.error or "#ff5d73",
        text=theme.foreground or ("#e0e0e0" if theme.dark else "#202020"),
        muted=muted,
        grid=grid,
        background=theme.background or ("#000000" if theme.dark else "#ffffff"),
        heat=tuple(heat),
        cool=(theme.secondary or theme.primary, theme.primary),
    )
