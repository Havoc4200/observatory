"""Packaged data files (hardware profile database)."""
