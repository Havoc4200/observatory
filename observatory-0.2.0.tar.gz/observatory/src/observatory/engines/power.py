"""Power Intelligence Engine.

Estimates wall power as the sum of per-component DC models divided by PSU
efficiency, preferring real measurements wherever the hardware offers them:

* CPU package   — RAPL energy counters when readable (root), else profile model
* DRAM          — RAPL DRAM domain when present, else per-DIMM model
* GPU           — nvidia-smi / amdgpu board power when present, else profile model
* Storage       — per-device model by type (HDD/SSD/NVMe) and I/O utilisation
* Platform      — motherboard/chipset/fans allowance by chassis class or config

Wall watts = DC watts / psu_efficiency + extra_watts (other devices on the meter).

CPU model: P = idle + (max - idle) * u^0.8, with u the CPU utilisation in
0..1. The sub-linear exponent reflects that frequency, voltage and power rise
steeply at low utilisation as cores leave idle states and boost.
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from pathlib import Path

from observatory.config import PowerConfig
from observatory.engines.hardware import HardwareProfile, load_profile_db
from observatory.models import DiskIO, GpuStats, PowerComponent, PowerEstimate

CPU_EXPONENT = 0.8
MODEL_UNCERTAINTY = 0.25      # ±25 % for modeled components
MEASURED_UNCERTAINTY = 0.05   # ±5 % for measured components


@dataclass(slots=True)
class PowerInputs:
    cpu_percent: float
    memory_percent: float = 0.0
    gpus: list[GpuStats] | None = None
    disk_io: list[DiskIO] | None = None


class RaplReader:
    """Converts cumulative RAPL energy counters (µJ) into average watts."""

    def __init__(self, zones: list[Path]) -> None:
        self.zones = zones
        self._last: dict[Path, tuple[float, int]] = {}
        self._max_range: dict[Path, int] = {}
        for zone in zones:
            try:
                self._max_range[zone] = int((zone / "max_energy_range_uj").read_text())
            except (OSError, ValueError):
                self._max_range[zone] = 2 ** 32

    def read_watts(self) -> float | None:
        if not self.zones:
            return None
        now = time.monotonic()
        total = 0.0
        have_delta = False
        for zone in self.zones:
            try:
                energy = int((zone / "energy_uj").read_text())
            except (OSError, ValueError):
                return None
            previous = self._last.get(zone)
            self._last[zone] = (now, energy)
            if previous is None:
                continue
            dt = now - previous[0]
            delta = energy - previous[1]
            if delta < 0:  # counter wrapped
                delta += self._max_range.get(zone, 2 ** 32)
            if dt > 0:
                total += delta / 1_000_000.0 / dt
                have_delta = True
        return total if have_delta else None


class PowerEngine:
    def __init__(self, hardware: HardwareProfile, cfg: PowerConfig) -> None:
        self.hw = hardware
        self.cfg = cfg
        self._db = load_profile_db()
        self._rapl = RaplReader(hardware.rapl_domains) if cfg.use_rapl else RaplReader([])
        self._rapl_dram = RaplReader(hardware.rapl_dram_domains) if cfg.use_rapl else RaplReader([])

    def update_config(self, cfg: PowerConfig, hardware: HardwareProfile | None = None) -> None:
        self.cfg = cfg
        if hardware is not None:
            self.hw = hardware
            self._rapl = RaplReader(hardware.rapl_domains) if cfg.use_rapl else RaplReader([])
            self._rapl_dram = RaplReader(hardware.rapl_dram_domains) if cfg.use_rapl else RaplReader([])

    # ----------------------------------------------------------- components
    def cpu_watts(self, cpu_percent: float) -> PowerComponent:
        measured = self._rapl.read_watts()
        if measured is not None:
            return PowerComponent("CPU package", round(measured, 1), "measured")
        profile = self.hw.cpu_profile
        u = min(max(cpu_percent / 100.0, 0.0), 1.0)
        watts = (profile.idle_w + (profile.max_w - profile.idle_w) * (u ** CPU_EXPONENT)) * self.hw.cpu_sockets
        name = "Board (SBC)" if profile.board else "CPU package"
        return PowerComponent(name, round(watts, 1), "modeled")

    def memory_watts(self, activity: float) -> PowerComponent:
        measured = self._rapl_dram.read_watts()
        if measured is not None:
            return PowerComponent("Memory", round(measured, 1), "measured")
        if self.hw.cpu_profile.board:
            return PowerComponent("Memory", 0.0, "modeled")  # included in board figure
        mem = self._db["memory"]
        a = min(max(activity, 0.0), 1.0)
        per_dimm = mem["dimm_idle_w"] + (mem["dimm_active_w"] - mem["dimm_idle_w"]) * a
        return PowerComponent("Memory", round(per_dimm * self.hw.dimm_count, 1), "modeled")

    def gpu_watts(self, gpus: list[GpuStats]) -> list[PowerComponent]:
        components: list[PowerComponent] = []
        measured_names: set[str] = set()
        if self.cfg.use_gpu_sensors:
            for g in gpus:
                if g.power_w is not None and g.power_w > 0:
                    components.append(PowerComponent(f"GPU {g.index}: {g.name}", round(g.power_w, 1), "measured"))
                    measured_names.add(g.name.lower())
        for dev in self.hw.discrete_gpus:
            if any(_same_gpu(dev.name, m) for m in measured_names):
                continue
            profile = dev.profile
            if profile is None:
                continue
            util = None
            for g in gpus:
                if _same_gpu(dev.name, g.name.lower()) and g.util_percent is not None:
                    util = g.util_percent / 100.0
                    break
            u = util if util is not None else 0.0
            watts = profile.idle_w + (profile.max_w - profile.idle_w) * min(max(u, 0.0), 1.0)
            components.append(PowerComponent(f"GPU: {dev.name}", round(watts, 1), "modeled"))
        return components

    def storage_watts(self, disk_io: list[DiskIO]) -> PowerComponent:
        table = self._db["storage"]
        util_by_dev = {d.device: d.util_percent / 100.0 for d in disk_io}
        spun_down = {name.strip() for name in self.cfg.spun_down_drives}
        total = 0.0
        for dev in self.hw.storage:
            spec = table.get(dev.kind, table["unknown"])
            util = min(max(util_by_dev.get(dev.name, 0.0), 0.0), 1.0)
            if dev.name in spun_down and util == 0.0:
                total += spec["standby_w"]
            else:
                total += spec["idle_w"] + (spec["active_w"] - spec["idle_w"]) * util
        return PowerComponent(f"Storage ({len(self.hw.storage)} devices)", round(total, 1), "modeled")

    def platform_watts(self) -> PowerComponent:
        if self.cfg.platform_watts >= 0:
            return PowerComponent("Platform", round(self.cfg.platform_watts, 1), "configured")
        watts = self._db["platform_by_chassis"].get(self.hw.chassis, self._db["platform_by_chassis"]["unknown"])
        return PowerComponent("Platform (board, fans)", float(watts), "modeled")

    # ------------------------------------------------------------- estimate
    def idle_floor(self) -> float:
        """Modeled wall power of this hardware completely idle (no measurements),
        used as the reference for the power efficiency score."""
        p = self.hw.cpu_profile
        cpu = p.idle_w * self.hw.cpu_sockets
        mem = 0.0 if p.board else self._db["memory"]["dimm_idle_w"] * self.hw.dimm_count
        gpus = sum(d.profile.idle_w for d in self.hw.discrete_gpus if d.profile)
        table = self._db["storage"]
        spun_down = set(self.cfg.spun_down_drives)
        storage = sum(table.get(d.kind, table["unknown"])["standby_w" if d.name in spun_down else "idle_w"]
                      for d in self.hw.storage)
        platform = self.platform_watts().watts
        efficiency = min(max(self.cfg.psu_efficiency, 0.5), 0.99)
        return (cpu + mem + gpus + storage + platform) / efficiency + max(self.cfg.extra_watts, 0.0)

    def estimate(self, inputs: PowerInputs) -> PowerEstimate:
        components: list[PowerComponent] = [
            self.cpu_watts(inputs.cpu_percent),
            self.memory_watts(max(inputs.cpu_percent, inputs.memory_percent * 0.3) / 100.0),
            *self.gpu_watts(inputs.gpus or []),
            self.storage_watts(inputs.disk_io or []),
            self.platform_watts(),
        ]
        efficiency = min(max(self.cfg.psu_efficiency, 0.5), 0.99)
        dc = sum(c.watts for c in components)
        low = high = 0.0
        for c in components:
            spread = {"measured": MEASURED_UNCERTAINTY, "configured": 0.0}.get(c.method, MODEL_UNCERTAINTY)
            low += c.watts * (1 - spread)
            high += c.watts * (1 + spread)
        extra = max(self.cfg.extra_watts, 0.0)
        if extra:
            components.append(PowerComponent("Extra devices (configured)", round(extra, 1), "configured"))
        wall = dc / efficiency + extra
        return PowerEstimate(
            wall_watts=round(wall, 1),
            dc_watts=round(dc, 1),
            low_watts=round(low / efficiency + extra, 1),
            high_watts=round(high / efficiency + extra, 1),
            psu_efficiency=efficiency,
            components=components,
        )


def _same_gpu(profile_name: str, reported_lower: str) -> bool:
    """Loose match between a PCI-derived name and the driver-reported name."""
    a = profile_name.lower()
    tokens = [t for t in reported_lower.replace("nvidia", "").replace("geforce", "").split() if len(t) > 1]
    return bool(tokens) and all(t in a for t in tokens[:3])


def energy_projection(watts: float) -> dict[str, float]:
    """kWh per day / month (30.44 d) / year at a constant draw."""
    kwh_day = watts * 24 / 1000
    return {"daily_kwh": kwh_day, "monthly_kwh": kwh_day * 30.44, "annual_kwh": kwh_day * 365.25}
