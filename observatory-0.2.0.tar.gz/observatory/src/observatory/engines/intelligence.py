"""Historical context and baseline learning.

Every live number on the dashboard is shown next to its history: 24-hour
average and peak, the same time last week, the 7-day average, and a learned
baseline for this hour of the week ("normal for a Wednesday at 14:00"). This
module computes all of that from the database on a slow cadence (about once a
minute; heavier forecasts every ten minutes) so the UI only reads cached
values.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field

from observatory.engines.forecast import StorageForecast, TrendForecast, forecast_storage, forecast_trend
from observatory.engines.holtwinters import fit_holt_winters
from observatory.engines.stats import mad, median
from observatory.storage.repository import Repository, local_midnight, local_month_start

# key -> (metric, label)
TRACKED = {
    "cpu": ("cpu.percent", ""),
    "mem": ("mem.percent", ""),
    "swap": ("swap.percent", ""),
    "power": ("power.watts", ""),
    "rx": ("net.rx_bps", "_total"),
    "tx": ("net.tx_bps", "_total"),
    "temp": ("temp.max_c", ""),
    "load": ("load.1", ""),
    "health": ("health.score", ""),
}
WEEKDAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]


@dataclass(slots=True)
class Baseline:
    median: float
    spread: float          # robust spread (1.4826 × MAD)
    samples: int
    description: str       # e.g. "Wednesday 14:00" or "14:00"


@dataclass(slots=True)
class MetricContext:
    avg_1h: float | None = None
    avg_24h: float | None = None
    peak_24h: float | None = None
    peak_24h_ts: float | None = None
    low_24h: float | None = None
    low_24h_ts: float | None = None
    avg_7d: float | None = None
    avg_prev_7d: float | None = None
    last_week_now: float | None = None
    baseline: Baseline | None = None
    series_24h: list[float] = field(default_factory=list)   # 96 × 15-minute buckets, oldest first

    def vs_last_week(self, current: float) -> float | None:
        """Relative change of ``current`` against the same time last week (fraction)."""
        if self.last_week_now is None or self.last_week_now <= 0:
            return None
        return (current - self.last_week_now) / self.last_week_now


@dataclass(slots=True)
class EnergyContext:
    week_kwh: float = 0.0
    week_cost: float = 0.0
    week_hours: float = 0.0
    prev_week_kwh: float = 0.0
    prev_week_cost: float = 0.0
    prev_week_hours: float = 0.0
    month_kwh: float = 0.0
    month_cost: float = 0.0
    month_hours: float = 0.0
    last_month_kwh: float = 0.0
    last_month_cost: float = 0.0
    last_month_hours: float = 0.0
    daily_kwh_14d: list[float] = field(default_factory=list)   # oldest first
    daily_cost_14d: list[float] = field(default_factory=list)
    forecast_30d_kwh: float | None = None
    forecast_30d_cost: float | None = None
    forecast_method: str = ""

    @property
    def week_change(self) -> float | None:
        """Week-over-week change in average draw (fraction), comparing like with like."""
        if self.week_hours < 24 or self.prev_week_hours < 24 or self.prev_week_kwh <= 0:
            return None
        this = self.week_kwh / self.week_hours
        prev = self.prev_week_kwh / self.prev_week_hours
        return (this - prev) / prev if prev else None

    @property
    def month_change(self) -> float | None:
        """This month's average draw vs last month's (fraction)."""
        if self.last_month_hours < 24 * 7 or self.last_month_kwh <= 0 or self.month_hours < 24:
            return None
        this = self.month_kwh / self.month_hours
        prev = self.last_month_kwh / self.last_month_hours
        return (this - prev) / prev


@dataclass(slots=True)
class HistoricalContext:
    available: bool = False
    built_at: float = 0.0
    history_since: float | None = None
    metrics: dict[str, MetricContext] = field(default_factory=dict)
    energy: EnergyContext = field(default_factory=EnergyContext)
    restarts_today: dict[str, int] = field(default_factory=dict)
    alerts_24h: int = 0
    new_devices_24h: list[dict] = field(default_factory=list)
    devices_active_24h: int = 0
    storage: dict[str, StorageForecast] = field(default_factory=dict)
    trends: dict[str, TrendForecast] = field(default_factory=dict)
    disk_idle_24h: dict[str, float] = field(default_factory=dict)   # device -> avg util % over 24 h
    power_peak_process: str = ""          # busiest process around the 24 h power peak
    heatmap_cpu: list[list[float | None]] = field(default_factory=list)  # 7 days × 24 h, oldest day first
    heatmap_days: list[str] = field(default_factory=list)                # row labels, e.g. "Mon"
    traffic_today_bytes: float | None = None
    media_library_growth: dict[str, float] = field(default_factory=dict)  # app -> bytes/day

    def metric(self, key: str) -> MetricContext:
        return self.metrics.get(key) or MetricContext()

    @property
    def history_days(self) -> float:
        if not self.history_since:
            return 0.0
        return max((time.time() - self.history_since) / 86400, 0.0)


def hour_of_week_baseline(repo: Repository, metric: str, label: str, now: float,
                          weeks: int = 4) -> Baseline | None:
    """Median of this metric at the same weekday and hour over past weeks;
    falls back to the same hour on any day over the last 14 days."""
    lt = time.localtime(now)
    rows = repo.db.query(
        "SELECT bucket, avg FROM metrics_1h WHERE metric = ? AND label = ? AND bucket >= ? AND bucket < ?",
        (metric, label, int(now - weeks * 7 * 86400), int(now - 3600)),
    )
    same_slot, same_hour = [], []
    for r in rows:
        bt = time.localtime(r["bucket"])
        if bt.tm_hour == lt.tm_hour:
            if bt.tm_wday == lt.tm_wday:
                same_slot.append(float(r["avg"]))
            if r["bucket"] >= now - 14 * 86400:
                same_hour.append(float(r["avg"]))
    if len(same_slot) >= 2:
        values, desc = same_slot, f"{WEEKDAYS[lt.tm_wday]} {lt.tm_hour:02d}:00"
    elif len(same_hour) >= 3:
        values, desc = same_hour, f"{lt.tm_hour:02d}:00"
    else:
        return None
    center = median(values)
    return Baseline(center, 1.4826 * mad(values, center), len(values), desc)


def build_metric_context(repo: Repository, metric: str, label: str, now: float) -> MetricContext:
    ctx = MetricContext()
    ctx.avg_1h = repo.window_avg(metric, label, now - 3600, now)
    points = repo.series(metric, label, now - 86400, now, max_points=96)
    if points:
        ctx.avg_24h = sum(p.avg for p in points) / len(points)
        best = max(points, key=lambda p: p.max)
        ctx.peak_24h, ctx.peak_24h_ts = best.max, best.ts
        low = min(points, key=lambda p: p.min)
        ctx.low_24h, ctx.low_24h_ts = low.min, low.ts
        # place on a fixed 96-bucket axis (15 min each) so gaps stay visible
        buckets = [0.0] * 96
        counts = [0] * 96
        start = now - 86400
        for p in points:
            idx = min(int((p.ts - start) / 900), 95)
            if idx >= 0:
                buckets[idx] += p.avg
                counts[idx] += 1
        ctx.series_24h = [b / c if c else 0.0 for b, c in zip(buckets, counts)]
    ctx.avg_7d = repo.window_avg(metric, label, now - 7 * 86400, now)
    ctx.avg_prev_7d = repo.window_avg(metric, label, now - 14 * 86400, now - 7 * 86400)
    ctx.last_week_now = repo.window_avg(metric, label, now - 7 * 86400 - 1800, now - 7 * 86400 + 1800)
    ctx.baseline = hour_of_week_baseline(repo, metric, label, now)
    return ctx


def build_energy_context(repo: Repository, now: float, rate_per_kwh: float) -> EnergyContext:
    e = EnergyContext()
    wh, cost, secs = repo.energy_between(now - 7 * 86400, now + 1)
    e.week_kwh, e.week_cost, e.week_hours = wh / 1000, cost, secs / 3600
    wh, cost, secs = repo.energy_between(now - 14 * 86400, now - 7 * 86400)
    e.prev_week_kwh, e.prev_week_cost, e.prev_week_hours = wh / 1000, cost, secs / 3600
    month_start = local_month_start(now)
    wh, cost, secs = repo.energy_between(month_start, now + 1)
    e.month_kwh, e.month_cost, e.month_hours = wh / 1000, cost, secs / 3600
    prev_month_start = local_month_start(month_start - 86400)
    wh, cost, secs = repo.energy_between(prev_month_start, month_start)
    e.last_month_kwh, e.last_month_cost, e.last_month_hours = wh / 1000, cost, secs / 3600
    days = list(reversed(repo.energy_daily(14, now)))
    e.daily_kwh_14d = [d.kwh for d in days]
    e.daily_cost_14d = [d.cost for d in days]

    # 30-day forecast: Holt-Winters on hourly mean watts when ≥ 2 days exist,
    # otherwise the observed average draw.
    rows = repo.db.query("SELECT hour, wh, seconds FROM energy_hourly WHERE hour >= ? ORDER BY hour",
                         (int(now - 14 * 86400),))
    hourly_w = [r["wh"] / (r["seconds"] / 3600) for r in rows if r["seconds"] >= 600]
    model = fit_holt_winters(hourly_w, 24) if len(hourly_w) >= 48 else None
    if model is not None:
        forecast = [max(v, 0.0) for v in model.forecast(30 * 24)]
        e.forecast_30d_kwh = sum(forecast) / 1000
        e.forecast_method = "Holt-Winters (daily seasonality)"
    elif hourly_w:
        e.forecast_30d_kwh = sum(hourly_w) / len(hourly_w) * 24 * 30 / 1000
        e.forecast_method = "average draw"
    if e.forecast_30d_kwh is not None:
        e.forecast_30d_cost = e.forecast_30d_kwh * rate_per_kwh
    return e


def build_heatmap(repo: Repository, metric: str, label: str, now: float,
                  days: int = 7) -> tuple[list[list[float | None]], list[str]]:
    """Hourly averages for the last ``days`` local days (rows) × 24 hours (columns)."""
    first_day = local_midnight(now)
    for _ in range(days - 1):
        first_day = local_midnight(first_day - 3600)
    points = repo.series(metric, label, first_day, now, max_points=days * 24)
    sums: dict[tuple[int, int], list[float]] = {}
    day_starts = [first_day]
    for _ in range(days - 1):
        day_starts.append(local_midnight(day_starts[-1] + 26 * 3600))
    for p in points:
        lt = time.localtime(p.ts)
        day = local_midnight(p.ts)
        try:
            r = day_starts.index(day)
        except ValueError:
            continue
        sums.setdefault((r, lt.tm_hour), []).append(p.avg)
    matrix: list[list[float | None]] = []
    for r in range(days):
        row: list[float | None] = []
        for h in range(24):
            vals = sums.get((r, h))
            row.append(sum(vals) / len(vals) if vals else None)
        matrix.append(row)
    labels = [time.strftime("%a", time.localtime(d + 3600)) for d in day_starts]
    return matrix, labels


class ContextBuilder:
    """Caches HistoricalContext; refresh cadence is driven by the caller."""

    LIGHT_EVERY = 60.0
    HEAVY_EVERY = 600.0

    def __init__(self, repo: Repository | None) -> None:
        self.repo = repo
        self.context = HistoricalContext()
        self._light_at = 0.0
        self._heavy_at = 0.0

    def due(self, now: float) -> bool:
        return self.repo is not None and now - self._light_at >= self.LIGHT_EVERY

    def build(self, now: float, rate_per_kwh: float, mounts: list[tuple[str, float, float]],
              disk_devices: list[str], media_apps: list[str] | None = None) -> HistoricalContext:
        repo = self.repo
        if repo is None:
            return self.context
        ctx = HistoricalContext(available=True, built_at=now)
        ctx.history_since = repo.first_sample_ts()
        for key, (metric, label) in TRACKED.items():
            ctx.metrics[key] = build_metric_context(repo, metric, label, now)
        ctx.energy = build_energy_context(repo, now, rate_per_kwh)
        midnight = local_midnight(now)
        ctx.restarts_today = repo.event_subject_counts("container_restart", midnight)
        ctx.alerts_24h = repo.count_events("alert_fired", now - 86400)
        ctx.new_devices_24h = repo.new_devices(now - 86400)
        ctx.devices_active_24h = repo.device_count(now - 86400)
        power = ctx.metrics.get("power")
        if power is not None and power.peak_24h_ts:
            row = repo.db.query_one(
                "SELECT name FROM process_samples WHERE ts BETWEEN ? AND ? ORDER BY cpu DESC LIMIT 1",
                (int(power.peak_24h_ts) - 600, int(power.peak_24h_ts) + 1500))
            ctx.power_peak_process = row["name"] if row else ""
        ctx.heatmap_cpu, ctx.heatmap_days = build_heatmap(repo, "cpu.percent", "", now)
        midnight_today = local_midnight(now)
        rx_today = repo.window_avg("net.rx_bps", "_total", midnight_today, now)
        tx_today = repo.window_avg("net.tx_bps", "_total", midnight_today, now)
        if rx_today is not None or tx_today is not None:
            ctx.traffic_today_bytes = ((rx_today or 0) + (tx_today or 0)) * (now - midnight_today)
        for dev in disk_devices:
            avg = repo.window_avg("disk.util", dev, now - 86400, now)
            if avg is not None:
                ctx.disk_idle_24h[dev] = avg
        heavy_due = now - self._heavy_at >= self.HEAVY_EVERY
        if heavy_due:
            self._heavy_at = now
            for mount, total, used in mounts:
                ctx.storage[mount] = forecast_storage(repo, mount, total, used, now=now)
            for key in ("mem", "cpu"):
                metric, label = TRACKED[key]
                trend = forecast_trend(repo, metric, label, 7, now)
                if trend is not None:
                    ctx.trends[key] = trend
            for app in media_apps or []:
                trend = forecast_trend(repo, "media.library_bytes", app, 7, now)
                if trend is not None:
                    ctx.media_library_growth[app] = trend.slope_per_day
        else:
            ctx.storage = self.context.storage
            ctx.trends = self.context.trends
            ctx.media_library_growth = self.context.media_library_growth
        self._light_at = now
        self.context = ctx
        return ctx
