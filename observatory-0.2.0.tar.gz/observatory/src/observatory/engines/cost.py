"""Cost Intelligence Engine.

Energy is integrated into ``energy_hourly`` using the rate in force at the
time, so changing the rate never rewrites past costs. Projections fill every
hour without data (before install, downtime, the rest of the period) with the
recent average draw priced at the current rate.
"""

from __future__ import annotations

import calendar
import time
from dataclasses import dataclass

from observatory.config import CostConfig
from observatory.models import CostSnapshot
from observatory.storage.repository import Repository, local_midnight, local_month_start

AVERAGE_WINDOW_DAYS = 7
MIN_COVERAGE_SECONDS = 1800  # need 30 min of history before trusting the average


def hourly_cost(watts: float, rate_per_kwh: float) -> float:
    return max(watts, 0.0) / 1000.0 * rate_per_kwh


def days_in_month(ts: float) -> int:
    lt = time.localtime(ts)
    return calendar.monthrange(lt.tm_year, lt.tm_mon)[1]


@dataclass(slots=True)
class CostEngine:
    cfg: CostConfig
    repo: Repository | None = None

    def update_config(self, cfg: CostConfig) -> None:
        self.cfg = cfg

    def average_watts(self, now: float, current_watts: float) -> float:
        if self.repo is None:
            return current_watts
        wh, _cost, seconds = self.repo.energy_between(now - AVERAGE_WINDOW_DAYS * 86400, now + 1)
        if seconds < MIN_COVERAGE_SECONDS:
            return current_watts
        return wh / (seconds / 3600.0)

    def compute(self, current_watts: float, now: float | None = None) -> CostSnapshot:
        now = now if now is not None else time.time()
        rate = self.cfg.rate_per_kwh
        fixed = self.cfg.fixed_daily_charge
        avg_w = self.average_watts(now, current_watts)
        avg_kw = avg_w / 1000.0

        midnight = local_midnight(now)
        month_start = local_month_start(now)
        if self.repo is not None:
            today_wh, today_cost, _ = self.repo.energy_between(midnight, now + 1)
            mtd_wh, mtd_cost, mtd_seconds = self.repo.energy_between(month_start, now + 1)
        else:
            today_wh = today_cost = mtd_wh = mtd_cost = mtd_seconds = 0.0

        day_fraction = min(max((now - midnight) / 86400.0, 0.0), 1.0)
        today_cost += fixed * day_fraction

        month_hours = days_in_month(now) * 24.0
        uncovered_hours = max(month_hours - mtd_seconds / 3600.0, 0.0)
        monthly_kwh = mtd_wh / 1000.0 + uncovered_hours * avg_kw
        monthly_cost = mtd_cost + uncovered_hours * avg_kw * rate + fixed * days_in_month(now)
        elapsed_days = (now - month_start) / 86400.0

        return CostSnapshot(
            currency_symbol=self.cfg.currency_symbol,
            currency=self.cfg.currency,
            rate_per_kwh=rate,
            hourly_cost=hourly_cost(current_watts, rate),
            today_kwh=today_wh / 1000.0,
            today_cost=today_cost,
            projected_daily_kwh=avg_kw * 24.0,
            month_to_date_cost=mtd_cost + fixed * elapsed_days,
            monthly_kwh_estimate=monthly_kwh,
            monthly_estimate=monthly_cost,
            annual_estimate=avg_kw * 24.0 * 365.25 * rate + fixed * 365.25,
            average_watts=avg_w,
        )
