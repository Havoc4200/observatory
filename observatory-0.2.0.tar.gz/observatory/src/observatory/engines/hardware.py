"""Hardware detection and the hardware profile database.

Detection is read-only and works without root: /proc/cpuinfo, sysfs (DMI,
PCI, block devices, powercap) and psutil. The resulting
:class:`HardwareProfile` is the input to the power engine.
"""

from __future__ import annotations

import json
import math
import re
import time
from dataclasses import dataclass, field
from functools import lru_cache
from importlib import resources
from pathlib import Path
from typing import Any

import psutil

from observatory.collectors.disks import scan_storage_devices
from observatory.collectors.system import read_cpu_model
from observatory.config import PowerConfig
from observatory.models import StorageDevice
from observatory.util.pci import PciDevice, scan_pci

DMI = Path("/sys/class/dmi/id")
POWERCAP = Path("/sys/class/powercap")
SYS_CPU = Path("/sys/devices/system/cpu")
POWER_SUPPLY = Path("/sys/class/power_supply")

# SMBIOS chassis type codes → coarse class
CHASSIS_CLASSES = {
    3: "desktop", 4: "desktop", 5: "desktop", 6: "desktop", 7: "desktop", 15: "desktop", 16: "desktop",
    24: "desktop", 8: "laptop", 9: "laptop", 10: "laptop", 14: "laptop", 31: "laptop", 32: "laptop",
    30: "laptop", 13: "all_in_one", 17: "server", 23: "server", 25: "server", 28: "server", 29: "server",
    35: "mini", 36: "mini",
}

VIRTUAL_VENDORS = ("qemu", "kvm", "vmware", "virtualbox", "innotek", "xen", "microsoft corporation",
                   "parallels", "bochs", "amazon ec2", "google", "digitalocean", "hetzner", "openstack")

INTEGRATED_GPU_HINTS = ("uhd graphics", "iris", "hd graphics", "vega series", "radeon graphics",
                        "renoir", "cezanne", "lucienne", "barcelo", "rembrandt", "phoenix", "raphael",
                        "picasso", "raven", "mendocino", "granite ridge", "hawk point", "strix",
                        "radeon 6[0-9]0m", "radeon 7[0-9]0m", "alder lake", "raptor lake", "tiger lake",
                        "jasper lake", "elkhart lake", "gemini lake", "coffeelake", "comet lake",
                        "rocket lake", "meteor lake", "arrow lake", "lunar lake", "skylake", "kaby lake",
                        "haswell", "ivy bridge", "sandy bridge", "broadwell", "xe graphics")
BMC_VENDORS = ("1a03", "102b", "1234", "15ad", "1af4", "1b36")  # ASPEED, Matrox, QEMU, VMware, virtio, Red Hat


# ---------------------------------------------------------------- profile DB
@dataclass(slots=True)
class ComponentProfile:
    idle_w: float
    max_w: float
    board: bool = False
    source: str = "profile"  # profile | heuristic | override
    pattern: str = ""


@lru_cache(maxsize=1)
def load_profile_db() -> dict[str, Any]:
    text = resources.files("observatory.data").joinpath("hardware_profiles.json").read_text(encoding="utf-8")
    db = json.loads(text)
    for section in ("cpu", "gpu"):
        for entry in db[section]:
            entry["_re"] = re.compile(entry["pattern"], re.IGNORECASE)
    return db


def match_cpu_profile(model: str) -> ComponentProfile:
    for entry in load_profile_db()["cpu"]:
        if entry["_re"].search(model):
            return ComponentProfile(entry["idle_w"], entry["max_w"], bool(entry.get("board")), "profile",
                                    entry["pattern"])
    return heuristic_cpu_profile(model)


def heuristic_cpu_profile(model: str) -> ComponentProfile:
    """Estimate from naming conventions when the model is not in the database."""
    m = model.lower()
    cores = psutil.cpu_count(logical=False) or 4
    if re.search(r"\d{4,5}(u|y)\b", m):
        idle, peak = 2.5, 25.0
    elif re.search(r"\d{4,5}(hs|hx|h)\b", m):
        idle, peak = 5.0, 60.0
    elif re.search(r"\d{4,5}t\b", m):
        idle, peak = 4.0, 40.0
    elif re.search(r"\d{4,5}k", m):
        idle, peak = 9.0, 180.0
    elif any(arch in m for arch in ("arm", "aarch64", "cortex", "armv")):
        idle, peak = 2.0, 8.0
    else:
        # generic desktop-class part: scale with physical cores
        idle = 6.0 + 0.5 * cores
        peak = min(max(35.0, 9.0 * cores), 250.0)
    return ComponentProfile(idle, peak, False, "heuristic")


def match_gpu_profile(name: str) -> ComponentProfile:
    for entry in load_profile_db()["gpu"]:
        if entry["_re"].search(name):
            return ComponentProfile(entry["idle_w"], entry["max_w"], False, "profile", entry["pattern"])
    return ComponentProfile(10.0, 150.0, False, "heuristic")


# ------------------------------------------------------------- detected model
@dataclass(slots=True)
class GpuDevice:
    name: str
    vendor: str
    discrete: bool
    pci_address: str = ""
    profile: ComponentProfile | None = None


@dataclass(slots=True)
class HardwareProfile:
    cpu_model: str
    cpu_sockets: int
    cpu_cores: int
    cpu_threads: int
    cpu_profile: ComponentProfile
    ram_bytes: int
    dimm_count: int
    gpus: list[GpuDevice] = field(default_factory=list)
    storage: list[StorageDevice] = field(default_factory=list)
    chassis: str = "unknown"
    virtualization: str = ""
    has_battery: bool = False
    rapl_domains: list[Path] = field(default_factory=list)
    rapl_dram_domains: list[Path] = field(default_factory=list)
    detected_at: float = field(default_factory=time.time)

    @property
    def ram_gb(self) -> float:
        return self.ram_bytes / (1024 ** 3)

    @property
    def discrete_gpus(self) -> list[GpuDevice]:
        return [g for g in self.gpus if g.discrete]

    def summary_lines(self) -> list[str]:
        lines = [
            f"CPU: {self.cpu_model} ({self.cpu_sockets} socket(s), {self.cpu_cores} cores / "
            f"{self.cpu_threads} threads) — profile {self.cpu_profile.idle_w:.0f}-{self.cpu_profile.max_w:.0f} W "
            f"[{self.cpu_profile.source}]",
            f"RAM: {self.ram_gb:.1f} GiB in ~{self.dimm_count} DIMM(s)",
        ]
        for g in self.gpus:
            kind = "discrete" if g.discrete else "integrated/BMC"
            extra = ""
            if g.discrete and g.profile:
                extra = f" — profile {g.profile.idle_w:.0f}-{g.profile.max_w:.0f} W [{g.profile.source}]"
            lines.append(f"GPU: {g.name} ({kind}){extra}")
        for d in self.storage:
            lines.append(f"Disk: {d.name} {d.kind.upper()} {d.model or ''} {d.size_bytes / 1e9:.0f} GB".rstrip())
        lines.append(f"Chassis: {self.chassis}" + (f", virtualized ({self.virtualization})" if self.virtualization else ""))
        lines.append("RAPL energy counters: " + ("readable" if self.rapl_domains else "not readable (needs root)"))
        return lines


def _read(path: Path, default: str = "") -> str:
    try:
        return path.read_text(errors="replace").strip()
    except OSError:
        return default


def detect_chassis(dmi: Path = DMI) -> str:
    try:
        code = int(_read(dmi / "chassis_type", "0") or 0)
    except ValueError:
        code = 0
    return CHASSIS_CLASSES.get(code, "unknown")


def detect_virtualization(dmi: Path = DMI) -> str:
    vendor = " ".join((_read(dmi / "sys_vendor"), _read(dmi / "product_name"), _read(dmi / "board_vendor"))).lower()
    for marker in VIRTUAL_VENDORS:
        if marker in vendor:
            return marker
    if Path("/proc/vz").exists() and not Path("/proc/bc").exists():
        return "openvz"
    try:
        with open("/proc/1/environ", "rb") as fh:
            if b"container=lxc" in fh.read():
                return "lxc"
    except OSError:
        pass
    for line in _read(Path("/proc/cpuinfo")).splitlines():
        if line.startswith("flags") and " hypervisor" in line:
            return "hypervisor"
    return ""


def count_sockets(sys_cpu: Path = SYS_CPU) -> int:
    ids = set()
    for topo in sys_cpu.glob("cpu[0-9]*/topology/physical_package_id"):
        value = _read(topo)
        if value and value != "-1":
            ids.add(value)
    return max(len(ids), 1)


def estimate_dimms(ram_gb: float) -> int:
    if ram_gb <= 0:
        return 1
    if ram_gb <= 8.5:
        return 1
    if ram_gb <= 17:
        return 2
    if ram_gb <= 66:
        return max(2, math.ceil(ram_gb / 16))
    return min(max(4, math.ceil(ram_gb / 32)), 24)


def find_rapl_domains(powercap: Path = POWERCAP) -> tuple[list[Path], list[Path]]:
    """Return readable (package, dram) RAPL energy counters."""
    packages: list[Path] = []
    dram: list[Path] = []
    if not powercap.is_dir():
        return packages, dram
    for zone in sorted(powercap.glob("intel-rapl:*")):
        energy = zone / "energy_uj"
        name = _read(zone / "name").lower()
        try:
            int(energy.read_text())
        except (OSError, ValueError):
            continue
        if zone.name.count(":") == 1 and name.startswith("package"):
            packages.append(zone)
        elif name == "dram":
            dram.append(zone)
    return packages, dram


def has_battery(power_supply: Path = POWER_SUPPLY) -> bool:
    if not power_supply.is_dir():
        return False
    return any(_read(p / "type").lower() == "battery" for p in power_supply.iterdir())


def is_integrated(dev: PciDevice, name: str, cpu_model: str) -> bool:
    lowered = name.lower()
    if dev.vendor_id in BMC_VENDORS:
        return True
    if dev.vendor_id == "8086":
        return not re.search(r"\barc\b|dg[12]|battlemage|alchemist", lowered)
    if dev.vendor_id == "1002":
        if any(re.search(h, lowered) for h in INTEGRATED_GPU_HINTS):
            return True
        vram = _read(Path("/sys/bus/pci/devices") / dev.address / "mem_info_vram_total")
        if vram.isdigit() and int(vram) < 2_500_000_000:
            return True
        return False
    return False  # NVIDIA and others are always add-in boards


def detect_gpus(cpu_model: str, override: str = "") -> list[GpuDevice]:
    if override:
        if override.strip().lower() in {"none", "no", "off"}:
            return []
        return [GpuDevice(override, "configured", True, "", match_gpu_profile(override))]
    gpus: list[GpuDevice] = []
    for dev in scan_pci():
        if not dev.is_display:
            continue
        name = dev.name
        discrete = not is_integrated(dev, name, cpu_model)
        gpus.append(GpuDevice(name, dev.vendor, discrete, dev.address, match_gpu_profile(name) if discrete else None))
    return gpus


def detect_hardware(cfg: PowerConfig) -> HardwareProfile:
    cpu_model = cfg.cpu_model.strip() or read_cpu_model()
    cpu_profile = match_cpu_profile(cpu_model)
    if cfg.cpu_model.strip():
        cpu_profile.source = f"{cpu_profile.source} (model override)"
    ram_bytes = int(cfg.ram_gb * 1024 ** 3) if cfg.ram_gb > 0 else psutil.virtual_memory().total
    ram_gb = ram_bytes / 1024 ** 3
    dimms = cfg.dimm_count if cfg.dimm_count > 0 else estimate_dimms(ram_gb)
    rapl_pkg, rapl_dram = find_rapl_domains()
    gpus = detect_gpus(cpu_model, cfg.gpu_model.strip())
    chassis = "board" if cpu_profile.board else detect_chassis()
    if chassis == "unknown" and has_battery():
        chassis = "laptop"
    return HardwareProfile(
        cpu_model=cpu_model,
        cpu_sockets=count_sockets(),
        cpu_cores=psutil.cpu_count(logical=False) or 1,
        cpu_threads=psutil.cpu_count(logical=True) or 1,
        cpu_profile=cpu_profile,
        ram_bytes=ram_bytes,
        dimm_count=dimms,
        gpus=gpus,
        storage=scan_storage_devices(),
        chassis=chassis,
        virtualization=detect_virtualization(),
        has_battery=has_battery(),
        rapl_domains=rapl_pkg,
        rapl_dram_domains=rapl_dram,
    )
