"""System Health Score: one 0–100 number with the reasons behind it.

Starts at 100 and subtracts capped penalties per area, so one bad disk cannot
hide everything else and a dozen minor issues cannot outweigh a critical one.
"""

from __future__ import annotations

from observatory.config import AlertConfig
from observatory.models import HealthScore, Snapshot


def _penalty(reasons: list[str], amount: float, reason: str) -> float:
    if amount > 0:
        reasons.append(f"-{amount:.0f} {reason}")
    return amount


def compute_health(snap: Snapshot, cfg: AlertConfig) -> HealthScore:
    reasons: list[str] = []
    total = 0.0

    cpu = snap.cpu.percent
    if cpu >= 90:
        total += _penalty(reasons, 15, f"CPU at {cpu:.0f}%")
    elif cpu >= 75:
        total += _penalty(reasons, 7, f"CPU at {cpu:.0f}%")
    if snap.cpu.iowait >= 20:
        total += _penalty(reasons, 5, f"I/O wait {snap.cpu.iowait:.0f}%")
    if snap.cpu.steal >= 10:
        total += _penalty(reasons, 5, f"CPU steal {snap.cpu.steal:.0f}% (noisy host)")

    load = snap.load.per_core1
    if load >= 2.0:
        total += _penalty(reasons, 10, f"load {load:.1f} per core")
    elif load >= 1.5:
        total += _penalty(reasons, 5, f"load {load:.1f} per core")

    mem = snap.memory.percent
    if mem >= 95:
        total += _penalty(reasons, 20, f"memory {mem:.0f}% used")
    elif mem >= 90:
        total += _penalty(reasons, 12, f"memory {mem:.0f}% used")
    elif mem >= 80:
        total += _penalty(reasons, 5, f"memory {mem:.0f}% used")

    if snap.swap.total and snap.swap.percent >= 50:
        total += _penalty(reasons, 5, f"swap {snap.swap.percent:.0f}% used")
    if snap.swap.sout_bps >= 1_000_000:
        total += _penalty(reasons, 5, "active swapping")

    disk_pen = 0.0
    for d in snap.disks:
        if d.percent >= 95:
            disk_pen += 15
            reasons.append(f"-15 {d.mountpoint} {d.percent:.0f}% full")
        elif d.percent >= 90:
            disk_pen += 8
            reasons.append(f"-8 {d.mountpoint} {d.percent:.0f}% full")
        elif d.percent >= 80:
            disk_pen += 3
            reasons.append(f"-3 {d.mountpoint} {d.percent:.0f}% full")
    total += min(disk_pen, 25)

    temp_pen = 0.0
    for r in snap.temps:
        if r.kind == "drive":
            warn, crit = cfg.drive_temp_warning_c, (r.critical or cfg.drive_temp_warning_c + 10)
        else:
            warn, crit = cfg.temp_warning_c, min(cfg.temp_critical_c, r.critical or cfg.temp_critical_c)
        if r.current >= crit:
            temp_pen += 20
            reasons.append(f"-20 {r.name} {r.current:.0f}°C (critical)")
        elif r.current >= warn:
            temp_pen += 8
            reasons.append(f"-8 {r.name} {r.current:.0f}°C")
    total += min(temp_pen, 30)

    unhealthy = [c for c in snap.containers if c.health == "unhealthy" or c.state == "restarting"]
    if unhealthy:
        amount = min(5 * len(unhealthy), 15)
        names = ", ".join(c.name for c in unhealthy[:3])
        total += _penalty(reasons, amount, f"container(s) unhealthy/restarting: {names}")

    crit_alerts = sum(1 for a in snap.alerts if a.severity == "critical")
    warn_alerts = sum(1 for a in snap.alerts if a.severity == "warning")
    if crit_alerts:
        total += _penalty(reasons, min(10 * crit_alerts, 30), f"{crit_alerts} critical alert(s)")
    if warn_alerts:
        total += _penalty(reasons, min(4 * warn_alerts, 16), f"{warn_alerts} warning alert(s)")

    score = int(round(min(max(100 - total, 0), 100)))
    if not reasons:
        reasons.append("All checks passing")
    return HealthScore(score=score, reasons=reasons)
