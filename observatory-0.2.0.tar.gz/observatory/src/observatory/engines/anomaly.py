"""Anomaly detection and alert lifecycle.

Detectors look at each new :class:`Snapshot` and report *findings*: conditions
that are true right now. The :class:`AlertManager` turns findings into alerts
with hysteresis (an alert resolves only after its finding has been absent for
several consecutive cycles), escalation, cool-down after resolution, and
persistence to the ``alerts`` and ``events`` tables.

Detectors
---------
CpuSpikeDetector       CPU far above its recent baseline or above an absolute ceiling, sustained
MemoryLeakDetector     process RSS / system memory rising monotonically over a window
DiskActivityDetector   device saturated (util %) or throughput far above its baseline
NetworkSpikeDetector   interface traffic far above its baseline, or link saturation
ThermalDetector        sensor above warning/critical, or a rapid temperature rise
"""

from __future__ import annotations

import logging
import time
from collections import deque
from dataclasses import dataclass

from observatory.config import AlertConfig
from observatory.engines.stats import mann_kendall, median, robust_z, theil_sen_slope
from observatory.models import Alert, ProcessInfo, Severity, Snapshot, TempReading
from observatory.storage.repository import Repository
from observatory.util.format import fmt_bytes, fmt_rate

log = logging.getLogger(__name__)

BASELINE_SECONDS = 30 * 60
SEVERITY_RANK = {"info": 0, "warning": 1, "critical": 2}


@dataclass(slots=True)
class Finding:
    kind: str
    subject: str
    severity: Severity
    message: str
    value: float | None = None

    @property
    def key(self) -> tuple[str, str]:
        return (self.kind, self.subject)


class TimeWindow:
    """A deque of (ts, value) trimmed to a maximum age, with optional thinning."""

    def __init__(self, max_age: float, min_spacing: float = 0.0) -> None:
        self.max_age = max_age
        self.min_spacing = min_spacing
        self.items: deque[tuple[float, float]] = deque()

    def add(self, ts: float, value: float) -> None:
        if self.items and self.min_spacing and ts - self.items[-1][0] < self.min_spacing:
            return
        self.items.append((ts, value))
        cutoff = ts - self.max_age
        while self.items and self.items[0][0] < cutoff:
            self.items.popleft()

    def values(self) -> list[float]:
        return [v for _, v in self.items]

    def span(self) -> float:
        return self.items[-1][0] - self.items[0][0] if len(self.items) > 1 else 0.0

    def value_at_or_before(self, ts: float) -> float | None:
        best = None
        for t, v in self.items:
            if t <= ts:
                best = v
            else:
                break
        return best

    def __len__(self) -> int:
        return len(self.items)


# ------------------------------------------------------------------ detectors
class CpuSpikeDetector:
    WARMUP = 20

    def __init__(self, cfg: AlertConfig) -> None:
        self.cfg = cfg
        self.history = TimeWindow(BASELINE_SECONDS)
        self.streak = 0

    def check(self, snap: Snapshot) -> list[Finding]:
        cpu = snap.cpu.percent
        baseline = self.history.values()
        is_spike = cpu >= self.cfg.cpu_spike_percent
        z = 0.0
        if len(baseline) >= self.WARMUP:
            center = median(baseline)
            z = robust_z(cpu, baseline, floor=2.0)
            if z >= self.cfg.cpu_spike_mad_k and cpu - center >= 25 and cpu >= 50:
                is_spike = True
        # Learn the baseline from non-spike samples only, so a long spike
        # does not become "normal" while it is still running.
        if not is_spike:
            self.history.add(snap.ts, cpu)
        self.streak = self.streak + 1 if is_spike else 0
        if self.streak < self.cfg.cpu_spike_samples:
            return []
        top = snap.top_process("cpu")
        culprit = f"; top process {top.name} (PID {top.pid}) at {top.cpu_percent:.0f}%" if top else ""
        baseline_text = f" (baseline {median(baseline):.0f}%)" if len(baseline) >= self.WARMUP else ""
        severity: Severity = "critical" if cpu >= 98 and self.streak >= self.cfg.cpu_spike_samples * 3 else "warning"
        return [Finding("cpu_spike", "cpu", severity,
                        f"CPU at {cpu:.0f}%{baseline_text} for {self.streak} samples{culprit}", cpu)]


class MemoryLeakDetector:
    TOP_N = 25
    MAX_POINTS = 60
    MIN_POINTS = 10
    TAU_THRESHOLD = 0.7

    def __init__(self, cfg: AlertConfig) -> None:
        self.cfg = cfg
        self.window_s = cfg.memory_leak_window_minutes * 60
        spacing = self.window_s / self.MAX_POINTS
        self._spacing = spacing
        self.procs: dict[tuple[int, float], TimeWindow] = {}
        self.names: dict[tuple[int, float], str] = {}
        self.system = TimeWindow(self.window_s, spacing)

    def _evaluate(self, window: TimeWindow, min_growth: float) -> tuple[bool, float, float]:
        """Return (leaking, growth_bytes_over_window, tau)."""
        if len(window) < self.MIN_POINTS or window.span() < 0.8 * self.window_s:
            return False, 0.0, 0.0
        xs = [t for t, _ in window.items]
        ys = [v for _, v in window.items]
        tau, z = mann_kendall(ys)
        slope = theil_sen_slope(xs, ys)
        growth = slope * window.span()
        first = ys[0] if ys[0] > 0 else 1.0
        leaking = (tau >= self.TAU_THRESHOLD and z > 2.58 and growth >= max(min_growth, 0.10 * first))
        return leaking, growth, tau

    def check(self, snap: Snapshot) -> list[Finding]:
        findings: list[Finding] = []
        top = sorted(snap.processes, key=lambda p: p.rss, reverse=True)[: self.TOP_N]
        live = set()
        for p in top:
            key = p.key
            live.add(key)
            window = self.procs.get(key)
            if window is None:
                window = self.procs[key] = TimeWindow(self.window_s, self._spacing)
            self.names[key] = p.name
            window.add(snap.ts, float(p.rss))
        # forget processes that exited or left the top list long ago
        for key in list(self.procs):
            if key not in live:
                window = self.procs[key]
                if not window.items or snap.ts - window.items[-1][0] > self.window_s:
                    del self.procs[key]
                    self.names.pop(key, None)
        min_growth = self.cfg.memory_leak_min_mb * 1024 * 1024
        for key, window in self.procs.items():
            if key not in live:
                continue
            leaking, growth, tau = self._evaluate(window, min_growth)
            if leaking:
                name = self.names.get(key, "?")
                minutes = window.span() / 60
                findings.append(Finding(
                    "memory_leak", f"{name} (PID {key[0]})", "warning",
                    f"{name} (PID {key[0]}) RSS grew {fmt_bytes(growth)} in {minutes:.0f} min "
                    f"(trend τ={tau:.2f}), now {fmt_bytes(window.items[-1][1])}", growth))
        # whole-system memory trend
        self.system.add(snap.ts, float(snap.memory.used))
        sys_min = max(min_growth, 0.05 * snap.memory.total)
        leaking, growth, tau = self._evaluate(self.system, sys_min)
        if leaking:
            findings.append(Finding(
                "memory_leak", "system memory", "warning",
                f"Used memory rose {fmt_bytes(growth)} in {self.system.span() / 60:.0f} min without "
                f"leveling off (τ={tau:.2f}); now {snap.memory.percent:.0f}% used", growth))
        return findings


class DiskActivityDetector:
    WARMUP = 20
    MIN_ANOMALOUS_BPS = 50 * 1000 * 1000

    def __init__(self, cfg: AlertConfig) -> None:
        self.cfg = cfg
        self.busy_streak: dict[str, int] = {}
        self.tp_streak: dict[str, int] = {}
        self.history: dict[str, TimeWindow] = {}

    def check(self, snap: Snapshot) -> list[Finding]:
        findings: list[Finding] = []
        for d in snap.disk_io:
            busy = d.util_percent >= self.cfg.disk_util_percent
            self.busy_streak[d.device] = self.busy_streak.get(d.device, 0) + 1 if busy else 0
            window = self.history.setdefault(d.device, TimeWindow(BASELINE_SECONDS))
            baseline = window.values()
            unusual = False
            if len(baseline) >= self.WARMUP and d.total_bps >= self.MIN_ANOMALOUS_BPS:
                floor = max(1_000_000.0, 0.05 * max(baseline))
                unusual = robust_z(d.total_bps, baseline, floor=floor) >= 6.0
            if not unusual:
                window.add(snap.ts, d.total_bps)
            self.tp_streak[d.device] = self.tp_streak.get(d.device, 0) + 1 if unusual else 0
            detail = (f"read {fmt_rate(d.read_bps)}, write {fmt_rate(d.write_bps)}, "
                      f"{d.read_iops + d.write_iops:.0f} IOPS")
            if self.busy_streak[d.device] >= self.cfg.disk_busy_samples:
                severity: Severity = "critical" if self.busy_streak[d.device] >= self.cfg.disk_busy_samples * 10 else "warning"
                findings.append(Finding("disk_activity", d.device, severity,
                                        f"{d.device} {d.util_percent:.0f}% busy for "
                                        f"{self.busy_streak[d.device]} samples ({detail})", d.util_percent))
            elif self.tp_streak[d.device] >= 3:
                findings.append(Finding("disk_activity", d.device, "warning",
                                        f"Unusual I/O on {d.device}: {fmt_rate(d.total_bps)} vs baseline "
                                        f"{fmt_rate(median(baseline))} ({detail})", d.total_bps))
        return findings


class NetworkSpikeDetector:
    WARMUP = 20

    def __init__(self, cfg: AlertConfig) -> None:
        self.cfg = cfg
        self.history: dict[str, TimeWindow] = {}
        self.spike_streak: dict[str, int] = {}
        self.sat_streak: dict[str, int] = {}

    def check(self, snap: Snapshot) -> list[Finding]:
        findings: list[Finding] = []
        min_bps = self.cfg.network_spike_mbps * 1_000_000 / 8
        for iface in snap.net:
            if iface.virtual or not iface.is_up:
                continue
            rate = iface.total_bps
            window = self.history.setdefault(iface.name, TimeWindow(BASELINE_SECONDS))
            baseline = window.values()
            spike = False
            if len(baseline) >= self.WARMUP and rate >= min_bps:
                floor = max(125_000.0, 0.05 * max(baseline))
                spike = robust_z(rate, baseline, floor=floor) >= self.cfg.network_spike_z
            if not spike:
                window.add(snap.ts, rate)
            self.spike_streak[iface.name] = self.spike_streak.get(iface.name, 0) + 1 if spike else 0
            saturated = False
            if iface.speed_mbps > 0:
                capacity = iface.speed_mbps * 1_000_000 / 8
                saturated = max(iface.rx_bps, iface.tx_bps) >= 0.9 * capacity
            self.sat_streak[iface.name] = self.sat_streak.get(iface.name, 0) + 1 if saturated else 0
            if self.sat_streak[iface.name] >= 5:
                findings.append(Finding("network_spike", iface.name, "warning",
                                        f"{iface.name} near link capacity ({iface.speed_mbps} Mbit/s): "
                                        f"rx {fmt_rate(iface.rx_bps)}, tx {fmt_rate(iface.tx_bps)}", rate))
            elif self.spike_streak[iface.name] >= 2:
                findings.append(Finding("network_spike", iface.name, "warning",
                                        f"Traffic spike on {iface.name}: {fmt_rate(rate)} vs baseline "
                                        f"{fmt_rate(median(baseline))} (rx {fmt_rate(iface.rx_bps)}, "
                                        f"tx {fmt_rate(iface.tx_bps)})", rate))
        return findings


class ThermalDetector:
    def __init__(self, cfg: AlertConfig) -> None:
        self.cfg = cfg
        self.history: dict[str, TimeWindow] = {}
        self.hot_streak: dict[str, int] = {}

    def thresholds(self, r: TempReading) -> tuple[float, float]:
        if r.kind == "drive":
            warn = self.cfg.drive_temp_warning_c
            crit = r.critical if r.critical else warn + 10
            if r.high:
                warn = min(warn, r.high)
            return warn, max(crit, warn + 1)
        warn = self.cfg.temp_warning_c
        crit = self.cfg.temp_critical_c
        if r.critical:
            crit = min(crit, r.critical)
        if r.high and r.high < crit:
            warn = min(warn, r.high)
        return warn, max(crit, warn + 1)

    def check(self, snap: Snapshot) -> list[Finding]:
        findings: list[Finding] = []
        for r in snap.temps:
            name = r.name
            warn, crit = self.thresholds(r)
            hot = r.current >= warn
            self.hot_streak[name] = self.hot_streak.get(name, 0) + 1 if hot else 0
            window = self.history.setdefault(name, TimeWindow(300))
            past = window.value_at_or_before(snap.ts - 60)
            window.add(snap.ts, r.current)
            if self.hot_streak[name] >= 2:
                severity: Severity = "critical" if r.current >= crit else "warning"
                limit = crit if severity == "critical" else warn
                findings.append(Finding("thermal", name, severity,
                                        f"{name} at {r.current:.0f}°C (limit {limit:.0f}°C)", r.current))
            elif past is not None and r.current - past >= self.cfg.temp_rise_c:
                findings.append(Finding("thermal", name, "warning",
                                        f"{name} rose {r.current - past:.0f}°C in about a minute "
                                        f"(now {r.current:.0f}°C)", r.current))
        return findings


# --------------------------------------------------------------- alert manager
class AlertManager:
    CLEAR_AFTER = 3  # consecutive cycles without the finding

    def __init__(self, cfg: AlertConfig, repo: Repository | None = None) -> None:
        self.cfg = cfg
        self.repo = repo
        self.active: dict[tuple[str, str], Alert] = {}
        self.absent: dict[tuple[str, str], int] = {}
        self.cooldown_until: dict[tuple[str, str], float] = {}

    def _persist(self, alert: Alert, new: bool) -> None:
        if self.repo is None:
            return
        try:
            if new:
                self.repo.insert_alert(alert)
                self.repo.insert_event("alert_fired", alert.message, alert.severity, alert.subject,
                                       details={"kind": alert.kind, "value": alert.value})
            else:
                self.repo.update_alert(alert)
        except Exception:  # storage problems must never break monitoring
            log.exception("failed to persist alert")

    def process(self, findings: list[Finding], now: float) -> tuple[list[Alert], list[Alert], list[Alert]]:
        """Apply this cycle's findings. Returns (active, newly_fired, resolved)."""
        fired: list[Alert] = []
        resolved: list[Alert] = []
        seen: set[tuple[str, str]] = set()
        for f in findings:
            key = f.key
            if key in seen:
                continue
            seen.add(key)
            self.absent[key] = 0
            alert = self.active.get(key)
            if alert is None:
                if now < self.cooldown_until.get(key, 0.0):
                    continue
                alert = Alert(kind=f.kind, severity=f.severity, subject=f.subject, message=f.message,
                              value=f.value, started_at=now)
                self.active[key] = alert
                self._persist(alert, new=True)
                fired.append(alert)
            else:
                escalated = SEVERITY_RANK[f.severity] > SEVERITY_RANK[alert.severity]
                alert.message = f.message
                alert.value = f.value
                if escalated:
                    alert.severity = f.severity
                    alert.acknowledged = False
                    fired.append(alert)
                    if self.repo is not None:
                        try:
                            self.repo.insert_event("alert_escalated", f.message, f.severity, f.subject,
                                                   details={"kind": f.kind})
                        except Exception:
                            log.exception("failed to log escalation")
                self._persist(alert, new=False)
        for key in list(self.active):
            if key in seen:
                continue
            self.absent[key] = self.absent.get(key, 0) + 1
            if self.absent[key] >= self.CLEAR_AFTER:
                alert = self.active.pop(key)
                alert.state = "resolved"
                alert.ended_at = now
                self._persist(alert, new=False)
                if self.repo is not None:
                    try:
                        self.repo.insert_event("alert_resolved", f"Resolved: {alert.message}", "info",
                                               alert.subject, details={"kind": alert.kind,
                                                                       "duration_s": now - alert.started_at})
                    except Exception:
                        log.exception("failed to log resolution")
                self.cooldown_until[key] = now + self.cfg.cooldown_minutes * 60
                self.absent.pop(key, None)
                resolved.append(alert)
        return list(self.active.values()), fired, resolved

    def acknowledge(self, alert_id: int) -> None:
        for alert in self.active.values():
            if alert.id == alert_id:
                alert.acknowledged = True
        if self.repo is not None:
            self.repo.acknowledge_alert(alert_id)


class AnomalyEngine:
    """Runs every detector each cycle and feeds the alert manager."""

    def __init__(self, cfg: AlertConfig, repo: Repository | None = None) -> None:
        self.cfg = cfg
        self.manager = AlertManager(cfg, repo)
        self._build()

    def _build(self) -> None:
        self.detectors = [
            CpuSpikeDetector(self.cfg),
            MemoryLeakDetector(self.cfg),
            DiskActivityDetector(self.cfg),
            NetworkSpikeDetector(self.cfg),
            ThermalDetector(self.cfg),
        ]

    def update_config(self, cfg: AlertConfig) -> None:
        self.cfg = cfg
        self.manager.cfg = cfg
        self._build()  # thresholds/windows may have changed; baselines re-learn

    def evaluate(self, snap: Snapshot) -> tuple[list[Alert], list[Alert], list[Alert]]:
        if not self.cfg.enabled:
            return self.manager.process([], snap.ts or time.time())
        findings: list[Finding] = []
        for detector in self.detectors:
            try:
                findings.extend(detector.check(snap))
            except Exception:
                log.exception("detector %s failed", type(detector).__name__)
        return self.manager.process(findings, snap.ts or time.time())


def top_by_rss(processes: list[ProcessInfo], n: int) -> list[ProcessInfo]:
    return sorted(processes, key=lambda p: p.rss, reverse=True)[:n]
