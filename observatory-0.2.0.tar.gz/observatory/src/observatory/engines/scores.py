"""Infrastructure scoring: five sub-scores, an overall health score and a risk score.

Health answers "how well is it running right now?"; risk answers "how likely
is trouble in the next few weeks?". Every point deducted carries a reason so
the dashboard can explain the number.

Status bands (health and sub-scores):
  ≥ 90 Excellent · ≥ 75 Healthy · ≥ 55 Warning · ≥ 35 Degraded · else Critical
Risk bands:
  < 15 Minimal · < 35 Low · < 60 Moderate · < 80 High · else Severe
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from observatory.config import AlertConfig

if TYPE_CHECKING:  # pragma: no cover
    from observatory.collectors.smart import SmartInfo
    from observatory.engines.intelligence import HistoricalContext
    from observatory.models import Snapshot
    from observatory.util.updates import UpdateStatus

STATUS_BANDS = ((90, "Excellent"), (75, "Healthy"), (55, "Warning"), (35, "Degraded"), (0, "Critical"))
RISK_BANDS = ((80, "Severe"), (60, "High"), (35, "Moderate"), (15, "Low"), (0, "Minimal"))
WEIGHTS = {"stability": 0.30, "thermal": 0.20, "storage": 0.25, "network": 0.10, "power": 0.15}


def status_for(score: float) -> str:
    for floor, name in STATUS_BANDS:
        if score >= floor:
            return name
    return "Critical"


def risk_label(score: float) -> str:
    for floor, name in RISK_BANDS:
        if score >= floor:
            return name
    return "Minimal"


@dataclass(slots=True)
class SubScore:
    name: str
    score: int = 100
    reasons: list[str] = field(default_factory=list)

    @property
    def status(self) -> str:
        return status_for(self.score)

    @property
    def summary(self) -> str:
        return self.reasons[0] if self.reasons else "nominal"


@dataclass(slots=True)
class Scores:
    overall: int = 100
    subs: dict[str, SubScore] = field(default_factory=dict)
    risk: int = 0
    risk_reasons: list[str] = field(default_factory=list)
    power_efficiency: int = 100

    @property
    def status(self) -> str:
        return status_for(self.overall)

    @property
    def risk_status(self) -> str:
        return risk_label(self.risk)


class _Acc:
    def __init__(self, name: str) -> None:
        self.sub = SubScore(name)
        self._penalty = 0.0

    def take(self, amount: float, reason: str, cap: float | None = None) -> None:
        if cap is not None:
            amount = min(amount, cap)
        if amount <= 0:
            return
        self._penalty += amount
        self.sub.reasons.append(reason)

    def done(self) -> SubScore:
        self.sub.score = int(round(min(max(100 - self._penalty, 0), 100)))
        return self.sub


def stability_score(snap: "Snapshot", ctx: "HistoricalContext | None") -> SubScore:
    acc = _Acc("stability")
    crit = sum(1 for a in snap.alerts if a.severity == "critical")
    warn = sum(1 for a in snap.alerts if a.severity == "warning")
    if crit:
        acc.take(15 * crit, f"{crit} critical alert(s) active", 45)
    if warn:
        acc.take(6 * warn, f"{warn} warning alert(s) active", 24)
    unhealthy = [c.name for c in snap.containers if c.health == "unhealthy" or c.state == "restarting"]
    if unhealthy:
        acc.take(8 * len(unhealthy), f"unhealthy: {', '.join(unhealthy[:3])}", 24)
    if ctx is not None and ctx.restarts_today:
        total = sum(ctx.restarts_today.values())
        worst = max(ctx.restarts_today, key=ctx.restarts_today.get)
        acc.take(3 * total, f"{total} container restart(s) today (most: {worst})", 20)
    load = snap.load.per_core1
    if load >= 2:
        acc.take(20, f"load {load:.1f} per core")
    elif load >= 1.5:
        acc.take(10, f"load {load:.1f} per core")
    if snap.memory.percent >= 95:
        acc.take(20, f"memory {snap.memory.percent:.0f}% used")
    elif snap.memory.percent >= 90:
        acc.take(12, f"memory {snap.memory.percent:.0f}% used")
    if snap.swap.sout_bps >= 1_000_000:
        acc.take(10, "actively swapping out")
    if 0 < snap.uptime_s < 3600:
        acc.take(5, f"rebooted {int(snap.uptime_s // 60)} min ago")
    return acc.done()


def thermal_score(snap: "Snapshot", cfg: AlertConfig, ctx: "HistoricalContext | None") -> SubScore:
    acc = _Acc("thermal")
    worst_headroom = None
    worst_name = ""
    for r in snap.temps:
        if r.kind == "drive":
            limit = r.critical or (cfg.drive_temp_warning_c + 10)
        else:
            limit = min(cfg.temp_critical_c, r.critical) if r.critical else cfg.temp_critical_c
        headroom = limit - r.current
        if worst_headroom is None or headroom < worst_headroom:
            worst_headroom, worst_name = headroom, r.name
        if r.kind == "drive" and r.current >= cfg.drive_temp_warning_c:
            acc.take(10, f"{r.name} at {r.current:.0f}°C (drive warning {cfg.drive_temp_warning_c:.0f}°C)", 20)
    if worst_headroom is not None:
        if worst_headroom <= 0:
            acc.take(90, f"{worst_name} at or above its critical limit")
        elif worst_headroom < 5:
            acc.take(65, f"{worst_name} within {worst_headroom:.0f}°C of its limit")
        elif worst_headroom < 10:
            acc.take(40, f"{worst_name} {worst_headroom:.0f}°C from its limit")
        elif worst_headroom < 20:
            acc.take(15, f"{worst_name} {worst_headroom:.0f}°C from its limit")
    if ctx is not None:
        temp_ctx = ctx.metric("temp")
        hottest = snap.hottest()
        if hottest and temp_ctx.avg_7d is not None and hottest.current - temp_ctx.avg_7d >= 8:
            acc.take(10, f"{hottest.current - temp_ctx.avg_7d:.0f}°C above its 7-day average")
    return acc.done()


def storage_score(snap: "Snapshot", ctx: "HistoricalContext | None",
                  smart: dict[str, "SmartInfo"] | None) -> SubScore:
    acc = _Acc("storage")
    # The fullest filesystem sets the main penalty; others add a little each.
    ranked = sorted(snap.disks, key=lambda d: -d.percent)
    for i, d in enumerate(ranked):
        if d.percent >= 95:
            base = 40
        elif d.percent >= 90:
            base = 25
        elif d.percent >= 80:
            base = 8
        else:
            continue
        acc.take(base if i == 0 else min(base, 5), f"{d.mountpoint} {d.percent:.0f}% full")
    if ctx is not None:
        fills = sorted((fc for fc in ctx.storage.values() if fc.days_to_full is not None),
                       key=lambda fc: fc.days_to_full)
        if fills:
            fc = fills[0]
            if fc.days_to_full < 7:
                acc.take(35, f"{fc.mountpoint} fills in {fc.days_to_full:.0f} days")
            elif fc.days_to_full < 30:
                acc.take(15, f"{fc.mountpoint} fills in {fc.days_to_full:.0f} days")
            elif fc.days_to_full < 90:
                acc.take(5, f"{fc.mountpoint} fills in {fc.days_to_full:.0f} days")
    scored = [(name, info) for name, info in (smart or {}).items() if not info.standby and info.risk != "unknown"]
    if scored:
        name, worst = min(scored, key=lambda kv: kv[1].health_score)
        if worst.health_score < 100:
            acc.take((100 - worst.health_score) * 0.6, f"{name} drive health {worst.health_score}/100", 50)
    for io in snap.disk_io:
        if io.util_percent >= 90:
            acc.take(10, f"{io.device} saturated ({io.util_percent:.0f}% busy)", 20)
    return acc.done()


def network_score(snap: "Snapshot", error_rate: float = 0.0) -> SubScore:
    acc = _Acc("network")
    physical = [n for n in snap.net if not n.virtual and n.name != "lo"]
    if physical and not any(n.is_up for n in physical):
        acc.take(80, "no physical interface is up")
    for n in physical:
        if n.speed_mbps > 0 and n.is_up:
            utilisation = max(n.rx_bps, n.tx_bps) * 8 / (n.speed_mbps * 1_000_000)
            if utilisation >= 0.9:
                acc.take(25, f"{n.name} at {utilisation:.0%} of link speed", 40)
            elif utilisation >= 0.7:
                acc.take(10, f"{n.name} at {utilisation:.0%} of link speed", 40)
    if error_rate > 10:
        acc.take(20, f"{error_rate:.0f} interface errors/drops per second")
    elif error_rate > 0.5:
        acc.take(8, f"{error_rate:.1f} interface errors/drops per second")
    spikes = [a for a in snap.alerts if a.kind == "network_spike"]
    if spikes:
        acc.take(10 * len(spikes), "unusual traffic detected", 30)
    return acc.done()


def power_score(snap: "Snapshot", ctx: "HistoricalContext | None", idle_floor_watts: float,
                idle_spinning_hdds: int) -> tuple[SubScore, int]:
    """Returns (power sub-score, power efficiency score 0-100).

    Efficiency compares the draw you pay for with the floor this hardware
    needs when idle, adjusted for how busy the machine actually is.
    """
    acc = _Acc("power")
    watts = snap.power.wall_watts
    if ctx is not None:
        change = ctx.energy.week_change
        if change is not None and change > 0.10:
            acc.take(min(change * 100, 30), f"draw up {change:.0%} week over week")
        base = ctx.metric("power").baseline
        if base is not None and base.median > 0 and watts > base.median * 1.3 and watts - base.median > 10:
            acc.take(10, f"{watts - base.median:.0f} W above normal for {base.description}")
    if idle_spinning_hdds:
        acc.take(3 * idle_spinning_hdds, f"{idle_spinning_hdds} idle HDD(s) spinning 24/7", 15)
    # efficiency: expected draw at this utilisation vs actual
    util = max(snap.cpu.percent, max((g.util_percent or 0) for g in snap.gpus) if snap.gpus else 0) / 100
    efficiency = 100
    if watts > 0 and idle_floor_watts > 0:
        expected = idle_floor_watts * (1 + 1.5 * util)
        ratio = expected / watts
        efficiency = int(round(min(max(ratio, 0), 1) * 100))
        if efficiency < 60:
            acc.take(15, f"drawing {watts:.0f} W for {util:.0%} utilisation")
    sub = acc.done()
    return sub, efficiency


def risk_score(snap: "Snapshot", ctx: "HistoricalContext | None", smart: dict[str, "SmartInfo"] | None,
               thermal: SubScore, updates: "UpdateStatus | None") -> tuple[int, list[str]]:
    # Each factor is treated as an independent chance of trouble; they combine
    # like probabilities (1 − Π(1 − p)) so many small issues raise risk without
    # saturating it, and one severe issue alone can still make it high.
    survival = 1.0
    reasons: list[tuple[float, str]] = []

    def add(points: float, reason: str) -> None:
        nonlocal survival
        if points > 0:
            survival *= 1 - min(points, 100) / 100
            reasons.append((points, reason))

    if ctx is not None:
        soonest = min((fc for fc in ctx.storage.values() if fc.days_to_full is not None),
                      key=lambda fc: fc.days_to_full, default=None)
        if soonest is not None:
            days = soonest.days_to_full
            if days < 7:
                add(40, f"{soonest.mountpoint} full within a week")
            elif days < 30:
                add(25, f"{soonest.mountpoint} full within a month")
            elif days < 90:
                add(10, f"{soonest.mountpoint} full within 3 months")
        loops = [name for name, n in ctx.restarts_today.items() if n >= 3]
        if loops:
            add(min(10 * len(loops), 20), f"restart loops: {', '.join(loops[:3])}")
    for name, info in (smart or {}).items():
        points = {"critical": 50, "high": 35, "elevated": 15}.get(info.risk, 0)
        add(points, f"drive {name} failure risk {info.risk}")
    crit = sum(1 for a in snap.alerts if a.severity == "critical")
    warn = sum(1 for a in snap.alerts if a.severity == "warning")
    add(min(20 * crit, 40), f"{crit} critical alert(s)")
    add(min(5 * warn, 20), f"{warn} warning alert(s)")
    if thermal.score < 40:
        add(25, "thermal headroom nearly exhausted")
    elif thermal.score < 65:
        add(15, "low thermal headroom")
    if any(a.kind == "memory_leak" for a in snap.alerts):
        add(15, "memory leak suspected")
    if snap.memory.percent >= 90:
        add(10, "memory pressure")
    if snap.swap.sout_bps >= 1_000_000:
        add(5, "swapping")
    if updates is not None and updates.security:
        add(10, f"{updates.security} security update(s) pending")
    reasons.sort(key=lambda pr: -pr[0])
    return int(round((1 - survival) * 100)), [r for _p, r in reasons]


def compute_scores(snap: "Snapshot", cfg: AlertConfig, ctx: "HistoricalContext | None" = None,
                   smart: dict[str, "SmartInfo"] | None = None, updates: "UpdateStatus | None" = None,
                   legacy_health: int | None = None, idle_floor_watts: float = 0.0,
                   idle_spinning_hdds: int = 0, net_error_rate: float = 0.0) -> Scores:
    subs = {
        "stability": stability_score(snap, ctx),
        "thermal": thermal_score(snap, cfg, ctx),
        "storage": storage_score(snap, ctx, smart),
        "network": network_score(snap, net_error_rate),
    }
    power_sub, efficiency = power_score(snap, ctx, idle_floor_watts, idle_spinning_hdds)
    subs["power"] = power_sub
    weighted = sum(subs[k].score * w for k, w in WEIGHTS.items())
    # The weakest area always pulls the overall score down: a perfect average
    # must not hide one failing subsystem.
    weakest = min(s.score for s in subs.values())
    overall = 0.7 * weighted + 0.3 * weakest
    if legacy_health is not None:
        overall = 0.5 * overall + 0.5 * legacy_health
    risk, risk_reasons = risk_score(snap, ctx, smart, subs["thermal"], updates)
    return Scores(overall=int(round(overall)), subs=subs, risk=risk, risk_reasons=risk_reasons,
                  power_efficiency=efficiency)
