"""Robust statistics used by anomaly detection and forecasting.

Pure Python, no numpy: windows are small (≤ a few hundred points) and the
agent must stay light.
"""

from __future__ import annotations

import math
from collections.abc import Sequence

MAD_SCALE = 1.4826  # makes MAD comparable to a standard deviation for normal data


def median(values: Sequence[float]) -> float:
    if not values:
        raise ValueError("median of empty sequence")
    ordered = sorted(values)
    n = len(ordered)
    mid = n // 2
    if n % 2:
        return float(ordered[mid])
    return (ordered[mid - 1] + ordered[mid]) / 2.0


def mad(values: Sequence[float], center: float | None = None) -> float:
    """Median absolute deviation."""
    if not values:
        raise ValueError("mad of empty sequence")
    c = median(values) if center is None else center
    return median([abs(v - c) for v in values])


def robust_z(value: float, values: Sequence[float], floor: float = 1e-9) -> float:
    """How many robust standard deviations ``value`` lies above the median.

    ``floor`` stops near-constant baselines (MAD≈0) from turning tiny changes
    into enormous scores.
    """
    if not values:
        return 0.0
    c = median(values)
    spread = max(MAD_SCALE * mad(values, c), floor)
    return (value - c) / spread


def theil_sen_slope(xs: Sequence[float], ys: Sequence[float]) -> float:
    """Median of pairwise slopes; robust to outliers (up to ~29 % breakdown)."""
    if len(xs) != len(ys):
        raise ValueError("xs and ys must be the same length")
    slopes = []
    n = len(xs)
    for i in range(n):
        for j in range(i + 1, n):
            dx = xs[j] - xs[i]
            if dx != 0:
                slopes.append((ys[j] - ys[i]) / dx)
    if not slopes:
        return 0.0
    return median(slopes)


def theil_sen(xs: Sequence[float], ys: Sequence[float]) -> tuple[float, float]:
    """Return (slope, intercept) of the Theil–Sen line."""
    slope = theil_sen_slope(xs, ys)
    intercept = median([y - slope * x for x, y in zip(xs, ys)])
    return slope, intercept


def mann_kendall(ys: Sequence[float]) -> tuple[float, float]:
    """Mann–Kendall trend test.

    Returns (tau, z): tau in [-1, 1] is Kendall's rank correlation with time,
    z is the normal-approximation test statistic (|z| > 2.58 ≈ p < 0.01).
    """
    n = len(ys)
    if n < 3:
        return 0.0, 0.0
    s = 0
    for i in range(n - 1):
        for j in range(i + 1, n):
            diff = ys[j] - ys[i]
            if diff > 0:
                s += 1
            elif diff < 0:
                s -= 1
    pairs = n * (n - 1) / 2
    tau = s / pairs
    # variance without tie correction is adequate for continuous metrics
    var_s = n * (n - 1) * (2 * n + 5) / 18.0
    if s > 0:
        z = (s - 1) / math.sqrt(var_s)
    elif s < 0:
        z = (s + 1) / math.sqrt(var_s)
    else:
        z = 0.0
    return tau, z


def linear_regression(xs: Sequence[float], ys: Sequence[float]) -> tuple[float, float, float]:
    """Ordinary least squares. Returns (slope, intercept, r_squared)."""
    n = len(xs)
    if n < 2:
        return 0.0, (ys[0] if ys else 0.0), 0.0
    mean_x = sum(xs) / n
    mean_y = sum(ys) / n
    sxx = sum((x - mean_x) ** 2 for x in xs)
    sxy = sum((x - mean_x) * (y - mean_y) for x, y in zip(xs, ys))
    if sxx == 0:
        return 0.0, mean_y, 0.0
    slope = sxy / sxx
    intercept = mean_y - slope * mean_x
    ss_tot = sum((y - mean_y) ** 2 for y in ys)
    ss_res = sum((y - (slope * x + intercept)) ** 2 for x, y in zip(xs, ys))
    r2 = 1 - ss_res / ss_tot if ss_tot > 0 else 1.0
    return slope, intercept, r2


def downsample(points: Sequence[tuple[float, float]], max_points: int) -> list[tuple[float, float]]:
    """Evenly thin a series to at most ``max_points`` (keeps first and last)."""
    n = len(points)
    if n <= max_points or max_points < 2:
        return list(points)
    step = (n - 1) / (max_points - 1)
    return [points[round(i * step)] for i in range(max_points)]
