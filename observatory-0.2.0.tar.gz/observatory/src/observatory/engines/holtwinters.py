"""Additive Holt-Winters (triple exponential smoothing) for seasonal series.

Used to forecast hourly power draw with a daily (24-step) season. Parameters
are chosen by a small grid search minimising one-step-ahead squared error, so
no external optimiser is needed.
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from itertools import product

GRID = (0.1, 0.3, 0.5, 0.8)
TREND_GRID = (0.0, 0.05, 0.2)


@dataclass(slots=True)
class HoltWintersModel:
    alpha: float
    beta: float
    gamma: float
    level: float
    trend: float
    season: list[float]
    sse: float
    period: int

    def forecast(self, steps: int) -> list[float]:
        out = []
        n = len(self.season)
        for h in range(1, steps + 1):
            out.append(self.level + h * self.trend + self.season[(h - 1) % n])
        return out


def _fit(values: Sequence[float], period: int, alpha: float, beta: float, gamma: float) -> HoltWintersModel:
    first = values[:period]
    second = values[period:2 * period]
    level = sum(first) / period
    trend = (sum(second) / period - level) / period if len(second) == period else 0.0
    season = [v - level for v in first]
    sse = 0.0
    for i in range(period, len(values)):
        s_idx = i % period
        predicted = level + trend + season[s_idx]
        error = values[i] - predicted
        sse += error * error
        last_level = level
        level = alpha * (values[i] - season[s_idx]) + (1 - alpha) * (level + trend)
        trend = beta * (level - last_level) + (1 - beta) * trend
        season[s_idx] = gamma * (values[i] - level) + (1 - gamma) * season[s_idx]
    # rotate so season[0] corresponds to the step after the last observation
    start = len(values) % period
    season = season[start:] + season[:start]
    return HoltWintersModel(alpha, beta, gamma, level, trend, season, sse, period)


def fit_holt_winters(values: Sequence[float], period: int = 24) -> HoltWintersModel | None:
    """Fit on at least two full seasons; returns None when there is too little data."""
    if len(values) < 2 * period:
        return None
    best: HoltWintersModel | None = None
    for alpha, beta, gamma in product(GRID, TREND_GRID, GRID):
        model = _fit(values, period, alpha, beta, gamma)
        if best is None or model.sse < best.sse:
            best = model
    return best


def daily_totals(hourly: Sequence[float]) -> list[float]:
    """Sum consecutive blocks of 24 hourly values."""
    return [sum(hourly[i:i + 24]) for i in range(0, len(hourly) - len(hourly) % 24, 24)]
