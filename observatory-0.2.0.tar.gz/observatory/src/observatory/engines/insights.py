"""Observatory Insights: turns metrics, history and forecasts into plain-language
explanations and recommendations.

Each generator looks at one aspect and may emit Insights. An insight states
what is happening, why (when Observatory can tell), and — when there is an
action — what to do, with the expected benefit. The list is ranked by
severity and priority; the dashboard shows the top of it.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from observatory.util.format import fmt_bytes, fmt_money, fmt_rate

if TYPE_CHECKING:  # pragma: no cover
    from observatory.collectors.media import MediaApp
    from observatory.collectors.smart import SmartInfo
    from observatory.config import Config
    from observatory.engines.intelligence import HistoricalContext
    from observatory.engines.scores import Scores
    from observatory.models import Snapshot, StorageDevice
    from observatory.util.updates import UpdateStatus

SEVERITY_ORDER = {"critical": 0, "warning": 1, "notice": 2, "info": 3, "good": 4}
ICONS = {"cpu": "◆", "memory": "◇", "power": "ϟ", "cost": "$", "storage": "▤", "network": "⇅",
         "docker": "▣", "thermal": "♨", "media": "▶", "system": "◎", "security": "⛨"}


@dataclass(slots=True)
class Insight:
    key: str
    severity: str           # critical | warning | notice | info | good
    category: str
    text: str
    recommendation: str = ""
    priority: int = 50      # lower = more important within a severity
    impact: str = ""        # what acting on the recommendation is worth, e.g. "saves $2.17/mo"
    created: float = field(default_factory=time.time)

    @property
    def icon(self) -> str:
        return ICONS.get(self.category, "•")


@dataclass(slots=True)
class InsightInputs:
    snap: "Snapshot"
    cfg: "Config"
    ctx: "HistoricalContext | None" = None
    scores: "Scores | None" = None
    smart: dict[str, "SmartInfo"] = field(default_factory=dict)
    media: dict[str, "MediaApp"] = field(default_factory=dict)
    updates: "UpdateStatus | None" = None
    storage_devices: list["StorageDevice"] = field(default_factory=list)
    recent_cpu: float | None = None     # ~5-minute average
    recent_net_bps: float | None = None
    recent_power: float | None = None
    has_gpu_encoder: bool = False


def _pct(fraction: float) -> str:
    return f"{abs(fraction) * 100:.0f}%"


def _date_in(days: float) -> str:
    return time.strftime("%b %d", time.localtime(time.time() + days * 86400))


# ------------------------------------------------------------------ generators
def cpu_insights(i: InsightInputs) -> list[Insight]:
    out = []
    snap = i.snap
    current = i.recent_cpu if i.recent_cpu is not None else snap.cpu.percent
    top = snap.top_process("cpu")
    container = snap.top_container()
    why = ""
    if container and container.cpu_percent >= 10:
        why = f" Most of it comes from container {container.name} ({container.cpu_percent:.0f}%)."
    elif top and top.cpu_percent >= 10:
        why = f" Top consumer: {top.name} ({top.cpu_percent:.0f}% of a core)."
    base = i.ctx.metric("cpu").baseline if i.ctx else None
    if base is not None and base.median >= 1:
        diff = current - base.median
        rel = diff / base.median
        if diff >= 15 and rel >= 0.3:
            out.append(Insight("cpu-above-pattern", "notice" if diff < 40 else "warning", "cpu",
                               f"CPU utilization is {_pct(rel)} higher than your normal {base.description} "
                               f"pattern ({current:.0f}% vs {base.median:.0f}%).{why}", priority=20))
        elif diff <= -15 and rel <= -0.5:
            out.append(Insight("cpu-below-pattern", "info", "cpu",
                               f"CPU is unusually quiet for {base.description} ({current:.0f}% vs a normal "
                               f"{base.median:.0f}%). A scheduled job may not have run.", priority=60))
    elif current >= 85:
        out.append(Insight("cpu-high", "warning", "cpu", f"CPU has averaged {current:.0f}% recently.{why}",
                           priority=20))
    return out


def memory_insights(i: InsightInputs) -> list[Insight]:
    out = []
    snap = i.snap
    trend = i.ctx.trends.get("mem") if i.ctx else None
    if trend is not None and trend.slope_per_day > 1.0 and snap.memory.percent < 95:
        days = (90 - snap.memory.percent) / trend.slope_per_day if snap.memory.percent < 90 else 0
        tail = f"; at this rate it reaches 90% in about {days:.0f} days" if 0 < days < 120 else ""
        out.append(Insight("mem-trend", "notice", "memory",
                           f"Memory use is climbing {trend.slope_per_day:.1f} points per day{tail}.",
                           "Check the Processes screen sorted by memory (key r) for a growing process.",
                           priority=35, impact=f"90% in ~{days:.0f} d" if 0 < days < 120 else "trend"))
    if snap.swap.sout_bps > 500_000 and snap.memory.percent < 70:
        out.append(Insight("swap-with-free-ram", "notice", "memory",
                           f"The system is swapping ({fmt_rate(snap.swap.sout_bps)} out) while "
                           f"{100 - snap.memory.percent:.0f}% of RAM is free.",
                           "Lower vm.swappiness (e.g. sysctl vm.swappiness=10).", priority=40,
                           impact="less disk I/O"))
    for alert in snap.alerts:
        if alert.kind == "memory_leak":
            out.append(Insight(f"leak-{alert.subject}", "warning", "memory", alert.message,
                               "Restart the service to reclaim memory and report the leak upstream.",
                               priority=15, impact="avoid OOM kill"))
    return out


def power_insights(i: InsightInputs) -> list[Insight]:
    out = []
    if i.ctx is None:
        return out
    e = i.ctx.energy
    sym = i.cfg.cost.currency_symbol
    change = e.week_change
    if change is not None and abs(change) >= 0.10:
        more = change > 0
        out.append(Insight("power-week", "notice" if more else "good", "power",
                           f"Power consumption has {'increased' if more else 'decreased'} {_pct(change)} this week "
                           f"({e.week_kwh:.1f} kWh vs {e.prev_week_kwh:.1f} kWh).", priority=30))
    mchange = e.month_change
    if mchange is not None and abs(mchange) >= 0.10:
        out.append(Insight("power-month", "notice" if mchange > 0 else "good", "power",
                           f"This server is drawing {_pct(mchange)} {'more' if mchange > 0 else 'less'} power than "
                           f"last month on average.", priority=32))
    base = i.ctx.metric("power").baseline
    watts = i.recent_power if i.recent_power is not None else i.snap.power.wall_watts
    if base is not None and base.median > 0 and watts - base.median > max(10, 0.25 * base.median):
        container = i.snap.top_container()
        why = f" Likely driver: {container.name} at {container.cpu_percent:.0f}% CPU." if container and \
            container.cpu_percent >= 15 else ""
        out.append(Insight("power-above-normal", "notice", "power",
                           f"Drawing {watts:.0f} W, {watts - base.median:.0f} W more than normal for "
                           f"{base.description}.{why}", priority=33))
    if e.forecast_30d_cost is not None:
        out.append(Insight("cost-forecast", "info", "cost",
                           f"Next 30 days: about {e.forecast_30d_kwh:.0f} kWh, {fmt_money(e.forecast_30d_cost, sym)} "
                           f"({e.forecast_method}).", priority=80))
    return out


def spindown_recommendation(i: InsightInputs) -> list[Insight]:
    if i.ctx is None:
        return []
    from observatory.engines.hardware import load_profile_db

    spec = load_profile_db()["storage"]["hdd"]
    idle_drives = [d.name for d in i.storage_devices
                   if d.kind == "hdd" and d.name not in i.cfg.power.spun_down_drives
                   and i.ctx.disk_idle_24h.get(d.name, 100.0) < 0.5]
    if not idle_drives or i.ctx.history_days < 1:
        return []
    saving_w = len(idle_drives) * (spec["idle_w"] - spec["standby_w"]) / i.cfg.power.psu_efficiency
    monthly = saving_w * 730 / 1000 * i.cfg.cost.rate_per_kwh
    sym = i.cfg.cost.currency_symbol
    names = ", ".join(idle_drives[:4])
    return [Insight("spindown", "notice", "power",
                    f"{len(idle_drives)} hard drive(s) ({names}) were idle all day but kept spinning.",
                    f"Enable spin-down on {names} (hdparm -S 241) to save ~{saving_w:.0f} W.",
                    priority=45, impact=f"saves {fmt_money(monthly, sym)}/mo")]


def storage_insights(i: InsightInputs) -> list[Insight]:
    out = []
    alerted = {a.subject.split(":")[-1] for a in i.snap.alerts if a.kind == "thermal"}
    if i.ctx is not None:
        for mount, fc in sorted(i.ctx.storage.items(), key=lambda kv: kv[1].days_to_full or 1e9):
            if fc.days_to_full is None or fc.days_to_full > 180:
                continue
            severity = "critical" if fc.days_to_full < 7 else "warning" if fc.days_to_full < 30 else "notice"
            out.append(Insight(f"fill-{mount}", severity, "storage",
                               f"Storage growth suggests {mount} will fill in {fc.days_to_full:.0f} days "
                               f"(≈ {_date_in(fc.days_to_full)}, +{fmt_bytes(fc.growth_bytes_per_day)}/day).",
                               f"Free space or expand {mount} before {_date_in(fc.days_to_full)}."
                               if fc.days_to_full < 60 else "",
                               priority=10 if severity == "critical" else 25,
                               impact=f"full in {fc.days_to_full:.0f} d"))
    for d in i.snap.disks:
        if d.percent >= 90 and not any(x.key == f"fill-{d.mountpoint}" for x in out):
            out.append(Insight(f"full-{d.mountpoint}", "warning" if d.percent < 97 else "critical", "storage",
                               f"{d.mountpoint} is {d.percent:.0f}% full ({fmt_bytes(d.free)} left).",
                               f"Free space on {d.mountpoint}.", priority=12, impact=f"{fmt_bytes(d.free)} left"))
    for name, info in i.smart.items():
        if info.risk in ("high", "critical"):
            out.append(Insight(f"smart-{name}", "critical" if info.risk == "critical" else "warning", "storage",
                               f"Drive {name} ({info.model}) shows failure risk: "
                               f"{'; '.join(info.reasons[:2]) or info.status}.",
                               f"Back up {name} and plan a replacement.", priority=5, impact="data at risk"))
        elif (info.temperature_c is not None and info.temperature_c >= i.cfg.alerts.drive_temp_warning_c
              and name not in alerted):
            out.append(Insight(f"drivetemp-{name}", "warning", "thermal",
                               f"Storage temperature is above its normal operating range: {name} at "
                               f"{info.temperature_c:.0f}°C.", f"Improve airflow over {name}.", priority=22,
                               impact="drive lifespan"))
    drive_temps = [t for t in i.snap.temps if t.kind == "drive" and t.current >= i.cfg.alerts.drive_temp_warning_c]
    for t in drive_temps:
        drive = t.label if t.chip.startswith("drivetemp") and t.label else t.name
        if drive in alerted or t.name in alerted or any(x.key == f"drivetemp-{drive}" for x in out):
            continue
        out.append(Insight(f"drivetemp-{drive}", "warning", "thermal",
                           f"Storage temperature is above its normal operating range: {t.name} at "
                           f"{t.current:.0f}°C.", f"Improve airflow over {drive}.", priority=22,
                           impact="drive lifespan"))
    return out


def docker_insights(i: InsightInputs) -> list[Insight]:
    out = []
    if i.ctx is not None:
        for name, count in i.ctx.restarts_today.items():
            if count >= 2:
                out.append(Insight(f"restarts-{name}", "warning" if count >= 3 else "notice", "docker",
                                   f"Container {name} restarted {count} times today.",
                                   f"Check why {name} keeps restarting: docker logs --tail 100 {name}",
                                   priority=18, impact=f"{count} restarts today"))
    for c in i.snap.containers:
        if c.health == "unhealthy":
            out.append(Insight(f"unhealthy-{c.name}", "warning", "docker",
                               f"Container {c.name} is failing its health check ({c.status}).",
                               f"Inspect {c.name}'s health check: docker inspect --format "
                               f"'{{{{json .State.Health}}}}' {c.name}", priority=16, impact="service degraded"))
        if c.mem_limit and c.mem_percent >= 90 and c.state == "running":
            out.append(Insight(f"memlimit-{c.name}", "notice", "docker",
                               f"Container {c.name} is using {c.mem_percent:.0f}% of its memory limit.",
                               f"Raise {c.name}'s memory limit or check it for a leak.", priority=30,
                               impact="avoid OOM kill"))
    return out


def thermal_insights(i: InsightInputs) -> list[Insight]:
    out = []
    hottest = i.snap.hottest()
    ctx_temp = i.ctx.metric("temp") if i.ctx else None
    if hottest and ctx_temp and ctx_temp.avg_7d is not None and hottest.current - ctx_temp.avg_7d >= 8:
        out.append(Insight("temp-above-normal", "notice", "thermal",
                           f"{hottest.name} is {hottest.current - ctx_temp.avg_7d:.0f}°C above its 7-day average "
                           f"({hottest.current:.0f}°C).", priority=28))
    for alert in i.snap.alerts:
        if alert.kind == "thermal":
            out.append(Insight(f"thermal-{alert.subject}", alert.severity, "thermal", alert.message,
                               "Check fans, dust filters and room temperature.", priority=8,
                               impact="throttling risk"))
    return out


def network_insights(i: InsightInputs) -> list[Insight]:
    out = []
    if i.ctx is None:
        return out
    rx_base = i.ctx.metric("rx").baseline
    tx_base = i.ctx.metric("tx").baseline
    current = i.recent_net_bps if i.recent_net_bps is not None else sum(i.snap.net_totals())
    if rx_base and tx_base:
        normal = rx_base.median + tx_base.median
        if current > max(3 * normal, 1_000_000):
            out.append(Insight("net-unusual", "notice", "network",
                               f"Network traffic is unusually high for this time of day "
                               f"({fmt_rate(current)} vs a normal {fmt_rate(normal)}).", priority=26))
    if i.ctx.new_devices_24h:
        devices = i.ctx.new_devices_24h
        sample = ", ".join(f"{d['ip']}" for d in devices[:3])
        out.append(Insight("new-devices", "notice", "network",
                           f"{len(devices)} new device(s) appeared on the network in the last 24 h ({sample}).",
                           "Confirm you recognise the new device(s) on your network.", priority=27,
                           impact="security"))
    for alert in i.snap.alerts:
        if alert.kind == "network_spike":
            out.append(Insight(f"netspike-{alert.subject}", "warning", "network", alert.message, priority=24))
    return out


def media_insights(i: InsightInputs) -> list[Insight]:
    out = []
    streams = [(app, s) for app in i.media.values() for s in app.streams]
    software = [(app, s) for app, s in streams if s.transcode and s.hardware is False]
    if software and i.has_gpu_encoder:
        out.append(Insight("sw-transcode", "notice", "media",
                           f"{len(software)} stream(s) are transcoding in software while a GPU is available.",
                           "Enable hardware transcoding in your media server.", priority=34,
                           impact="less CPU & power"))
    for app in i.media.values():
        if app.service_health in ("down", "unhealthy"):
            detail = app.error or app.container_state or app.container_health
            out.append(Insight(f"media-{app.key}", "warning", "media", f"{app.name} is {app.service_health} ({detail}).",
                               priority=19))
        for issue in app.health_issues[:1]:
            out.append(Insight(f"media-issue-{app.key}", "notice", "media", f"{app.name}: {issue}", priority=42))
    growth = i.ctx.media_library_growth if i.ctx else {}
    for key, per_day in growth.items():
        if per_day > 1e9:
            out.append(Insight(f"library-{key}", "info", "media",
                               f"The {key} library is growing about {fmt_bytes(per_day)} per day.", priority=70))
    return out


def system_insights(i: InsightInputs) -> list[Insight]:
    out = []
    if 0 < i.snap.uptime_s < 3600:
        out.append(Insight("rebooted", "info", "system",
                           f"System rebooted {int(i.snap.uptime_s // 60)} minutes ago.", priority=55))
    if i.updates is not None and i.updates.available:
        sev = "warning" if i.updates.security else "info"
        out.append(Insight("updates", sev, "security",
                           f"{i.updates.label.capitalize()} available via {i.updates.manager}.",
                           "Apply pending updates in a maintenance window.",
                           priority=40 if i.updates.security else 75,
                           impact=f"{i.updates.security} security" if i.updates.security else "keep current"))
    services = i.snap.services
    if services is not None:
        for unit in services.failed[:3]:
            out.append(Insight(f"unit-failed-{unit.name}", "warning", "system",
                               f"systemd service {unit.name} has failed"
                               + (f" ({unit.description})." if unit.description else "."),
                               f"Check it: systemctl status {unit.name}", priority=17, impact="service down"))
        if services.reboot_required:
            pkgs = ", ".join(services.reboot_packages[:3])
            out.append(Insight("reboot-required", "notice", "security",
                               "A reboot is required to finish installing updates" + (f" ({pkgs})." if pkgs else "."),
                               "Reboot in a maintenance window.", priority=38, impact="apply fixes"))
    # Upgrades are a common root cause: tie recent ones to current trouble.
    recent = [g for g in i.snap.package_changes if i.snap.ts - g.ts < 86400]
    if recent:
        latest = recent[-1]
        hours = (i.snap.ts - latest.ts) / 3600
        trouble = [a for a in i.snap.alerts] or [x for x in recent if x.notable]
        if i.snap.alerts and hours < 12:
            out.append(Insight("upgrade-correlation", "notice", "system",
                               f"{latest.message} {hours:.0f} h ago, shortly before the current "
                               f"{i.snap.alerts[0].kind.replace('_', ' ')} alert. The upgrade is a likely cause.",
                               priority=21))
        elif trouble:
            out.append(Insight("recent-upgrade", "info", "system",
                               f"{latest.message} {hours:.0f} h ago.", priority=65))
    if i.ctx is not None and 0 < i.ctx.history_days < 1:
        out.append(Insight("learning", "info", "system",
                           "Observatory is still learning this system's normal patterns; comparisons sharpen "
                           "after the first day and baselines after the first week.", priority=90))
    return out


GENERATORS = (cpu_insights, memory_insights, power_insights, spindown_recommendation, storage_insights,
              docker_insights, thermal_insights, network_insights, media_insights, system_insights)


def generate_insights(i: InsightInputs, limit: int = 30) -> list[Insight]:
    insights: list[Insight] = []
    for generator in GENERATORS:
        try:
            insights.extend(generator(i))
        except Exception:  # one broken generator must not blank the panel
            continue
    seen: set[str] = set()
    unique = []
    for ins in insights:
        if ins.key not in seen:
            seen.add(ins.key)
            unique.append(ins)
    if not any(x.severity in ("critical", "warning", "notice") for x in unique):
        score = i.scores.overall if i.scores else i.snap.health.score
        unique.append(Insight("nominal", "good", "system",
                              f"All systems nominal — health {score}/100, no anomalies in progress.", priority=1))
    unique.sort(key=lambda x: (SEVERITY_ORDER.get(x.severity, 9), x.priority))
    return unique[:limit]
