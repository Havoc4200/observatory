"""Predictive analytics: storage exhaustion and resource trends."""

from __future__ import annotations

import time
from dataclasses import dataclass

from observatory.engines.stats import downsample, linear_regression, mann_kendall, theil_sen
from observatory.storage.repository import Repository

MIN_SPAN_SECONDS = 6 * 3600   # need at least 6 h of history to extrapolate
MAX_HORIZON_DAYS = 3650


@dataclass(slots=True)
class StorageForecast:
    mountpoint: str
    used_bytes: float
    total_bytes: float
    growth_bytes_per_day: float
    days_to_full: float | None   # None = not growing / not enough data
    confidence: str              # high | medium | low | insufficient data

    @property
    def status(self) -> str:
        if self.days_to_full is None:
            return "stable" if self.confidence != "insufficient data" else "collecting data"
        if self.days_to_full < 7:
            return "critical"
        if self.days_to_full < 30:
            return "warning"
        return "ok"


@dataclass(slots=True)
class TrendForecast:
    metric: str
    label: str
    current: float
    slope_per_day: float
    projected_7d: float
    projected_30d: float
    r_squared: float


def forecast_storage(repo: Repository, mountpoint: str, total_bytes: float, used_now: float,
                     lookback_days: int = 14, now: float | None = None) -> StorageForecast:
    now = now if now is not None else time.time()
    points = repo.series("disk.used_bytes", mountpoint, now - lookback_days * 86400, now, max_points=400)
    pairs = [(p.ts, p.avg) for p in points]
    if len(pairs) < 6 or pairs[-1][0] - pairs[0][0] < MIN_SPAN_SECONDS:
        return StorageForecast(mountpoint, used_now, total_bytes, 0.0, None, "insufficient data")
    pairs = downsample(pairs, 120)
    xs = [t for t, _ in pairs]
    ys = [v for _, v in pairs]
    slope, _intercept = theil_sen(xs, ys)  # bytes per second
    tau, _z = mann_kendall(ys)
    _ols_slope, _ols_int, r2 = linear_regression(xs, ys)
    per_day = slope * 86400
    span_days = (xs[-1] - xs[0]) / 86400
    if abs(tau) >= 0.6 and r2 >= 0.6 and span_days >= 3:
        confidence = "high"
    elif abs(tau) >= 0.4 and span_days >= 1:
        confidence = "medium"
    else:
        confidence = "low"
    free = max(total_bytes - used_now, 0.0)
    if per_day <= 0 or tau < 0.2:
        days = None
    else:
        days = min(free / per_day, MAX_HORIZON_DAYS)
    return StorageForecast(mountpoint, used_now, total_bytes, per_day, days, confidence)


def forecast_trend(repo: Repository, metric: str, label: str = "", lookback_days: int = 7,
                   now: float | None = None) -> TrendForecast | None:
    now = now if now is not None else time.time()
    points = repo.series(metric, label, now - lookback_days * 86400, now, max_points=200)
    if len(points) < 6 or points[-1].ts - points[0].ts < MIN_SPAN_SECONDS:
        return None
    xs = [p.ts for p in points]
    ys = [p.avg for p in points]
    slope, intercept = theil_sen(xs, ys)
    _s, _i, r2 = linear_regression(xs, ys)
    current = ys[-1]
    return TrendForecast(
        metric=metric,
        label=label,
        current=current,
        slope_per_day=slope * 86400,
        projected_7d=slope * (now + 7 * 86400) + intercept,
        projected_30d=slope * (now + 30 * 86400) + intercept,
        r_squared=r2,
    )
