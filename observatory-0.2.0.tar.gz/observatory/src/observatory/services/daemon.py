"""Headless collector daemon (run by the systemd service).

Collects a snapshot every ``storage.sample_interval`` seconds, records
metrics/energy/alerts/events, runs rollups and retention, and keeps a
heartbeat so interactive TUI sessions know not to record duplicates.
"""

from __future__ import annotations

import logging
import signal
import threading
import time
from pathlib import Path

from observatory.config import Config, load_config
from observatory.services.monitor import MonitorService
from observatory.util.format import fmt_money, fmt_watts

log = logging.getLogger("observatory.daemon")


def _mtime(path: Path | None) -> float | None:
    if path is None:
        return None
    try:
        return path.stat().st_mtime
    except OSError:
        return None


def run_daemon(cfg: Config, stop: threading.Event | None = None, max_cycles: int | None = None,
               config_path: str | None = None) -> int:
    stop = stop or threading.Event()

    def _handle(signum, _frame):
        log.info("received signal %s, stopping", signal.Signals(signum).name)
        stop.set()

    reload_requested = threading.Event()

    def _reload(_signum, _frame):
        reload_requested.set()

    if threading.current_thread() is threading.main_thread():
        signal.signal(signal.SIGTERM, _handle)
        signal.signal(signal.SIGINT, _handle)
        signal.signal(signal.SIGHUP, _reload)

    service = MonitorService(cfg, mode="always")
    if service.storage_error:
        log.error("%s", service.storage_error)
        service.close()
        return 2
    log.info("Observatory daemon started; database %s; interval %.1fs", cfg.resolved_db_path(),
             cfg.storage.sample_interval)
    for line in service.hardware.summary_lines():
        log.info("hardware: %s", line)

    cycles = 0
    last_log = 0.0
    watched = Path(config_path).expanduser() if config_path else cfg.source_path
    watched_mtime = _mtime(watched)
    try:
        while not stop.is_set():
            started = time.monotonic()
            current_mtime = _mtime(watched)
            if current_mtime != watched_mtime:
                # Settings saved from a TUI (or an editor): pick the change up automatically.
                watched_mtime = current_mtime
                reload_requested.set()
            if reload_requested.is_set():
                reload_requested.clear()
                try:
                    new_cfg = load_config(watched)
                    service.apply_config(new_cfg)
                    cfg = new_cfg
                    log.info("configuration reloaded from %s", new_cfg.source_path)
                except Exception:
                    log.exception("configuration reload failed; keeping previous settings")
            try:
                snap = service.collect()
            except Exception:
                log.exception("collection cycle failed")
            else:
                for alert in snap.new_alerts:
                    log.warning("ALERT [%s] %s: %s", alert.severity, alert.kind, alert.message)
                if time.monotonic() - last_log >= 300:
                    last_log = time.monotonic()
                    log.info("cpu %.0f%% mem %.0f%% power %s cost today %s health %d",
                             snap.cpu.percent, snap.memory.percent, fmt_watts(snap.power.wall_watts),
                             fmt_money(snap.cost.today_cost, snap.cost.currency_symbol), snap.health.score)
            cycles += 1
            if max_cycles is not None and cycles >= max_cycles:
                break
            interval = min(max(cfg.storage.sample_interval, 2.0), 60.0)
            stop.wait(max(interval - (time.monotonic() - started), 0.1))
    finally:
        service.close()
        log.info("Observatory daemon stopped")
    return 0
