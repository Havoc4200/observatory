"""The monitoring service: one object that runs every collector and engine.

Both the TUI and the headless daemon use :class:`MonitorService`. Each call
to :meth:`MonitorService.collect` produces a complete :class:`Snapshot`.

Recording modes
---------------
``always``  the daemon: persist metrics, energy, alerts and events.
``never``   view only (e.g. ``observatory --no-record``).
``auto``    the TUI default: record only while no daemon heartbeat is fresh,
            so running the TUI alongside the systemd service never writes
            duplicate history. Re-evaluated every 30 seconds.
"""

from __future__ import annotations

import logging
import os
import threading
import time
from collections import deque
from dataclasses import replace
from pathlib import Path

from observatory.collectors.disks import DiskCollector
from observatory.collectors.docker import DockerClient, DockerCollector
from observatory.collectors.gpu import GpuCollector
from observatory.collectors.media import MediaCollector
from observatory.collectors.neighbors import read_neighbors, top_connection_apps
from observatory.collectors.network import NetworkCollector
from observatory.collectors.processes import ProcessCollector, kill_process
from observatory.collectors.sensors import SensorCollector
from observatory.collectors.services import ServiceCollector
from observatory.collectors.smart import SmartCollector
from observatory.collectors.changes import group_changes, recent_package_changes
from observatory.collectors.system import SystemCollector
from observatory.config import Config
from observatory.engines.anomaly import AnomalyEngine
from observatory.engines.cost import CostEngine
from observatory.engines.hardware import HardwareProfile, detect_hardware
from observatory.engines.health import compute_health
from observatory.engines.insights import InsightInputs, generate_insights
from observatory.engines.intelligence import ContextBuilder
from observatory.engines.power import PowerEngine, PowerInputs
from observatory.engines.scores import compute_scores
from observatory.models import Alert, Snapshot, TempReading
from observatory.storage.aggregation import Aggregator
from observatory.storage.database import Database
from observatory.storage.repository import Repository
from observatory.util.rates import RateTracker
from observatory.util.sysinfo import system_identity
from observatory.util.updates import UpdateChecker

log = logging.getLogger(__name__)

AGGREGATE_EVERY = 60.0
PRUNE_EVERY = 3600.0
MODE_CHECK_EVERY = 30.0
MAX_ENERGY_GAP = 120.0  # never integrate across gaps longer than this (sleep, suspend)


class BackgroundJobs:
    """Run slow, independent refreshes (SMART, media APIs, updates) in daemon
    threads, at most one at a time per job name."""

    def __init__(self) -> None:
        self._threads: dict[str, threading.Thread] = {}

    def run(self, name: str, fn, *args) -> bool:
        thread = self._threads.get(name)
        if thread is not None and thread.is_alive():
            return False

        def target() -> None:
            try:
                fn(*args)
            except Exception:
                log.exception("background job %s failed", name)

        thread = threading.Thread(target=target, name=f"obs-{name}", daemon=True)
        self._threads[name] = thread
        thread.start()
        return True

    def running(self, name: str) -> bool:
        thread = self._threads.get(name)
        return thread is not None and thread.is_alive()

    def wait(self, timeout: float = 5.0) -> None:
        deadline = time.monotonic() + timeout
        for thread in list(self._threads.values()):
            thread.join(max(deadline - time.monotonic(), 0))


def build_metric_rows(snap: Snapshot) -> list[tuple[str, str, float]]:
    """Flatten a snapshot into (metric, label, value) rows for ``metrics_raw``."""
    rows: list[tuple[str, str, float]] = [
        ("cpu.percent", "", snap.cpu.percent),
        ("cpu.iowait", "", snap.cpu.iowait),
        ("cpu.freq_mhz", "", snap.cpu.freq_mhz),
        ("mem.percent", "", snap.memory.percent),
        ("mem.used_bytes", "", float(snap.memory.used)),
        ("swap.percent", "", snap.swap.percent),
        ("load.1", "", snap.load.load1),
        ("load.5", "", snap.load.load5),
        ("load.15", "", snap.load.load15),
        ("proc.count", "", float(snap.process_count)),
        ("power.watts", "", snap.power.wall_watts),
        ("power.cost_per_hour", "", snap.cost.hourly_cost),
        ("health.score", "", float(snap.health.score)),
        ("alerts.active", "", float(len(snap.alerts))),
    ]
    for comp in snap.power.components:
        rows.append(("power.component", comp.name, comp.watts))
    for d in snap.disks:
        rows.append(("disk.used_pct", d.mountpoint, d.percent))
        rows.append(("disk.used_bytes", d.mountpoint, float(d.used)))
        rows.append(("disk.total_bytes", d.mountpoint, float(d.total)))
    for io in snap.disk_io:
        rows.append(("disk.read_bps", io.device, io.read_bps))
        rows.append(("disk.write_bps", io.device, io.write_bps))
        rows.append(("disk.util", io.device, io.util_percent))
    for n in snap.net:
        if n.name == "lo":
            continue
        rows.append(("net.rx_bps", n.name, n.rx_bps))
        rows.append(("net.tx_bps", n.name, n.tx_bps))
    rx, tx = snap.net_totals()
    rows.append(("net.rx_bps", "_total", rx))
    rows.append(("net.tx_bps", "_total", tx))
    for t in snap.temps:
        rows.append(("temp.c", t.name, t.current))
    hottest = snap.hottest()
    if hottest:
        rows.append(("temp.max_c", "", hottest.current))
    for g in snap.gpus:
        label = f"{g.index}:{g.name}"
        if g.util_percent is not None:
            rows.append(("gpu.util", label, g.util_percent))
        if g.power_w is not None:
            rows.append(("gpu.power_w", label, g.power_w))
        if g.mem_used is not None:
            rows.append(("gpu.mem_used_bytes", label, float(g.mem_used)))
    running = 0
    for c in snap.containers:
        if c.state != "running":
            continue
        running += 1
        rows.append(("container.cpu", c.name, c.cpu_percent))
        rows.append(("container.mem_bytes", c.name, float(c.mem_usage)))
        rows.append(("container.net_rx_bps", c.name, c.net_rx_bps))
        rows.append(("container.net_tx_bps", c.name, c.net_tx_bps))
    if snap.docker_available:
        rows.append(("docker.running", "", float(running)))
    scores = snap.scores
    if scores is not None:
        rows.append(("risk.score", "", float(scores.risk)))
        rows.append(("power.efficiency", "", float(scores.power_efficiency)))
        for name, sub in scores.subs.items():
            rows.append(("health.sub", name, float(sub.score)))
    for key, app in (snap.media or {}).items():
        rows.append(("media.streams", key, float(len(app.streams))))
        if app.queue_total:
            rows.append(("media.queue", key, float(app.queue_total)))
        if app.library_bytes is not None:
            rows.append(("media.library_bytes", key, float(app.library_bytes)))
        if app.download_bps is not None:
            rows.append(("media.download_bps", key, app.download_bps))
            rows.append(("media.upload_bps", key, app.upload_bps or 0.0))
    for name, info in (snap.smart or {}).items():
        if info.temperature_c is not None and not info.standby:
            rows.append(("smart.temp_c", name, info.temperature_c))
    return rows


class MonitorService:
    def __init__(self, cfg: Config, mode: str = "auto", db_path: str | Path | None = None,
                 enable_docker: bool | None = None) -> None:
        if mode not in {"auto", "always", "never"}:
            raise ValueError(f"invalid recording mode {mode!r}")
        self.cfg = cfg
        self.mode = mode
        self.role = "daemon" if mode == "always" else "tui"
        self._lock = threading.RLock()

        self.system = SystemCollector()
        self.disks = DiskCollector()
        self.network = NetworkCollector()
        self.sensors = SensorCollector()
        self.gpu = GpuCollector()
        self.processes = ProcessCollector()
        docker_on = cfg.docker.enabled if enable_docker is None else enable_docker
        self.docker: DockerCollector | None = (
            DockerCollector(DockerClient(cfg.docker.socket, cfg.docker.timeout)) if docker_on else None
        )

        self.hardware: HardwareProfile = detect_hardware(cfg.power)
        self.power = PowerEngine(self.hardware, cfg.power)

        self.db: Database | None = None
        self.repo: Repository | None = None
        self.aggregator: Aggregator | None = None
        self.storage_error = ""
        if mode != "never" or db_path is not None:
            self._open_storage(Path(db_path) if db_path else cfg.resolved_db_path())

        self.cost = CostEngine(cfg.cost, self.repo)
        self.recording = False
        self._update_recording(force=True)
        self.anomaly = AnomalyEngine(cfg.alerts, self.repo if self.recording else None)

        self._last_persist = 0.0
        self._last_energy_ts: float | None = None
        self._last_aggregate = 0.0
        self._last_prune = 0.0
        self._last_mode_check = time.monotonic()
        self._prev_containers: dict[str, tuple[str, int, str]] = {}
        self.last_snapshot: Snapshot | None = None

        # ---- intelligence layer
        self.identity = system_identity()
        self.updates = UpdateChecker()
        self.smart = SmartCollector()
        self.media = MediaCollector(cfg.media.credentials())
        self.context_builder = ContextBuilder(self.repo)
        self.jobs = BackgroundJobs()
        self.idle_floor = self.power.idle_floor()
        self.recent: dict[str, deque[tuple[float, float]]] = {k: deque() for k in ("cpu", "power", "net")}
        self._net_errors = RateTracker()
        self._last_neighbors = 0.0
        self._last_apps = 0.0
        self._top_apps: list = []
        self._smart_persisted_at = 0.0
        self.services = ServiceCollector()
        self._package_changes: list = []
        self._last_changes = 0.0

        if self.repo is not None and self.recording:
            if self.role == "daemon":
                self.repo.resolve_stale_alerts()
            self.repo.insert_event(f"{self.role}_started", f"Observatory {self.role} started",
                                   source=self.role)

    # --------------------------------------------------------------- storage
    def _open_storage(self, path: Path) -> None:
        try:
            self.db = Database(path)
            self.repo = Repository(self.db)
            self.aggregator = Aggregator(self.db, self.cfg.storage)
        except Exception as exc:  # unwritable path, corrupt file, newer schema...
            self.storage_error = f"History disabled: cannot open {path}: {exc}"
            if str(path).startswith("/var/lib/observatory") and os.geteuid() != 0:
                self.storage_error += (" — add your user to the 'observatory' group "
                                       "(sudo usermod -aG observatory $USER) and log in again")
            log.error(self.storage_error)
            self.db = self.repo = self.aggregator = None

    def _daemon_alive(self) -> bool:
        if self.repo is None:
            return False
        try:
            last = self.repo.last_heartbeat("daemon")
        except Exception:
            return False
        freshness = max(3 * self.cfg.storage.sample_interval, 30.0) + 15.0
        return time.time() - last < freshness

    def _update_recording(self, force: bool = False) -> None:
        previous = self.recording
        if self.repo is None or self.mode == "never":
            self.recording = False
        elif self.mode == "always":
            self.recording = True
        else:
            self.recording = not self._daemon_alive()
        if not force and previous != self.recording and hasattr(self, "anomaly"):
            # hand alert persistence over between TUI and daemon cleanly
            self.anomaly.manager.repo = self.repo if self.recording else None
            log.info("recording %s", "enabled" if self.recording else "disabled (daemon is recording)")

    # --------------------------------------------------------------- collect
    def collect(self) -> Snapshot:
        with self._lock:
            return self._collect()

    def _collect(self) -> Snapshot:
        now = time.time()
        if time.monotonic() - self._last_mode_check >= MODE_CHECK_EVERY:
            self._last_mode_check = time.monotonic()
            self._update_recording()

        snap = Snapshot(ts=now, hostname=self.cfg.general.host_name or self.system.hostname)
        snap.cpu = self.system.cpu()
        snap.memory = self.system.memory()
        snap.swap = self.system.swap()
        snap.load = self.system.load()
        snap.uptime_s = self.system.uptime()
        snap.disks = self.disks.usage()
        snap.disk_io = self.disks.io()
        snap.storage_devices = self.disks.devices()
        snap.temps = self.sensors.collect()
        snap.net = self.network.collect()
        snap.gpus = self.gpu.collect()
        for g in snap.gpus:  # make GPU temperatures visible to thermal detection
            if g.temp_c is not None and g.vendor == "NVIDIA":
                snap.temps.append(TempReading(chip="nvidia", label=f"GPU{g.index}", current=g.temp_c,
                                              kind="gpu"))
        snap.processes, snap.process_count = self.processes.collect(self.cfg.ui.process_limit)
        if self.docker is not None:
            snap.containers, snap.docker_available, snap.docker_error = self.docker.collect()
        else:
            snap.docker_error = "Docker integration disabled in settings"

        snap.power = self.power.estimate(PowerInputs(
            cpu_percent=snap.cpu.percent,
            memory_percent=snap.memory.percent,
            gpus=snap.gpus,
            disk_io=snap.disk_io,
        ))

        # Energy accumulates every cycle (not only every sample interval).
        if self.recording and self.repo is not None:
            if self._last_energy_ts is not None:
                gap = now - self._last_energy_ts
                if 0 < gap <= MAX_ENERGY_GAP:
                    self._safe(self.repo.add_energy, now, snap.power.wall_watts, gap, self.cfg.cost.rate_per_kwh)
            self._last_energy_ts = now
        else:
            self._last_energy_ts = None

        snap.cost = self.cost.compute(snap.power.wall_watts, now)

        if self.recording or self.repo is None:
            active, fired, _resolved = self.anomaly.evaluate(snap)
            snap.alerts = active
            snap.new_alerts = fired
        else:
            snap.alerts = self._safe(self.repo.alerts, True) or []

        self._container_events(snap)
        snap.health = compute_health(snap, self.cfg.alerts)
        snap.recording = self.recording
        self._intelligence(snap, now)

        if self.recording and self.repo is not None:
            if now - self._last_persist >= self.cfg.storage.sample_interval:
                self._last_persist = now
                self._safe(self.repo.insert_metrics, now, build_metric_rows(snap))
                self._safe(self.repo.insert_process_samples, now, snap.processes)
            self._safe(self.repo.heartbeat, self.role, now)
            if self.aggregator is not None:
                if now - self._last_aggregate >= AGGREGATE_EVERY:
                    self._last_aggregate = now
                    self._safe(self.aggregator.rollup, now)
                if now - self._last_prune >= PRUNE_EVERY:
                    self._last_prune = now
                    self._safe(self.aggregator.prune, now)

        self.last_snapshot = snap
        return snap

    # ---------------------------------------------------------- intelligence
    def _recent_avg(self, key: str, value: float, now: float, window: float = 300.0) -> float:
        buf = self.recent[key]
        buf.append((now, value))
        while buf and buf[0][0] < now - window:
            buf.popleft()
        return sum(v for _, v in buf) / len(buf)

    def _intelligence(self, snap: Snapshot, now: float) -> None:
        snap.identity = self.identity
        rx, tx = snap.net_totals()
        recent_cpu = self._recent_avg("cpu", snap.cpu.percent, now)
        recent_power = self._recent_avg("power", snap.power.wall_watts, now)
        recent_net = self._recent_avg("net", rx + tx, now)
        errors = sum(n.errors + n.drops for n in snap.net if not n.virtual)
        snap.net_error_rate = self._net_errors.rate("errors", errors)

        # slow background jobs (never block collection)
        if self.updates.due(now):
            self.updates.status.checked_at = now  # avoid re-queuing while running
            self.jobs.run("updates", self.updates.check)
        if self.smart.due(now):
            self.smart.last_run = now
            devices = [d.name for d in snap.storage_devices]
            self.jobs.run("smart", self.smart.refresh, devices)
        if self.cfg.media.enabled and now - self.media.last_run >= self.cfg.media.poll_interval:
            self.media.last_run = now
            self.jobs.run("media", self.media.refresh, list(snap.containers), list(snap.processes))
        if now - self._last_apps >= 30:
            self._last_apps = now
            self.jobs.run("apps", self._refresh_top_apps)
        if self.services.due(now):
            self.services.summary.checked_at = now
            self.jobs.run("services", self.services.refresh)
        if now - self._last_changes >= 300:
            self._last_changes = now
            self.jobs.run("changes", self._refresh_package_changes, now)
        if self.recording and self.repo is not None and now - self._last_neighbors >= 60:
            self._last_neighbors = now
            sightings = [(n.mac, n.ip, n.interface) for n in read_neighbors()]
            new = self._safe(self.repo.upsert_neighbors, sightings, now) or []
            for mac in new:
                ip = next((s[1] for s in sightings if s[0] == mac), "?")
                self._safe(self.repo.insert_event, "network_device_new", f"New device {ip} ({mac})",
                           "info", mac, "network")

        snap.updates = self.updates.status
        snap.smart = self.smart.snapshot()
        snap.smart_error = self.smart.error
        snap.media = self.media.snapshot() if self.cfg.media.enabled else {}
        snap.top_apps = self._top_apps
        snap.services = self.services.summary
        snap.package_changes = self._package_changes

        if self.context_builder.due(now):
            mounts = [(d.mountpoint, float(d.total), float(d.used)) for d in snap.disks]
            self._safe(self.context_builder.build, now, self.cfg.cost.rate_per_kwh, mounts,
                       [d.device for d in snap.disk_io], list(snap.media))
            if self.recording and self.repo is not None and snap.smart and now - self._smart_persisted_at > 1800:
                self._smart_persisted_at = now
                for name, info in snap.smart.items():
                    if not info.standby:
                        self._safe(self.repo.insert_smart, name, now, info.serial, info.model, info.health_score,
                                   info.risk, info.temperature_c, {"reasons": info.reasons})
        ctx = self.context_builder.context if self.context_builder.context.available else None
        snap.context = ctx

        idle_hdds = 0
        if ctx is not None and ctx.history_days >= 1:
            spun = set(self.cfg.power.spun_down_drives)
            idle_hdds = sum(1 for d in snap.storage_devices
                            if d.kind == "hdd" and d.name not in spun and ctx.disk_idle_24h.get(d.name, 100) < 0.5)
        snap.scores = compute_scores(snap, self.cfg.alerts, ctx, snap.smart, snap.updates,
                                     legacy_health=snap.health.score, idle_floor_watts=self.idle_floor,
                                     idle_spinning_hdds=idle_hdds, net_error_rate=snap.net_error_rate)
        snap.health.score = snap.scores.overall
        has_gpu = any(g.vendor in ("NVIDIA", "Intel", "AMD") for g in snap.gpus) or bool(self.hardware.gpus)
        snap.insights = generate_insights(InsightInputs(
            snap=snap, cfg=self.cfg, ctx=ctx, scores=snap.scores, smart=snap.smart, media=snap.media,
            updates=snap.updates, storage_devices=snap.storage_devices, recent_cpu=recent_cpu,
            recent_net_bps=recent_net, recent_power=recent_power, has_gpu_encoder=has_gpu,
        ))

    def _refresh_top_apps(self) -> None:
        self._top_apps = top_connection_apps(6)

    def _refresh_package_changes(self, now: float) -> None:
        self._package_changes = group_changes(recent_package_changes(now - 7 * 86400))

    def _container_events(self, snap: Snapshot) -> None:
        current = {c.id: (c.state, c.restart_count, c.health) for c in snap.containers}
        names = {c.id: c.name for c in snap.containers}
        if self._prev_containers and self.recording and self.repo is not None:
            for cid, (state, restarts, health) in current.items():
                prev = self._prev_containers.get(cid)
                name = names[cid]
                if prev is None:
                    self._safe(self.repo.insert_event, "container_created", f"Container {name} appeared",
                               "info", name, "docker")
                    continue
                if restarts > prev[1]:
                    self._safe(self.repo.insert_event, "container_restart",
                               f"{name} restarted ({restarts} restarts total)", "warning", name, "docker")
                if state != prev[0]:
                    severity = "warning" if state in {"exited", "dead"} else "info"
                    self._safe(self.repo.insert_event, "container_state", f"{name}: {prev[0]} → {state}",
                               severity, name, "docker")
                if health != prev[2] and health == "unhealthy":
                    self._safe(self.repo.insert_event, "container_unhealthy", f"{name} became unhealthy",
                               "warning", name, "docker")
            for cid, prev in self._prev_containers.items():
                if cid not in current:
                    self._safe(self.repo.insert_event, "container_removed", "Container removed",
                               "info", cid[:12], "docker")
        self._prev_containers = current

    def _safe(self, fn, *args, **kwargs):
        try:
            return fn(*args, **kwargs)
        except Exception as exc:
            log.warning("storage operation %s failed: %s", getattr(fn, "__name__", fn), exc)
            return None

    # --------------------------------------------------------------- actions
    def kill(self, pid: int, force: bool = False) -> tuple[bool, str]:
        ok, message = kill_process(pid, force)
        if ok and self.repo is not None:
            self._safe(self.repo.insert_event, "process_signal", message, "info", str(pid), "user")
        return ok, message

    def docker_action(self, action: str, container_id: str, name: str = "") -> tuple[bool, str]:
        if self.docker is None:
            return False, "Docker integration is disabled."
        ok, message = self.docker.act(action, container_id)
        if ok and self.repo is not None:
            self._safe(self.repo.insert_event, f"container_{action}", f"User requested {action} of {name or container_id[:12]}",
                       "info", name or container_id[:12], "user")
        return ok, message

    def acknowledge(self, alert_id: int) -> None:
        self.anomaly.manager.acknowledge(alert_id)
        if self.repo is not None and not self.recording:
            self._safe(self.repo.acknowledge_alert, alert_id)

    def alerts_history(self, limit: int = 300) -> list[Alert]:
        if self.repo is None:
            return list(self.anomaly.manager.active.values())
        return self._safe(self.repo.alerts, False, limit) or []

    def recent_events(self, window: float = 86400, limit: int = 80) -> list:
        if self.repo is None:
            return []
        return self._safe(self.repo.events, limit, time.time() - window) or []

    # ---------------------------------------------------------------- config
    def apply_config(self, cfg: Config) -> None:
        with self._lock:
            power_changed = cfg.power != self.cfg.power
            self.cfg = cfg
            if power_changed:
                self.hardware = detect_hardware(cfg.power)
                self.power.update_config(cfg.power, self.hardware)
                self.idle_floor = self.power.idle_floor()
            self.media.update_credentials(cfg.media.credentials())
            self.media.last_run = 0.0
            self.cost.update_config(cfg.cost)
            if self.aggregator is not None:
                self.aggregator.storage = cfg.storage
            self.anomaly.update_config(cfg.alerts)
            if self.docker is None and cfg.docker.enabled:
                self.docker = DockerCollector(DockerClient(cfg.docker.socket, cfg.docker.timeout))
            elif self.docker is not None and not cfg.docker.enabled:
                self.docker.close()
                self.docker = None
            if self.repo is not None and self.recording:
                self._safe(self.repo.insert_event, "config_changed", "Settings updated", "info", "", "user")

    def close(self) -> None:
        with self._lock:
            if self.repo is not None and self.recording:
                self._safe(self.repo.insert_event, f"{self.role}_stopped", f"Observatory {self.role} stopped",
                           source=self.role)
                if self.aggregator is not None:
                    self._safe(self.aggregator.rollup)
            if self.docker is not None:
                self.docker.close()
            if self.db is not None:
                self.db.close()
                self.db = None


def copy_config(cfg: Config) -> Config:
    """Deep-ish copy so Settings can edit without mutating the live config."""
    return Config(
        general=replace(cfg.general), storage=replace(cfg.storage),
        power=replace(cfg.power, spun_down_drives=list(cfg.power.spun_down_drives)),
        cost=replace(cfg.cost), alerts=replace(cfg.alerts), docker=replace(cfg.docker), ui=replace(cfg.ui),
        media=replace(cfg.media), source_path=cfg.source_path,
    )
