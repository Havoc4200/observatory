"""Plain data classes shared by collectors, engines, storage and the UI.

They are intentionally free of behaviour so they can be built in a worker
thread and handed to the UI thread without locking.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal

Severity = Literal["info", "warning", "critical"]


@dataclass(slots=True)
class CpuStats:
    percent: float = 0.0
    per_core: list[float] = field(default_factory=list)
    user: float = 0.0
    system: float = 0.0
    iowait: float = 0.0
    steal: float = 0.0
    freq_mhz: float = 0.0
    freq_max_mhz: float = 0.0
    cores_logical: int = 1
    cores_physical: int = 1
    model: str = ""


@dataclass(slots=True)
class MemoryStats:
    total: int = 0
    used: int = 0
    available: int = 0
    percent: float = 0.0
    cached: int = 0
    buffers: int = 0


@dataclass(slots=True)
class SwapStats:
    total: int = 0
    used: int = 0
    percent: float = 0.0
    sin_bps: float = 0.0
    sout_bps: float = 0.0


@dataclass(slots=True)
class LoadStats:
    load1: float = 0.0
    load5: float = 0.0
    load15: float = 0.0
    cores: int = 1

    @property
    def per_core1(self) -> float:
        return self.load1 / max(self.cores, 1)


@dataclass(slots=True)
class DiskUsage:
    device: str
    mountpoint: str
    fstype: str
    total: int
    used: int
    free: int
    percent: float


@dataclass(slots=True)
class DiskIO:
    device: str
    read_bps: float = 0.0
    write_bps: float = 0.0
    read_iops: float = 0.0
    write_iops: float = 0.0
    util_percent: float = 0.0

    @property
    def total_bps(self) -> float:
        return self.read_bps + self.write_bps


@dataclass(slots=True)
class StorageDevice:
    name: str
    model: str = ""
    kind: str = "unknown"  # hdd | ssd | nvme | virtual | usb | unknown
    size_bytes: int = 0
    rotational: bool = False
    removable: bool = False


@dataclass(slots=True)
class TempReading:
    chip: str
    label: str
    current: float
    high: float | None = None
    critical: float | None = None
    kind: str = "other"  # cpu | gpu | drive | board | other

    @property
    def name(self) -> str:
        return f"{self.chip}:{self.label}" if self.label else self.chip


@dataclass(slots=True)
class NetInterface:
    name: str
    is_up: bool = False
    speed_mbps: int = 0
    addresses: list[str] = field(default_factory=list)
    rx_bps: float = 0.0
    tx_bps: float = 0.0
    rx_total: int = 0
    tx_total: int = 0
    errors: int = 0
    drops: int = 0
    virtual: bool = False

    @property
    def total_bps(self) -> float:
        return self.rx_bps + self.tx_bps


@dataclass(slots=True)
class GpuStats:
    index: int
    name: str
    vendor: str
    util_percent: float | None = None
    mem_used: int | None = None
    mem_total: int | None = None
    temp_c: float | None = None
    power_w: float | None = None
    power_limit_w: float | None = None


@dataclass(slots=True)
class ProcessInfo:
    pid: int
    name: str
    username: str = ""
    cpu_percent: float = 0.0
    memory_percent: float = 0.0
    rss: int = 0
    threads: int = 0
    status: str = ""
    cmdline: str = ""
    create_time: float = 0.0

    @property
    def key(self) -> tuple[int, float]:
        return (self.pid, self.create_time)


@dataclass(slots=True)
class ContainerInfo:
    id: str
    name: str
    image: str = ""
    state: str = ""          # running | exited | paused | restarting | created | dead
    status: str = ""         # human status, e.g. "Up 3 hours (healthy)"
    health: str = ""         # healthy | unhealthy | starting | "" (no healthcheck)
    cpu_percent: float = 0.0
    mem_usage: int = 0
    mem_limit: int = 0
    mem_percent: float = 0.0
    net_rx_bps: float = 0.0
    net_tx_bps: float = 0.0
    restart_count: int = 0
    started_at: str = ""
    compose_project: str = ""
    ports: str = ""


@dataclass(slots=True)
class PowerComponent:
    name: str
    watts: float
    method: str  # measured | modeled | configured


@dataclass(slots=True)
class PowerEstimate:
    wall_watts: float = 0.0
    dc_watts: float = 0.0
    low_watts: float = 0.0
    high_watts: float = 0.0
    psu_efficiency: float = 0.87
    components: list[PowerComponent] = field(default_factory=list)

    @property
    def method(self) -> str:
        methods = {c.method for c in self.components if c.watts > 0}
        if "measured" in methods and methods <= {"measured", "configured"}:
            return "measured"
        if "measured" in methods:
            return "partially measured"
        return "modeled"


@dataclass(slots=True)
class CostSnapshot:
    currency_symbol: str = "$"
    currency: str = "USD"
    rate_per_kwh: float = 0.0
    hourly_cost: float = 0.0
    today_kwh: float = 0.0
    today_cost: float = 0.0
    projected_daily_kwh: float = 0.0
    month_to_date_cost: float = 0.0
    monthly_kwh_estimate: float = 0.0
    monthly_estimate: float = 0.0
    annual_estimate: float = 0.0
    average_watts: float = 0.0


@dataclass(slots=True)
class Alert:
    kind: str
    severity: Severity
    subject: str
    message: str
    value: float | None = None
    started_at: float = 0.0
    ended_at: float | None = None
    state: str = "active"  # active | resolved
    acknowledged: bool = False
    id: int | None = None

    @property
    def key(self) -> tuple[str, str]:
        return (self.kind, self.subject)


@dataclass(slots=True)
class HealthScore:
    score: int = 100
    reasons: list[str] = field(default_factory=list)

    @property
    def grade(self) -> str:
        if self.score >= 90:
            return "Excellent"
        if self.score >= 75:
            return "Good"
        if self.score >= 50:
            return "Fair"
        if self.score >= 25:
            return "Poor"
        return "Critical"


@dataclass(slots=True)
class Snapshot:
    ts: float
    hostname: str = ""
    uptime_s: float = 0.0
    cpu: CpuStats = field(default_factory=CpuStats)
    memory: MemoryStats = field(default_factory=MemoryStats)
    swap: SwapStats = field(default_factory=SwapStats)
    load: LoadStats = field(default_factory=LoadStats)
    disks: list[DiskUsage] = field(default_factory=list)
    disk_io: list[DiskIO] = field(default_factory=list)
    storage_devices: list[StorageDevice] = field(default_factory=list)
    temps: list[TempReading] = field(default_factory=list)
    net: list[NetInterface] = field(default_factory=list)
    gpus: list[GpuStats] = field(default_factory=list)
    processes: list[ProcessInfo] = field(default_factory=list)
    process_count: int = 0
    containers: list[ContainerInfo] = field(default_factory=list)
    docker_available: bool = False
    docker_error: str = ""
    power: PowerEstimate = field(default_factory=PowerEstimate)
    cost: CostSnapshot = field(default_factory=CostSnapshot)
    health: HealthScore = field(default_factory=HealthScore)
    alerts: list[Alert] = field(default_factory=list)
    new_alerts: list[Alert] = field(default_factory=list)
    recording: bool = False
    # ---- intelligence layer (filled by MonitorService; typed loosely to avoid import cycles)
    identity: Any = None        # util.sysinfo.SystemIdentity
    updates: Any = None         # util.updates.UpdateStatus
    smart: dict[str, Any] = field(default_factory=dict)      # device -> collectors.smart.SmartInfo
    media: dict[str, Any] = field(default_factory=dict)      # key -> collectors.media.MediaApp
    context: Any = None         # engines.intelligence.HistoricalContext
    scores: Any = None          # engines.scores.Scores
    insights: list[Any] = field(default_factory=list)        # engines.insights.Insight
    top_apps: list[Any] = field(default_factory=list)        # collectors.neighbors.AppConnections
    net_error_rate: float = 0.0
    smart_error: str = ""
    services: Any = None        # collectors.services.ServiceSummary
    package_changes: list[Any] = field(default_factory=list)  # collectors.changes.ChangeGroup, last 7 days

    # ---------------------------------------------------------- conveniences
    def top_process(self, by: str = "cpu") -> ProcessInfo | None:
        if not self.processes:
            return None
        if by == "memory":
            return max(self.processes, key=lambda p: p.rss)
        return max(self.processes, key=lambda p: p.cpu_percent)

    def top_container(self) -> ContainerInfo | None:
        running = [c for c in self.containers if c.state == "running"]
        if not running:
            return None
        return max(running, key=lambda c: (c.cpu_percent, c.mem_usage))

    def most_active_drive(self) -> DiskIO | None:
        if not self.disk_io:
            return None
        return max(self.disk_io, key=lambda d: (d.total_bps, d.util_percent))

    def hottest(self) -> TempReading | None:
        if not self.temps:
            return None
        return max(self.temps, key=lambda t: t.current)

    def net_totals(self) -> tuple[float, float]:
        physical = [n for n in self.net if not n.virtual] or self.net
        return (sum(n.rx_bps for n in physical), sum(n.tx_bps for n in physical))
