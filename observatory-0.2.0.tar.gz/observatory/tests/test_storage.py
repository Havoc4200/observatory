import time

import pytest

from observatory.config import StorageConfig
from observatory.models import ProcessInfo
from observatory.storage.aggregation import Aggregator
from observatory.storage.database import SCHEMA_VERSION, Database
from observatory.storage.repository import Repository, local_midnight, pick_table
from tests.conftest import make_alert

EXPECTED_TABLES = {"meta", "metrics_raw", "metrics_1m", "metrics_1h", "metrics_1d", "energy_hourly",
                   "process_samples", "events", "alerts"}


class TestSchema:
    def test_migration_creates_all_tables(self, db):
        names = {r["name"] for r in db.query("SELECT name FROM sqlite_master WHERE type = 'table'")}
        assert EXPECTED_TABLES <= names
        assert db.schema_version == SCHEMA_VERSION

    def test_reopen_is_idempotent(self, tmp_path):
        path = tmp_path / "x.db"
        Database(path).close()
        db = Database(path)
        assert db.schema_version == SCHEMA_VERSION
        db.close()

    def test_newer_schema_is_refused(self, tmp_path):
        path = tmp_path / "future.db"
        db = Database(path)
        db.execute(f"PRAGMA user_version={SCHEMA_VERSION + 5}")
        db.close()
        with pytest.raises(RuntimeError, match="newer"):
            Database(path)

    def test_wal_mode(self, db):
        assert db.query_one("PRAGMA journal_mode")[0] == "wal"

    def test_transaction_rolls_back(self, db, repo):
        with pytest.raises(ZeroDivisionError):
            with db.transaction() as cur:
                cur.execute("INSERT INTO meta(key, value) VALUES('k', 'v')")
                1 / 0
        assert repo.get_meta("k") is None


class TestRepository:
    def test_meta_and_heartbeat(self, repo):
        repo.set_meta("a", 1)
        repo.set_meta("a", 2)
        assert repo.get_meta("a") == "2"
        repo.heartbeat("daemon", 1234.5)
        assert repo.last_heartbeat("daemon") == 1234.5
        assert repo.last_heartbeat("nobody") == 0.0

    def test_insert_and_query_series(self, repo):
        now = int(time.time())
        for i in range(60):
            repo.insert_metrics(now - 600 + i * 10, [("cpu.percent", "", float(i)), ("temp.c", "cpu", 40.0 + i)])
        points = repo.series("cpu.percent", "", now - 700, now, max_points=1000)
        assert len(points) == 60
        assert points[0].avg == 0 and points[-1].avg == 59
        st = repo.stats("cpu.percent", "", now - 700, now)
        assert st.min == 0 and st.max == 59 and st.avg == pytest.approx(29.5)
        assert repo.labels("temp.c", now - 700) == ["cpu"]

    def test_series_downsamples(self, repo):
        now = int(time.time())
        repo.insert_metrics(now - 100, [("m", "", 1.0)])
        for i in range(500):
            repo.insert_metrics(now - 3000 + i * 6, [("m", "", float(i % 10))])
        assert len(repo.series("m", "", now - 3600, now, max_points=50)) <= 51

    def test_nan_values_dropped(self, repo):
        assert repo.insert_metrics(time.time(), [("m", "", float("nan")), ("m2", "", 1.0)]) == 1

    def test_pick_table(self):
        assert pick_table(3600)[0] == "metrics_raw"
        assert pick_table(86400)[0] == "metrics_1m"
        assert pick_table(30 * 86400)[0] == "metrics_1h"
        assert pick_table(400 * 86400)[0] == "metrics_1d"

    def test_energy_accumulates_per_hour(self, repo):
        hour = int(time.time()) // 3600 * 3600
        repo.add_energy(hour + 10, 100.0, 1800, 0.20)  # 50 Wh
        repo.add_energy(hour + 2000, 200.0, 900, 0.20)  # 50 Wh
        wh, cost, secs = repo.energy_between(hour, hour + 3600)
        assert wh == pytest.approx(100.0)
        assert cost == pytest.approx(0.02)
        assert secs == pytest.approx(2700)
        repo.add_energy(hour, 100.0, 0, 0.2)  # ignored
        assert repo.energy_between(hour, hour + 3600)[2] == pytest.approx(2700)

    def test_energy_daily(self, repo):
        midnight = local_midnight()
        repo.add_energy(midnight + 3600, 1000.0, 3600, 0.10)        # today: 1 kWh
        repo.add_energy(midnight - 86400 + 7200, 500.0, 3600, 0.10)  # yesterday: 0.5 kWh
        days = repo.energy_daily(3, now=midnight + 7200)
        assert days[0].kwh == pytest.approx(1.0)
        assert days[0].cost == pytest.approx(0.10)
        assert days[1].kwh == pytest.approx(0.5)
        assert days[2].kwh == 0

    def test_process_samples(self, repo):
        now = time.time()
        procs = [ProcessInfo(i, f"p{i}", cpu_percent=float(i), rss=i * 1000) for i in range(20)]
        repo.insert_process_samples(now, procs, top_n=3)
        top = repo.top_processes(now - 10, now + 10, limit=5)
        assert top[0]["name"] == "p19"
        assert len(top) <= 5

    def test_events(self, repo):
        repo.insert_event("test", "hello", details={"x": 1})
        repo.insert_event("other", "world", severity="warning")
        events = repo.events()
        assert events[0].kind == "other"
        assert repo.events(kind="test")[0].details == {"x": 1}

    def test_alert_lifecycle(self, repo):
        alert = make_alert()
        repo.insert_alert(alert)
        assert alert.id is not None
        assert repo.alert_counts() == {"warning": 1}
        alert.state, alert.ended_at = "resolved", time.time()
        repo.update_alert(alert)
        assert repo.alerts(active_only=True) == []
        assert repo.alerts()[0].state == "resolved"
        assert repo.clear_resolved() == 1

    def test_acknowledge_and_stale_resolution(self, repo):
        a = make_alert()
        repo.insert_alert(a)
        repo.acknowledge_alert(a.id)
        assert repo.alerts()[0].acknowledged
        assert repo.resolve_stale_alerts() == 1
        assert repo.alerts(active_only=True) == []

    def test_row_counts_and_first_sample(self, repo):
        assert repo.first_sample_ts() is None
        repo.insert_metrics(1000, [("m", "", 1.0)])
        assert repo.first_sample_ts() == 1000
        assert repo.row_counts()["metrics_raw"] == 1


class TestAggregation:
    def _fill(self, repo, start, minutes, value_fn):
        for m in range(minutes):
            for s in range(0, 60, 10):
                ts = start + m * 60 + s
                repo.insert_metrics(ts, [("cpu.percent", "", value_fn(ts))])

    def test_rollup_minutes_hours_days(self, db, repo):
        start = (int(time.time()) // 86400 - 3) * 86400  # three days ago, UTC midnight
        self._fill(repo, start, 180, lambda ts: 50.0)
        agg = Aggregator(db, StorageConfig())
        result = agg.rollup(now=start + 2 * 86400)
        assert result.minute_rows == 180
        assert result.hour_rows == 3
        assert result.day_rows == 1
        row = db.query_one("SELECT avg, min, max, count FROM metrics_1h WHERE bucket = ?", (start,))
        assert row["avg"] == 50.0 and row["count"] == 360
        day = db.query_one("SELECT count FROM metrics_1d WHERE bucket = ?", (start,))
        assert day["count"] == 1080

    def test_weighted_average_carried_up(self, db, repo):
        start = (int(time.time()) // 3600 - 5) * 3600
        # minute 0: six samples of 10; minute 1: one sample of 100
        for s in range(0, 60, 10):
            repo.insert_metrics(start + s, [("m", "", 10.0)])
        repo.insert_metrics(start + 60, [("m", "", 100.0)])
        Aggregator(db, StorageConfig()).rollup(now=start + 4 * 3600)
        row = db.query_one("SELECT avg, count FROM metrics_1h WHERE metric = 'm'")
        assert row["count"] == 7
        assert row["avg"] == pytest.approx((60 + 100) / 7)

    def test_rollup_is_idempotent(self, db, repo):
        start = (int(time.time()) // 3600 - 3) * 3600
        self._fill(repo, start, 30, lambda ts: 1.0)
        agg = Aggregator(db, StorageConfig())
        first = agg.rollup(now=start + 7200)
        second = agg.rollup(now=start + 7200)
        assert first.minute_rows == 30
        assert second.minute_rows == 0

    def test_prune_respects_retention_and_watermark(self, db, repo):
        now = time.time()
        old = int(now - 10 * 86400)
        repo.insert_metrics(old, [("m", "", 1.0)])
        repo.insert_metrics(int(now), [("m", "", 1.0)])
        agg = Aggregator(db, StorageConfig(retention_raw_days=2))
        # nothing rolled up yet → raw data is kept
        assert agg.prune(now).raw == 0
        agg.rollup(now)
        assert agg.prune(now).raw == 1
        assert repo.row_counts()["metrics_raw"] == 1

    def test_prune_rollup_tiers(self, db):
        now = time.time()
        db.execute("INSERT INTO metrics_1m VALUES('m', '', ?, 1, 1, 1, 1)", (int(now - 40 * 86400),))
        db.execute("INSERT INTO metrics_1h VALUES('m', '', ?, 1, 1, 1, 1)", (int(now - 400 * 86400),))
        db.execute("INSERT INTO metrics_1d VALUES('m', '', ?, 1, 1, 1, 1)", (int(now - 4000 * 86400),))
        result = Aggregator(db, StorageConfig()).prune(now)
        assert (result.minute, result.hour, result.day) == (1, 1, 0)  # daily kept forever by default
