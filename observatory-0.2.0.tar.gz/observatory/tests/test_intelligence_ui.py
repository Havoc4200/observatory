"""Tests for the intelligence-layer additions: systemd summary, change journal,
chart primitives and insight impacts."""

from __future__ import annotations

import time

import pytest
from rich.style import Style

from observatory.collectors.changes import (
    ChangeGroup, PackageChange, group_changes, parse_dnf_log, parse_dpkg_log, parse_pacman_log,
)
from observatory.collectors.services import parse_list_units
from observatory.config import Config
from observatory.engines.insights import InsightInputs, generate_insights
from observatory.ui.charts import (
    block_area, heatmap_grid, mirror_area, pulse_line, seg_text, seg_width, spark_blocks, stacked_bar, stretch,
)
from tests.conftest import make_alert, make_snapshot


# ------------------------------------------------------------------ systemd
def test_parse_list_units():
    out = """\
cron.service            loaded    active   running Regular background program processing daemon
docker.service          loaded    active   running Docker Application Container Engine
nut-monitor.service     loaded    failed   failed  Network UPS Tools - power device monitor
ssh.service             loaded    active   running OpenBSD Secure Shell server
plymouth.service        not-found inactive dead    plymouth.service
apt-daily.service       loaded    inactive dead    Daily apt download activities
"""
    running, total, failed = parse_list_units(out)
    assert running == 3
    assert total == 5   # not-found units are ignored
    assert [f.name for f in failed] == ["nut-monitor"]
    assert failed[0].description.startswith("Network UPS Tools")


# ------------------------------------------------------------ change journal
def _ts(text: str) -> float:
    return time.mktime(time.strptime(text, "%Y-%m-%d %H:%M:%S"))


def test_parse_dpkg_log():
    log = """\
2026-09-29 22:10:01 startup archives unpack
2026-09-29 22:10:03 upgrade linux-image-6.8.0-45-generic:amd64 6.8.0-44.44 6.8.0-45.45
2026-09-29 22:10:04 install htop:amd64 <none> 3.3.0-4
2026-09-29 22:10:05 remove oldpkg:amd64 1.0 <none>
2026-09-29 22:10:05 status installed htop:amd64 3.3.0-4
"""
    changes = parse_dpkg_log(log, since=_ts("2026-09-29 00:00:00"))
    assert [(c.action, c.package, c.version) for c in changes] == [
        ("upgrade", "linux-image-6.8.0-45-generic", "6.8.0-45.45"),
        ("install", "htop", "3.3.0-4"),
        ("remove", "oldpkg", "1.0"),
    ]
    assert changes[0].notable and not changes[1].notable
    assert parse_dpkg_log(log, since=_ts("2026-09-30 00:00:00")) == []


def test_parse_dnf_and_pacman_logs():
    dnf = ("2026-09-29T10:00:01+0000 SUBDEBUG Upgrade: kernel-6.10.1-200.fc40.x86_64\n"
           "2026-09-29T10:00:02+0000 SUBDEBUG Upgraded: kernel-6.9.0-100.fc40.x86_64\n"
           "2026-09-29T10:00:03+0000 SUBDEBUG Installed: htop-3.3.0-1.fc40.x86_64\n")
    changes = parse_dnf_log(dnf, since=0)
    assert [c.action for c in changes] == ["upgrade", "install"]
    pac = "[2026-09-29T10:00:01+0000] [ALPM] upgraded linux (6.10.1 -> 6.10.2)\n"
    assert parse_pacman_log(pac, since=0)[0].package == "linux"


def test_group_changes_merges_one_upgrade_run():
    t = 1_000_000.0
    changes = [PackageChange(t, "upgrade", "libc6"), PackageChange(t + 30, "upgrade", "openssl"),
               PackageChange(t + 60, "upgrade", "curl"), PackageChange(t + 5000, "install", "htop")]
    groups = group_changes(changes)
    assert len(groups) == 2
    assert groups[0].count == 3 and groups[0].notable == ("libc6", "openssl")
    assert "3 packages upgraded incl. libc6" in groups[0].message
    assert groups[1].message == "1 package installed"


# ------------------------------------------------------------------ charts
def test_seg_text_rows_and_width():
    rows = seg_text("204W", Style(bold=True))
    assert len(rows) == 3
    assert {r.cell_len for r in rows} == {seg_width("204W")}
    assert "┏━┓" in rows[0].plain  # the zero


def test_block_area_shape_and_baseline():
    chart = block_area([0, 50, 100], 3, 2, ["#000000", "#ffffff"], max_value=100, baseline=25)
    lines = chart.plain.split("\n")
    assert len(lines) == 2 and all(len(line) == 3 for line in lines)
    assert lines[1][2] == "█" and lines[0][2] == "█"   # 100% fills both rows
    assert lines[0][1] == " " and lines[1][1] == "█"   # 50% fills the bottom row


def test_mirror_area_and_stacked_bar():
    m = mirror_area([1, 2, 3], [3, 2, 1], 3, 4, "cyan", "magenta")
    assert len(m.plain.split("\n")) == 4
    bar = stacked_bar([(3, "red"), (1, "blue")], 8)
    assert bar.cell_len == 8 and bar.plain == "█" * 8
    assert len(bar.spans) == 2


def test_stretch_and_spark_fill_width():
    assert stretch([1, 2], 4) == [1, 1, 2, 2]
    assert spark_blocks([1, 2, 3], 9).cell_len == 9
    assert spark_blocks([1, 2, 3], 9).plain[0] != " "   # short series are stretched, not right-aligned


def test_pulse_line_and_heatmap():
    line = pulse_line(0, 30, 0.8, ["#111111", "#eeeeee"], "#333333")
    assert line.cell_len == 30 and ("█" in line.plain or "▇" in line.plain)
    grid = heatmap_grid([[1, None, 3], [2, 2, 2]], ["Mon", "Tue"], ["#000000", "#ffffff"], "#333333", Style(),
                        highlight=(1, 2))
    rows = grid.plain.split("\n")
    assert rows[0].startswith("Mon ") and "·" in rows[0] and rows[1].endswith("◆")


# -------------------------------------------------------- insight impacts
def test_actions_carry_impact_and_upgrade_correlation():
    from observatory.collectors.services import FailedUnit, ServiceSummary

    snap = make_snapshot()
    snap.alerts = [make_alert()]
    snap.services = ServiceSummary(available=True, running=10, total=12,
                                   failed=[FailedUnit("smbd", "Samba SMB daemon")], reboot_required=True)
    snap.package_changes = [ChangeGroup(snap.ts - 2 * 3600, 12, ("linux-image-6.8",), "upgrade")]
    insights = generate_insights(InsightInputs(snap=snap, cfg=Config()))
    by_key = {i.key: i for i in insights}
    assert by_key["unit-failed-smbd"].impact == "service down"
    assert by_key["reboot-required"].recommendation
    assert "likely cause" in by_key["upgrade-correlation"].text
    actionable = [i for i in insights if i.recommendation and i.severity in ("critical", "warning", "notice")]
    assert actionable and all(i.impact for i in actionable)


def test_storage_fill_insight_has_date_and_impact():
    from observatory.engines.forecast import StorageForecast
    from observatory.engines.intelligence import HistoricalContext

    snap = make_snapshot()
    ctx = HistoricalContext(available=True)
    ctx.storage = {"/tank": StorageForecast("/tank", 6e12, 8e12, 50e9, 12.0, "high")}
    insights = generate_insights(InsightInputs(snap=snap, cfg=Config(), ctx=ctx))
    fill = next(i for i in insights if i.key == "fill-/tank")
    assert fill.severity == "warning" and fill.impact == "full in 12 d"
    assert "before" in fill.recommendation


@pytest.mark.parametrize("width,height", [(160, 45), (180, 50), (230, 62)])
def test_plan_layout_uses_full_height(width, height):
    from observatory.ui.dashboard.home import plan_layout

    plan = plan_layout(width, height)
    assert plan["a"] + plan["b"] + plan["c"] + plan["d"] == height
