import threading
import time

import pytest

from observatory.engines.forecast import forecast_storage, forecast_trend
from observatory.services.daemon import run_daemon
from observatory.services.monitor import MonitorService, build_metric_rows, copy_config
from tests.conftest import make_snapshot


class TestForecast:
    def test_storage_growth_projects_days_to_full(self, repo):
        now = time.time()
        total = 1000 * 10**9
        for h in range(0, 24 * 7):
            used = 500 * 10**9 + h * 10**9  # +1 GB/hour = 24 GB/day
            repo.insert_metrics(now - (24 * 7 - h) * 3600, [("disk.used_bytes", "/data", float(used))])
        used_now = 500 * 10**9 + 24 * 7 * 10**9
        fc = forecast_storage(repo, "/data", total, used_now, now=now)
        assert fc.growth_bytes_per_day == pytest.approx(24 * 10**9, rel=0.05)
        assert fc.days_to_full == pytest.approx((total - used_now) / (24 * 10**9), rel=0.05)
        assert fc.confidence == "high" and fc.status == "warning"  # ~14 days left

    def test_stable_and_insufficient(self, repo):
        now = time.time()
        assert forecast_storage(repo, "/x", 100, 50, now=now).confidence == "insufficient data"
        for h in range(48):
            repo.insert_metrics(now - (48 - h) * 3600, [("disk.used_bytes", "/s", 50.0 + (h % 2))])
        fc = forecast_storage(repo, "/s", 100, 50, now=now)
        assert fc.days_to_full is None and fc.status == "stable"

    def test_trend(self, repo):
        now = time.time()
        for h in range(48):
            repo.insert_metrics(now - (48 - h) * 3600, [("mem.percent", "", 40.0 + h * 0.5)])
        trend = forecast_trend(repo, "mem.percent", now=now)
        assert trend is not None
        assert trend.slope_per_day == pytest.approx(12.0, rel=0.05)
        assert trend.projected_7d > trend.current


class TestMonitorService:
    def test_build_metric_rows(self):
        rows = build_metric_rows(make_snapshot())
        metrics = {(m, l) for m, l, _v in rows}
        assert ("cpu.percent", "") in metrics
        assert ("disk.used_bytes", "/tank") in metrics
        assert ("net.rx_bps", "_total") in metrics
        assert ("container.cpu", "plex") in metrics
        assert ("gpu.util", "0:NVIDIA GeForce RTX 3060") in metrics
        assert not any(l == "docker0" and m == "net.rx_bps" for m, l, _ in rows if l == "lo")

    def test_collect_records_history_and_energy(self, cfg):
        cfg.storage.sample_interval = 1.0
        service = MonitorService(cfg, mode="always")
        try:
            first = service.collect()
            time.sleep(1.1)
            second = service.collect()
            assert first.recording and second.recording
            assert second.power.wall_watts > 0
            counts = service.repo.row_counts()
            assert counts["metrics_raw"] > 10
            assert counts["energy_hourly"] == 1
            assert service.repo.last_heartbeat("daemon") > 0
            kinds = {e.kind for e in service.repo.events()}
            assert "daemon_started" in kinds
            assert second.cost.today_kwh > 0
        finally:
            service.close()

    def test_auto_mode_defers_to_live_daemon(self, cfg):
        daemon = MonitorService(cfg, mode="always")
        daemon.collect()
        tui = MonitorService(cfg, mode="auto")
        try:
            assert tui.recording is False
            snap = tui.collect()
            assert snap.recording is False
        finally:
            tui.close()
            daemon.close()

    def test_auto_mode_records_without_daemon(self, cfg):
        tui = MonitorService(cfg, mode="auto")
        try:
            assert tui.recording is True
        finally:
            tui.close()

    def test_never_mode_has_no_storage(self, cfg):
        service = MonitorService(cfg, mode="never")
        try:
            assert service.repo is None
            snap = service.collect()
            assert snap.recording is False
        finally:
            service.close()

    def test_unwritable_db_degrades_gracefully(self, cfg, tmp_path):
        blocker = tmp_path / "file"
        blocker.write_text("x")
        cfg.storage.db_path = str(blocker / "sub" / "db.sqlite")
        service = MonitorService(cfg, mode="always")
        try:
            assert service.repo is None and "History disabled" in service.storage_error
            assert service.collect().ts > 0
        finally:
            service.close()

    def test_apply_config_updates_engines(self, cfg):
        service = MonitorService(cfg, mode="never")
        try:
            new = copy_config(cfg)
            new.cost.rate_per_kwh = 0.5
            new.power.extra_watts = 25.0
            service.apply_config(new)
            snap = service.collect()
            assert snap.cost.rate_per_kwh == 0.5
            assert any(c.name.startswith("Extra") for c in snap.power.components)
        finally:
            service.close()

    def test_container_events(self, cfg):
        service = MonitorService(cfg, mode="always")
        try:
            s1 = make_snapshot()
            service._container_events(s1)
            s2 = make_snapshot()
            s2.containers[1].restart_count = 4
            s2.containers[0].state = "exited"
            service._container_events(s2)
            kinds = [e.kind for e in service.repo.events()]
            assert "container_restart" in kinds and "container_state" in kinds
        finally:
            service.close()


class TestDaemon:
    def test_runs_cycles_and_stops(self, cfg):
        cfg.storage.sample_interval = 2.0
        stop = threading.Event()
        assert run_daemon(cfg, stop=stop, max_cycles=2) == 0
        from observatory.storage import Database, Repository
        db = Database(cfg.resolved_db_path())
        try:
            repo = Repository(db)
            kinds = {e.kind for e in repo.events()}
            assert {"daemon_started", "daemon_stopped"} <= kinds
            assert repo.row_counts()["metrics_raw"] > 0
        finally:
            db.close()

    def test_stop_event_ends_loop(self, cfg):
        stop = threading.Event()
        stop.set()
        assert run_daemon(cfg, stop=stop) == 0

    def test_reloads_config_when_file_changes(self, cfg, tmp_path):
        from observatory.config import load_config, save_config
        from observatory.storage import Database, Repository

        path = tmp_path / "daemon.toml"
        cfg.storage.sample_interval = 2.0
        save_config(cfg, path)
        loaded = load_config(path)
        stop = threading.Event()
        thread = threading.Thread(target=run_daemon, args=(loaded,),
                                  kwargs={"stop": stop, "config_path": str(path)}, daemon=True)
        thread.start()
        time.sleep(1.0)
        loaded.cost.rate_per_kwh = 0.42
        save_config(loaded, path)
        import os
        os.utime(path, (time.time() + 5, time.time() + 5))
        time.sleep(3.5)
        stop.set()
        thread.join(timeout=10)
        db = Database(cfg.resolved_db_path())
        try:
            assert "config_changed" in {e.kind for e in Repository(db).events()}
        finally:
            db.close()

    def test_shared_directory_keeps_files_group_writable(self, tmp_path):
        import os
        import stat
        from observatory.storage import Database

        shared = tmp_path / "shared"
        shared.mkdir()
        shared.chmod(0o2775)
        old = os.umask(0o022)
        try:
            db = Database(shared / "o.db")
            db.execute("CREATE TABLE IF NOT EXISTS t(x)")
            db.execute("INSERT INTO t VALUES(1)")
            mode = (shared / "o.db").stat().st_mode
            assert mode & stat.S_IWGRP
            db.close()
        finally:
            os.umask(old)
