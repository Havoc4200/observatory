import time

import pytest

from observatory.config import CostConfig
from observatory.engines.cost import CostEngine, days_in_month, hourly_cost
from observatory.storage.repository import local_midnight, local_month_start


def test_hourly_cost():
    assert hourly_cost(250, 0.20) == pytest.approx(0.05)
    assert hourly_cost(-5, 0.20) == 0.0


def test_without_history_uses_current_draw():
    engine = CostEngine(CostConfig(rate_per_kwh=0.10))
    now = time.time()
    snap = engine.compute(100.0, now)
    assert snap.hourly_cost == pytest.approx(0.01)
    assert snap.today_cost == 0.0
    assert snap.projected_daily_kwh == pytest.approx(2.4)
    hours = days_in_month(now) * 24
    assert snap.monthly_kwh_estimate == pytest.approx(hours * 0.1)
    assert snap.monthly_estimate == pytest.approx(hours * 0.1 * 0.10)
    assert snap.annual_estimate == pytest.approx(2.4 * 365.25 * 0.10)


def test_with_history_today_and_month(repo):
    now = local_midnight() + 10 * 3600  # 10:00 today
    # 8 hours of 150 W today, priced at the old rate of 0.20
    for h in range(2, 10):
        repo.add_energy(local_midnight() + h * 3600 + 1, 150.0, 3600, 0.20)
    engine = CostEngine(CostConfig(rate_per_kwh=0.30), repo)
    snap = engine.compute(150.0, now)
    assert snap.today_kwh == pytest.approx(1.2)
    assert snap.today_cost == pytest.approx(1.2 * 0.20)  # recorded at the old rate
    assert snap.average_watts == pytest.approx(150.0)
    covered = 8
    expected_month_kwh = 1.2 + (days_in_month(now) * 24 - covered) * 0.15
    assert snap.monthly_kwh_estimate == pytest.approx(expected_month_kwh)
    assert snap.monthly_estimate == pytest.approx(1.2 * 0.20 + (days_in_month(now) * 24 - covered) * 0.15 * 0.30)


def test_fixed_daily_charge_is_prorated(repo):
    now = local_midnight() + 12 * 3600
    engine = CostEngine(CostConfig(rate_per_kwh=0.0, fixed_daily_charge=1.0), repo)
    snap = engine.compute(0.0, now)
    assert snap.today_cost == pytest.approx(0.5, abs=0.05)
    assert snap.monthly_estimate == pytest.approx(days_in_month(now))
    assert snap.annual_estimate == pytest.approx(365.25)
    assert snap.month_to_date_cost == pytest.approx((now - local_month_start(now)) / 86400, abs=0.05)
