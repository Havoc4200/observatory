import time

import pytest

from observatory.config import AlertConfig
from observatory.engines.anomaly import (
    AlertManager, AnomalyEngine, CpuSpikeDetector, DiskActivityDetector, Finding, MemoryLeakDetector,
    NetworkSpikeDetector, ThermalDetector, TimeWindow,
)
from observatory.engines.health import compute_health
from observatory.models import CpuStats, DiskIO, MemoryStats, NetInterface, ProcessInfo, TempReading
from tests.conftest import make_alert, make_snapshot


def snap_at(ts, **kw):
    return make_snapshot(ts=ts, **kw)


class TestTimeWindow:
    def test_trims_by_age_and_spacing(self):
        w = TimeWindow(max_age=10, min_spacing=2)
        for t in range(0, 30):
            w.add(float(t), float(t))
        assert all(v >= 18 for v in w.values())  # last kept sample is t=28; cutoff 28 - 10
        assert all(b - a >= 2 for a, b in zip(w.values(), w.values()[1:]))
        assert w.value_at_or_before(25) in (24.0, 25.0)


class TestCpuSpike:
    def test_absolute_threshold_needs_sustain(self):
        det = CpuSpikeDetector(AlertConfig(cpu_spike_percent=90, cpu_spike_samples=3))
        t = 1000.0
        results = []
        for i in range(4):
            results.append(det.check(snap_at(t + i * 2, cpu=CpuStats(percent=97))))
        assert results[0] == [] and results[1] == []
        assert results[2][0].kind == "cpu_spike"
        assert "plex" in results[2][0].message  # names the top process

    def test_relative_spike_after_warmup(self):
        det = CpuSpikeDetector(AlertConfig(cpu_spike_percent=99, cpu_spike_samples=2))
        t = 0.0
        for i in range(40):
            assert det.check(snap_at(t + i * 2, cpu=CpuStats(percent=5 + (i % 3)))) == []
        det.check(snap_at(100, cpu=CpuStats(percent=70)))
        found = det.check(snap_at(102, cpu=CpuStats(percent=72)))
        assert found and "baseline" in found[0].message

    def test_normal_load_never_fires(self):
        det = CpuSpikeDetector(AlertConfig())
        for i in range(100):
            assert det.check(snap_at(i * 2.0, cpu=CpuStats(percent=40 + (i % 10)))) == []


class TestMemoryLeak:
    def test_detects_monotonic_growth(self):
        cfg = AlertConfig(memory_leak_window_minutes=10, memory_leak_min_mb=50)
        det = MemoryLeakDetector(cfg)
        found = []
        start = 10_000.0
        for i in range(0, 700, 10):  # ~11.6 minutes, +1 MB every 10 s → ~70 MB
            leaky = ProcessInfo(4242, "leaky", rss=200 * 1024**2 + i * 1024**2 // 10 * 1, create_time=1.0)
            steady = ProcessInfo(5000, "steady", rss=300 * 1024**2 + (i % 30) * 1024, create_time=2.0)
            found = det.check(snap_at(start + i, processes=[leaky, steady],
                                      memory=MemoryStats(total=16 * 1024**3, used=4 * 1024**3, percent=25)))
        subjects = [f.subject for f in found]
        assert "leaky (PID 4242)" in subjects
        assert not any("steady" in s for s in subjects)

    def test_no_alert_before_window_filled(self):
        det = MemoryLeakDetector(AlertConfig(memory_leak_window_minutes=30))
        for i in range(0, 600, 10):
            p = ProcessInfo(1, "x", rss=10**8 + i * 10**6, create_time=1.0)
            assert det.check(snap_at(float(i), processes=[p])) == []


class TestDiskActivity:
    def test_sustained_busy(self):
        det = DiskActivityDetector(AlertConfig(disk_util_percent=90, disk_busy_samples=3))
        out = []
        for i in range(3):
            out = det.check(snap_at(i * 2.0, disk_io=[DiskIO("sda", read_bps=1e8, util_percent=99)]))
        assert out and out[0].subject == "sda" and out[0].kind == "disk_activity"

    def test_throughput_anomaly(self):
        det = DiskActivityDetector(AlertConfig(disk_util_percent=100, disk_busy_samples=99))
        for i in range(30):
            det.check(snap_at(i * 2.0, disk_io=[DiskIO("nvme0n1", read_bps=1e6, util_percent=1)]))
        out = []
        for i in range(30, 33):
            out = det.check(snap_at(i * 2.0, disk_io=[DiskIO("nvme0n1", read_bps=6e8, util_percent=40)]))
        assert out and "Unusual I/O" in out[0].message


class TestNetworkSpike:
    def test_spike_vs_baseline(self):
        det = NetworkSpikeDetector(AlertConfig(network_spike_mbps=10, network_spike_z=6))
        for i in range(30):
            det.check(snap_at(i * 2.0, net=[NetInterface("eth0", True, 0, rx_bps=1e5 + i * 100)]))
        det.check(snap_at(100, net=[NetInterface("eth0", True, 0, rx_bps=8e7)]))
        out = det.check(snap_at(102, net=[NetInterface("eth0", True, 0, rx_bps=8e7)]))
        assert out and out[0].subject == "eth0"

    def test_virtual_interfaces_ignored_and_saturation(self):
        det = NetworkSpikeDetector(AlertConfig())
        for i in range(5):
            out = det.check(snap_at(i * 2.0, net=[NetInterface("veth1", True, 0, rx_bps=1e9, virtual=True),
                                                  NetInterface("eth0", True, 100, rx_bps=12.4e6)]))
        assert [f.subject for f in out] == ["eth0"]
        assert "link capacity" in out[0].message


class TestThermal:
    def test_warning_and_critical(self):
        det = ThermalDetector(AlertConfig(temp_warning_c=80, temp_critical_c=95))
        hot = [TempReading("coretemp", "Package id 0", 88.0, kind="cpu")]
        det.check(snap_at(0, temps=hot))
        out = det.check(snap_at(2, temps=hot))
        assert out[0].severity == "warning"
        cooked = [TempReading("coretemp", "Package id 0", 99.0, critical=100.0, kind="cpu")]
        out = det.check(snap_at(4, temps=cooked))
        assert out[0].severity == "critical"

    def test_drive_threshold_and_rapid_rise(self):
        det = ThermalDetector(AlertConfig(drive_temp_warning_c=50, temp_rise_c=15))
        det.check(snap_at(0, temps=[TempReading("drivetemp", "", 52.0, kind="drive")]))
        out = det.check(snap_at(2, temps=[TempReading("drivetemp", "", 52.0, kind="drive")]))
        assert out and out[0].kind == "thermal"
        det2 = ThermalDetector(AlertConfig())
        det2.check(snap_at(0, temps=[TempReading("k10temp", "Tctl", 40.0, kind="cpu")]))
        out = det2.check(snap_at(70, temps=[TempReading("k10temp", "Tctl", 60.0, kind="cpu")]))
        assert out and "rose" in out[0].message


class TestAlertManager:
    def finding(self, severity="warning", msg="m"):
        return Finding("cpu_spike", "cpu", severity, msg, 99.0)

    def test_fire_hysteresis_resolve_and_cooldown(self, repo):
        mgr = AlertManager(AlertConfig(cooldown_minutes=10), repo)
        active, fired, resolved = mgr.process([self.finding()], 0)
        assert len(fired) == 1 and fired[0].id is not None
        mgr.process([], 2)
        mgr.process([], 4)
        assert len(mgr.active) == 1  # not yet resolved
        active, fired, resolved = mgr.process([], 6)
        assert resolved and resolved[0].state == "resolved"
        assert repo.alerts(active_only=True) == []
        _, fired, _ = mgr.process([self.finding()], 60)  # within cool-down
        assert fired == []
        _, fired, _ = mgr.process([self.finding()], 6 + 601)
        assert len(fired) == 1
        kinds = [e.kind for e in repo.events()]
        assert "alert_fired" in kinds and "alert_resolved" in kinds

    def test_escalation_refires(self, repo):
        mgr = AlertManager(AlertConfig(), repo)
        mgr.process([self.finding("warning")], 0)
        _, fired, _ = mgr.process([self.finding("critical", "worse")], 2)
        assert fired and fired[0].severity == "critical"
        assert repo.alerts()[0].severity == "critical"

    def test_engine_disabled_produces_nothing(self):
        engine = AnomalyEngine(AlertConfig(enabled=False))
        active, fired, _ = engine.evaluate(make_snapshot(cpu=CpuStats(percent=100)))
        assert active == [] and fired == []

    def test_engine_end_to_end(self):
        engine = AnomalyEngine(AlertConfig(cpu_spike_samples=2))
        fired_total = []
        for i in range(3):
            _, fired, _ = engine.evaluate(make_snapshot(ts=1000 + i * 2, cpu=CpuStats(percent=99)))
            fired_total += fired
        assert [a.kind for a in fired_total] == ["cpu_spike"]


class TestHealth:
    def test_healthy_system(self):
        health = compute_health(make_snapshot(), AlertConfig())
        assert health.score >= 90
        assert health.grade == "Excellent"

    def test_penalties_accumulate_and_cap(self):
        from observatory.models import DiskUsage

        snap = make_snapshot(
            cpu=CpuStats(percent=97, iowait=30),
            memory=MemoryStats(total=100, used=96, available=4, percent=96),
            disks=[DiskUsage(f"/dev/sd{c}", f"/m{c}", "ext4", 100, 97, 3, 97) for c in "abcd"],
            temps=[TempReading("coretemp", "Package id 0", 99, kind="cpu")],
            alerts=[make_alert(severity="critical"), make_alert(kind="thermal", subject="x")],
        )
        health = compute_health(snap, AlertConfig())
        assert health.score < 25
        assert any("memory" in r for r in health.reasons)
        assert sum(1 for r in health.reasons if "full" in r) == 4
        assert health.grade in {"Poor", "Critical"}

    def test_score_bounds(self):
        snap = make_snapshot(cpu=CpuStats(percent=100), memory=MemoryStats(total=1, used=1, percent=100))
        assert 0 <= compute_health(snap, AlertConfig()).score <= 100
