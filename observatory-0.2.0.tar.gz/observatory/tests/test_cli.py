import json

from observatory.cli import build_parser, main


def test_parser_accepts_global_options_after_subcommand():
    args = build_parser().parse_args(["status", "--db", "/tmp/x.db", "--json"])
    assert args.db == "/tmp/x.db" and args.json and args.command == "status"
    args = build_parser().parse_args(["--db", "/tmp/y.db", "db", "stats"])
    assert args.db == "/tmp/y.db" and args.action == "stats"
    args = build_parser().parse_args(["--tab", "docker"])
    assert args.tab == "docker" and args.command is None


def test_init_config(tmp_path, capsys):
    target = tmp_path / "c.toml"
    assert main(["init-config", "--path", str(target)]) == 0
    assert "[cost]" in target.read_text()
    assert main(["init-config", "--path", str(target)]) == 1
    assert main(["init-config", "--path", str(target), "--force"]) == 0


def test_status_json(tmp_path, capsys):
    assert main(["status", "--json"]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["power"]["wall_watts"] > 0
    assert 0 <= payload["health"]["score"] <= 100


def test_status_text_and_hardware(capsys):
    assert main(["status"]) == 0
    out = capsys.readouterr().out
    assert "Health" in out and "Power" in out
    assert main(["hardware"]) == 0
    out = capsys.readouterr().out
    assert "Detected hardware" in out and "Wall" in out


def test_daemon_once_and_db_commands(tmp_path, capsys):
    db = str(tmp_path / "cli.db")
    assert main(["daemon", "--once", "--db", db]) == 0
    assert main(["db", "stats", "--db", db]) == 0
    assert "metrics_raw" in capsys.readouterr().out
    assert main(["db", "rollup", "--db", db]) == 0
    assert main(["db", "prune", "--db", db]) == 0
    assert main(["db", "vacuum", "--db", db]) == 0
    assert main(["db", "stats", "--db", str(tmp_path / "missing.db")]) == 1
