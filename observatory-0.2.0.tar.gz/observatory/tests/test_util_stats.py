import pytest

from observatory.engines.stats import (
    downsample, linear_regression, mad, mann_kendall, median, robust_z, theil_sen, theil_sen_slope,
)
from observatory.util.format import (
    bar, fmt_bits, fmt_bytes, fmt_duration, fmt_money, fmt_percent, fmt_rate, fmt_temp, fmt_watts, truncate,
)
from observatory.util.rates import RateTracker


class TestFormat:
    def test_bytes(self):
        assert fmt_bytes(0) == "0 B"
        assert fmt_bytes(1536) == "1.5 KiB"
        assert fmt_bytes(5 * 1024**3) == "5.0 GiB"
        assert fmt_bytes(None) == "—"
        assert fmt_bytes(-2048) == "-2.0 KiB"

    def test_rates_and_bits(self):
        assert fmt_rate(999) == "999 B/s"
        assert fmt_rate(1_500_000) == "1.5 MB/s"
        assert fmt_bits(125_000) == "1.0 Mbps"

    def test_duration(self):
        assert fmt_duration(42) == "42s"
        assert fmt_duration(3700) == "1h 1m"
        assert fmt_duration(90061) == "1d 1h 1m"

    def test_money_watts_temp_percent(self):
        assert fmt_money(1234.5, "$") == "$1,234.50"
        assert fmt_money(-3, "€") == "-€3.00"
        assert fmt_watts(87.4) == "87 W"
        assert fmt_watts(1500) == "1.50 kW"
        assert fmt_temp(55.6) == "56°C"
        assert fmt_percent(None) == "—"

    def test_bar_and_truncate(self):
        assert bar(50, 10) == "█████░░░░░"
        assert bar(150, 4) == "████"
        assert truncate("abcdef", 4) == "abc…"
        assert truncate("ab", 4) == "ab"


class TestRates:
    def test_rate_from_counter(self):
        tracker = RateTracker()
        assert tracker.rate("x", 100, now=0.0) == 0.0
        assert tracker.rate("x", 300, now=2.0) == 100.0

    def test_counter_reset_yields_zero(self):
        tracker = RateTracker()
        tracker.rate("x", 1000, now=0)
        assert tracker.rate("x", 10, now=1) == 0.0
        assert tracker.rate("x", 20, now=2) == 10.0

    def test_forget_missing(self):
        tracker = RateTracker()
        tracker.rate("a", 1, now=0)
        tracker.rate("b", 1, now=0)
        tracker.forget_missing({"a"})
        assert "a" in tracker and "b" not in tracker


class TestStats:
    def test_median_and_mad(self):
        assert median([3, 1, 2]) == 2
        assert median([4, 1, 2, 3]) == 2.5
        assert mad([1, 2, 3, 4, 100]) == 1
        with pytest.raises(ValueError):
            median([])

    def test_robust_z_ignores_outliers(self):
        baseline = [10, 11, 9, 10, 12, 10, 11, 9, 500]
        assert robust_z(10, baseline) == pytest.approx(0, abs=0.1)
        assert robust_z(40, baseline) > 15

    def test_robust_z_floor_prevents_explosion(self):
        assert robust_z(11, [10] * 20, floor=2.0) == pytest.approx(0.5)

    def test_theil_sen_is_robust(self):
        xs = list(range(20))
        ys = [2 * x + 1 for x in xs]
        ys[5] = 1000  # outlier
        slope, intercept = theil_sen(xs, ys)
        assert slope == pytest.approx(2.0)
        assert intercept == pytest.approx(1.0)
        assert theil_sen_slope([1, 1], [1, 2]) == 0.0

    def test_mann_kendall(self):
        tau, z = mann_kendall(list(range(30)))
        assert tau == pytest.approx(1.0)
        assert z > 2.58
        tau, z = mann_kendall([5, 1, 4, 2, 3, 3, 1, 5, 2, 4])
        assert abs(tau) < 0.3

    def test_linear_regression(self):
        slope, intercept, r2 = linear_regression([0, 1, 2, 3], [1, 3, 5, 7])
        assert (slope, intercept, r2) == pytest.approx((2, 1, 1))

    def test_downsample(self):
        pts = [(i, i) for i in range(100)]
        out = downsample(pts, 10)
        assert len(out) == 10 and out[0] == (0, 0) and out[-1] == (99, 99)
