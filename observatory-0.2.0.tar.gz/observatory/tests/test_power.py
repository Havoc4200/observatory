from pathlib import Path

import pytest

from observatory.config import PowerConfig
from observatory.engines.hardware import (
    ComponentProfile, GpuDevice, HardwareProfile, detect_chassis, estimate_dimms, find_rapl_domains,
    heuristic_cpu_profile, is_integrated, match_cpu_profile, match_gpu_profile,
)
from observatory.engines.power import PowerEngine, PowerInputs, RaplReader, energy_projection
from observatory.models import DiskIO, GpuStats, StorageDevice
from observatory.util.pci import PciDevice


def hw(**kw) -> HardwareProfile:
    base = dict(
        cpu_model="Test CPU", cpu_sockets=1, cpu_cores=4, cpu_threads=8,
        cpu_profile=ComponentProfile(10.0, 110.0), ram_bytes=32 * 1024**3, dimm_count=2,
        gpus=[], storage=[], chassis="desktop",
    )
    base.update(kw)
    return HardwareProfile(**base)


class TestProfiles:
    @pytest.mark.parametrize("model,idle,peak", [
        ("Intel(R) N100", 2.0, 12.0),
        ("12th Gen Intel(R) Core(TM) i5-12500", 6.0, 117.0),
        ("AMD Ryzen 7 5700G with Radeon Graphics", 8.0, 88.0),
        ("Intel(R) Xeon(R) CPU E5-2690 v4 @ 2.60GHz", 25.0, 135.0),
        ("Raspberry Pi 4 Model B Rev 1.4", 2.7, 6.4),
        ("Intel(R) Core(TM) i7-8700K CPU @ 3.70GHz", 7.0, 160.0),
        ("AMD Ryzen 9 7950X 16-Core Processor", 25.0, 230.0),
        ("Intel(R) Core(TM) i5-8500T CPU @ 2.10GHz", 4.0, 35.0),
    ])
    def test_cpu_matches(self, model, idle, peak):
        p = match_cpu_profile(model)
        assert (p.idle_w, p.max_w) == (idle, peak)
        assert p.source == "profile"

    def test_board_flag_for_sbc(self):
        assert match_cpu_profile("Raspberry Pi 5 Model B Rev 1.0").board is True

    def test_unknown_cpu_uses_heuristic(self):
        p = match_cpu_profile("Mystery Processor 9000")
        assert p.source == "heuristic"
        assert p.max_w > p.idle_w > 0

    def test_heuristic_mobile_parts(self):
        assert heuristic_cpu_profile("FooCorp Z-7840U").max_w == 25.0
        assert heuristic_cpu_profile("FooCorp Z-7840HS").max_w == 60.0

    @pytest.mark.parametrize("name,peak", [
        ("NVIDIA GeForce RTX 3060", 170.0),
        ("NVIDIA Quadro P2000", 75.0),
        ("Intel Arc A380", 75.0),
        ("AMD Radeon RX 6600", 132.0),
        ("NVIDIA Some Future GPU", 150.0),
    ])
    def test_gpu_matches(self, name, peak):
        assert match_gpu_profile(name).max_w == peak


class TestDetection:
    @pytest.mark.parametrize("gb,expected", [(4, 1), (8, 1), (16, 2), (32, 2), (64, 4), (128, 4), (512, 16)])
    def test_estimate_dimms(self, gb, expected):
        assert estimate_dimms(gb) == expected

    def test_chassis_from_dmi(self, tmp_path):
        (tmp_path / "chassis_type").write_text("17\n")
        assert detect_chassis(tmp_path) == "server"
        (tmp_path / "chassis_type").write_text("35\n")
        assert detect_chassis(tmp_path) == "mini"
        assert detect_chassis(tmp_path / "missing") == "unknown"

    def test_find_rapl_domains(self, tmp_path):
        pkg = tmp_path / "intel-rapl:0"
        pkg.mkdir()
        (pkg / "name").write_text("package-0")
        (pkg / "energy_uj").write_text("12345")
        dram = tmp_path / "intel-rapl:0:2"
        dram.mkdir()
        (dram / "name").write_text("dram")
        (dram / "energy_uj").write_text("10")
        core = tmp_path / "intel-rapl:0:0"
        core.mkdir()
        (core / "name").write_text("core")
        (core / "energy_uj").write_text("10")
        packages, drams = find_rapl_domains(tmp_path)
        assert packages == [pkg]
        assert drams == [dram]

    def test_integrated_gpu_classification(self):
        assert is_integrated(PciDevice("0000:00:02.0", "8086", "4680", "030000"), "Intel UHD Graphics 770", "")
        assert not is_integrated(PciDevice("0000:03:00.0", "8086", "56a5", "030000"), "Intel Arc A380", "")
        assert not is_integrated(PciDevice("0000:01:00.0", "10de", "2504", "030000"), "NVIDIA RTX 3060", "")
        assert is_integrated(PciDevice("0000:07:00.0", "1002", "1638", "030000"),
                             "AMD Radeon Vega Series / Radeon Vega Mobile Series", "")
        assert is_integrated(PciDevice("0000:00:0f.0", "1a03", "2000", "030000"), "ASPEED Graphics Family", "")


class TestRapl:
    def test_watts_from_counter_and_wrap(self, tmp_path, monkeypatch):
        zone = tmp_path / "intel-rapl:0"
        zone.mkdir()
        (zone / "max_energy_range_uj").write_text("1000000000")
        (zone / "energy_uj").write_text("999000000")
        clock = iter([100.0, 102.0])
        monkeypatch.setattr("observatory.engines.power.time.monotonic", lambda: next(clock))
        reader = RaplReader([zone])
        assert reader.read_watts() is None  # first read primes
        (zone / "energy_uj").write_text("19000000")  # wrapped: +20 J over 2 s
        assert reader.read_watts() == pytest.approx(10.0)

    def test_no_zones(self):
        assert RaplReader([]).read_watts() is None


class TestPowerEngine:
    def cfg(self, **kw) -> PowerConfig:
        c = PowerConfig(use_rapl=False)
        for k, v in kw.items():
            setattr(c, k, v)
        return c

    def test_cpu_model_curve(self):
        engine = PowerEngine(hw(), self.cfg())
        assert engine.cpu_watts(0).watts == pytest.approx(10.0)
        assert engine.cpu_watts(100).watts == pytest.approx(110.0)
        mid = engine.cpu_watts(50).watts
        assert 10 + 100 * 0.5 < mid < 110  # sub-linear exponent lifts the midpoint

    def test_multi_socket_scales(self):
        engine = PowerEngine(hw(cpu_sockets=2), self.cfg())
        assert engine.cpu_watts(0).watts == pytest.approx(20.0)

    def test_memory_and_board(self):
        engine = PowerEngine(hw(dimm_count=4), self.cfg())
        assert engine.memory_watts(0).watts == pytest.approx(6.0)
        assert engine.memory_watts(1).watts == pytest.approx(12.0)
        sbc = PowerEngine(hw(cpu_profile=ComponentProfile(2.7, 6.4, board=True), chassis="board"), self.cfg())
        assert sbc.memory_watts(1).watts == 0.0
        assert sbc.platform_watts().watts == 0.0

    def test_gpu_measured_preferred_over_model(self):
        dev = GpuDevice("NVIDIA GeForce RTX 3060 Lite Hash Rate", "NVIDIA", True, "", match_gpu_profile("RTX 3060"))
        engine = PowerEngine(hw(gpus=[dev]), self.cfg())
        measured = engine.gpu_watts([GpuStats(0, "NVIDIA GeForce RTX 3060", "NVIDIA", util_percent=50, power_w=88.0)])
        assert len(measured) == 1 and measured[0].method == "measured" and measured[0].watts == 88.0
        modeled = PowerEngine(hw(gpus=[dev]), self.cfg(use_gpu_sensors=False)).gpu_watts(
            [GpuStats(0, "NVIDIA GeForce RTX 3060", "NVIDIA", util_percent=50, power_w=88.0)])
        assert modeled[0].method == "modeled"
        assert modeled[0].watts == pytest.approx(12 + (170 - 12) * 0.5)

    def test_storage_model_and_spindown(self):
        devices = [StorageDevice("sda", kind="hdd"), StorageDevice("sdb", kind="hdd"),
                   StorageDevice("nvme0n1", kind="nvme")]
        engine = PowerEngine(hw(storage=devices), self.cfg(spun_down_drives=["sdb"]))
        idle = engine.storage_watts([])
        assert idle.watts == pytest.approx(5.0 + 0.8 + 1.5)
        busy = engine.storage_watts([DiskIO("sda", util_percent=100), DiskIO("sdb", util_percent=50)])
        assert busy.watts == pytest.approx(8.0 + 6.5 + 1.5)

    def test_platform_configured_vs_auto(self):
        assert PowerEngine(hw(chassis="server"), self.cfg()).platform_watts().watts == 45.0
        configured = PowerEngine(hw(), self.cfg(platform_watts=12.0)).platform_watts()
        assert configured.watts == 12.0 and configured.method == "configured"

    def test_estimate_applies_psu_efficiency_and_extra(self):
        engine = PowerEngine(hw(), self.cfg(psu_efficiency=0.80, extra_watts=10.0, platform_watts=20.0))
        est = engine.estimate(PowerInputs(cpu_percent=0, memory_percent=0))
        dc = 10.0 + 3.0 + 0.0 + 20.0
        assert est.dc_watts == pytest.approx(dc)
        assert est.wall_watts == pytest.approx(dc / 0.80 + 10.0, abs=0.1)
        assert est.low_watts < est.wall_watts < est.high_watts
        assert est.method == "modeled"
        assert any(c.name.startswith("Extra") for c in est.components)

    def test_energy_projection(self):
        proj = energy_projection(100.0)
        assert proj["daily_kwh"] == pytest.approx(2.4)
        assert proj["annual_kwh"] == pytest.approx(876.6)
