"""Shared fixtures for the Observatory test suite."""

from __future__ import annotations

import time
from pathlib import Path

import pytest

from observatory.config import Config
from observatory.models import (
    Alert, ContainerInfo, CpuStats, DiskIO, DiskUsage, GpuStats, LoadStats, MemoryStats, NetInterface,
    ProcessInfo, Snapshot, StorageDevice, SwapStats, TempReading,
)
from observatory.storage.database import Database
from observatory.storage.repository import Repository


@pytest.fixture(autouse=True)
def isolated_home(tmp_path, monkeypatch):
    """Keep every test away from the real ~/.config, ~/.local and /etc."""
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path / "xdg-config"))
    monkeypatch.setenv("XDG_DATA_HOME", str(tmp_path / "xdg-data"))
    monkeypatch.setenv("XDG_STATE_HOME", str(tmp_path / "xdg-state"))
    monkeypatch.delenv("OBSERVATORY_CONFIG", raising=False)
    monkeypatch.setattr("observatory.config.SYSTEM_CONFIG_PATH", tmp_path / "etc" / "config.toml")
    monkeypatch.setattr("observatory.config.SYSTEM_DB_PATH", tmp_path / "var" / "observatory.db")
    yield
    # CLI tests reconfigure logging with handlers bound to captured streams; drop them.
    import logging

    root = logging.getLogger()
    for handler in list(root.handlers):
        root.removeHandler(handler)


@pytest.fixture
def cfg(tmp_path) -> Config:
    c = Config()
    c.storage.db_path = str(tmp_path / "test.db")
    c.docker.enabled = False
    return c


@pytest.fixture
def db(tmp_path) -> Database:
    database = Database(tmp_path / "repo.db")
    yield database
    database.close()


@pytest.fixture
def repo(db) -> Repository:
    return Repository(db)


def make_snapshot(**overrides) -> Snapshot:
    """A realistic snapshot with every section populated."""
    now = overrides.pop("ts", time.time())
    snap = Snapshot(
        ts=now,
        hostname="testhost",
        uptime_s=86400 * 3 + 3600,
        cpu=CpuStats(percent=23.5, per_core=[20.0, 30.0, 25.0, 19.0], user=15, system=6, iowait=1.5,
                     freq_mhz=3400, freq_max_mhz=4600, cores_logical=4, cores_physical=4, model="Test CPU"),
        memory=MemoryStats(total=16 * 1024**3, used=6 * 1024**3, available=10 * 1024**3, percent=37.5),
        swap=SwapStats(total=2 * 1024**3, used=100 * 1024**2, percent=4.9),
        load=LoadStats(load1=0.8, load5=0.6, load15=0.5, cores=4),
        disks=[
            DiskUsage("/dev/nvme0n1p2", "/", "ext4", 500 * 10**9, 200 * 10**9, 300 * 10**9, 40.0),
            DiskUsage("tank", "/tank", "zfs", 8 * 10**12, 6 * 10**12, 2 * 10**12, 75.0),
        ],
        disk_io=[
            DiskIO("nvme0n1", read_bps=12e6, write_bps=3e6, read_iops=300, write_iops=80, util_percent=12.0),
            DiskIO("sda", read_bps=1e5, write_bps=2e5, read_iops=5, write_iops=9, util_percent=3.0),
        ],
        storage_devices=[
            StorageDevice("nvme0n1", "Samsung SSD 980", "nvme", 500 * 10**9),
            StorageDevice("sda", "WDC WD80EFAX", "hdd", 8 * 10**12, rotational=True),
        ],
        temps=[
            TempReading("coretemp", "Package id 0", 54.0, high=80.0, critical=100.0, kind="cpu"),
            TempReading("nvme", "Composite", 41.0, high=82.0, critical=85.0, kind="drive"),
        ],
        net=[
            NetInterface("eth0", True, 1000, ["192.168.1.10"], rx_bps=2.5e6, tx_bps=4e5,
                         rx_total=10**10, tx_total=10**9),
            NetInterface("docker0", True, 0, ["172.17.0.1"], rx_bps=1e3, tx_bps=1e3, virtual=True),
        ],
        gpus=[GpuStats(0, "NVIDIA GeForce RTX 3060", "NVIDIA", util_percent=35.0, mem_used=2 * 1024**3,
                       mem_total=12 * 1024**3, temp_c=58.0, power_w=62.0, power_limit_w=170.0)],
        processes=[
            ProcessInfo(1, "systemd", "root", 0.0, 0.1, 12 * 1024**2, 1, "sleeping", "/sbin/init", 1.0),
            ProcessInfo(1234, "plex", "plex", 45.0, 6.5, 1024**3, 30, "running", "/usr/lib/plexmediaserver/Plex Media Server", 2.0),
            ProcessInfo(2222, "postgres", "postgres", 3.0, 2.0, 300 * 1024**2, 8, "sleeping", "postgres: main", 3.0),
            ProcessInfo(3333, "kworker/0:1", "root", 0.0, 0.0, 0, 1, "idle", "[kworker/0:1]", 4.0),
        ],
        process_count=4,
        containers=[
            ContainerInfo("a" * 64, "plex", "plexinc/pms-docker", "running", "Up 2 hours (healthy)", "healthy",
                          cpu_percent=40.0, mem_usage=900 * 1024**2, mem_limit=4 * 1024**3, mem_percent=22.0,
                          net_rx_bps=1e5, net_tx_bps=5e6, restart_count=0, compose_project="media"),
            ContainerInfo("b" * 64, "sonarr", "lscr.io/linuxserver/sonarr", "running", "Up 2 hours", "",
                          cpu_percent=1.0, mem_usage=250 * 1024**2, restart_count=3, compose_project="media"),
            ContainerInfo("c" * 64, "old-job", "alpine", "exited", "Exited (1) 3 hours ago", ""),
        ],
        docker_available=True,
    )
    for key, value in overrides.items():
        setattr(snap, key, value)
    return snap


@pytest.fixture
def snapshot() -> Snapshot:
    return make_snapshot()


def make_alert(**kw) -> Alert:
    base = dict(kind="cpu_spike", severity="warning", subject="cpu", message="CPU at 97%", value=97.0,
                started_at=time.time() - 120)
    base.update(kw)
    return Alert(**base)


@pytest.fixture
def fake_sysfs(tmp_path) -> Path:
    root = tmp_path / "sys"
    root.mkdir()
    return root
