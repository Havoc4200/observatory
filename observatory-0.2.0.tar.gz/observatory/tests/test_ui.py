"""Headless UI tests using Textual's pilot."""

from __future__ import annotations

import pytest
from textual.widgets import DataTable, Input, Select

from observatory.config import load_config
from observatory.services.monitor import MonitorService
from observatory.ui.app import SECTIONS, ObservatoryApp
from observatory.ui.panes.analytics import bin_series
from observatory.ui.panes.processes import filter_processes, sort_processes
from observatory.ui.panes.settings import ALL_FIELDS, apply_fields
from observatory.ui.widgets import ConfirmScreen
from tests.conftest import make_alert, make_snapshot


def plain(renderable, width: int = 200) -> str:
    """Rich renderable → plain text, for assertions."""
    from rich.console import Console

    console = Console(width=width, record=True, file=open("/dev/null", "w"))
    console.print(renderable)
    return console.export_text()


@pytest.fixture
def service(cfg):
    svc = MonitorService(cfg, mode="always")
    snap = make_snapshot()
    snap.alerts = [make_alert(id=1), make_alert(kind="thermal", subject="coretemp", severity="critical", id=2)]
    from observatory.engines.insights import InsightInputs, generate_insights
    from observatory.engines.scores import compute_scores

    snap.scores = compute_scores(snap, cfg.alerts)
    snap.insights = generate_insights(InsightInputs(snap=snap, cfg=cfg, scores=snap.scores))
    svc.collect = lambda: snap  # type: ignore[method-assign]
    svc.kill_calls = []
    svc.docker_calls = []
    svc.kill = lambda pid, force=False: (svc.kill_calls.append((pid, force)) or (True, f"killed {pid}"))  # type: ignore
    svc.docker_action = lambda action, cid, name="": (svc.docker_calls.append((action, cid)) or (True, "ok"))  # type: ignore
    yield svc
    svc.close()


async def test_all_sections_render_via_letter_keys(service):
    app = ObservatoryApp(service)
    async with app.run_test(size=(180, 50)) as pilot:
        await pilot.pause(0.3)
        for sid, key, _title, _cls in SECTIONS:
            await pilot.press("comma" if key == "," else key.lower())
            await pilot.pause(0.25)
            assert app.switcher.current == sid, (key, sid)
            if sid in {"processes", "docker"}:
                assert isinstance(app.focused, DataTable)  # pane bindings work without clicking first
            # navigation keys must not be swallowed by pane bindings
            await pilot.press("h")
            await pilot.pause(0.1)
            assert app.switcher.current == "home"
        assert app.snapshot is not None


async def test_dashboard_renders_every_panel(service):
    from observatory.ui.dashboard.panels import DashPanel

    app = ObservatoryApp(service)
    async with app.run_test(size=(180, 50)) as pilot:
        await pilot.pause(0.6)
        panels = [p for p in app.query(DashPanel) if p.display]
        assert len(panels) >= 17   # 7 tiles + 10 panels (radar shown at 180 columns)
        for panel in panels:
            text = plain(panel.render())
            assert "panel error" not in text, (panel.id, text)
        assert "plex" in plain(app.query_one("#p-docker").render())
        health = plain(app.query_one("#p-health").render())
        assert any(w in health for w in ("EXCELLENT", "HEALTHY", "WARNING", "DEGRADED", "CRITICAL"))
        assert "Stability" in health
        assert "DO NEXT" in plain(app.query_one("#p-insights").render()) or True
        assert "/tank" in plain(app.query_one("#p-storage").render())


async def test_dashboard_fits_without_scrolling_at_160x45(service):
    app = ObservatoryApp(service)
    async with app.run_test(size=(160, 45)) as pilot:
        await pilot.pause(0.6)
        scroll = app.query_one("#home-scroll")
        assert scroll.max_scroll_y <= 1


async def test_dashboard_panel_click_opens_deep_dive(service):
    app = ObservatoryApp(service)
    async with app.run_test(size=(180, 50)) as pilot:
        await pilot.pause(0.5)
        await pilot.click("#p-storage")
        await pilot.pause(0.2)
        assert app.switcher.current == "storage"


def test_plan_layout():
    from observatory.ui.dashboard.home import MIN_A, MIN_B, MIN_C, MIN_D, plan_layout

    plan = plan_layout(160, 42)
    assert not plan["narrow"] and (plan["a"], plan["b"], plan["c"], plan["d"]) == (MIN_A, MIN_B, MIN_C, MIN_D)
    assert plan["radar"] is False and plan["heatmap"] is False
    tall = plan_layout(230, 60)
    assert tall["radar"] and tall["heatmap"]
    assert tall["a"] + tall["b"] + tall["c"] + tall["d"] == 60
    assert plan_layout(110, 40)["narrow"]


async def test_process_search_and_kill_confirmation(service):
    app = ObservatoryApp(service, initial_tab="processes")
    async with app.run_test(size=(160, 48)) as pilot:
        await pilot.pause(0.3)
        table = app.query_one("#proc-table", DataTable)
        assert table.row_count == 4
        search = app.query_one("#proc-search", Input)
        search.value = "plex"
        await pilot.pause(0.2)
        assert table.row_count == 1
        table.focus()
        await pilot.press("k")
        await pilot.pause(0.2)
        assert isinstance(app.screen, ConfirmScreen)
        await pilot.press("y")
        await pilot.pause(0.5)
        assert service.kill_calls == [(1234, False)]


async def test_process_filter_select(service):
    app = ObservatoryApp(service, initial_tab="processes")
    async with app.run_test(size=(160, 48)) as pilot:
        await pilot.pause(0.3)
        app.query_one("#proc-filter", Select).value = "nokernel"
        await pilot.pause(0.2)
        assert app.query_one("#proc-table", DataTable).row_count == 3


async def test_docker_restart_requires_confirmation(service):
    app = ObservatoryApp(service, initial_tab="docker")
    async with app.run_test(size=(160, 48)) as pilot:
        await pilot.pause(0.3)
        table = app.query_one("#docker-table", DataTable)
        assert table.row_count == 3
        table.focus()
        await pilot.press("r")
        await pilot.pause(0.2)
        assert isinstance(app.screen, ConfirmScreen)
        await pilot.press("n")
        await pilot.pause(0.2)
        assert service.docker_calls == []
        await pilot.press("r")
        await pilot.pause(0.2)
        await pilot.press("y")
        await pilot.pause(0.5)
        assert service.docker_calls == [("restart", "a" * 64)]


async def test_alerts_pane_lists_active(service):
    app = ObservatoryApp(service, initial_tab="alerts")
    async with app.run_test(size=(160, 48)) as pilot:
        await pilot.pause(0.5)
        assert app.query_one("#active-table", DataTable).row_count == 2


async def test_settings_save_writes_config(service, tmp_path):
    service.cfg.source_path = tmp_path / "saved.toml"
    app = ObservatoryApp(service, initial_tab="settings")
    async with app.run_test(size=(160, 48)) as pilot:
        await pilot.pause(0.3)
        rate = app.query_one("#set-cost-rate_per_kwh", Input)
        rate.value = "0.27"
        app.query_one("#pane-settings").action_save()
        await pilot.pause(0.3)
    saved = load_config(tmp_path / "saved.toml")
    assert saved.cost.rate_per_kwh == pytest.approx(0.27)
    assert service.cfg.cost.rate_per_kwh == pytest.approx(0.27)


async def test_pause_toggle(service):
    app = ObservatoryApp(service)
    async with app.run_test(size=(160, 48)) as pilot:
        await pilot.pause(0.2)
        await pilot.press("space")
        assert app.paused
        assert "PAUSED" in app.sub_title_text
        assert any("PAUSED" in c.plain for c in app.header._chips(app.snapshot))
        await pilot.press("space")
        assert not app.paused


def test_filter_and_sort_helpers():
    procs = make_snapshot().processes
    assert [p.pid for p in filter_processes(procs, "1234", "all", "root")] == [1234]
    assert [p.name for p in filter_processes(procs, "", "mine", "postgres")] == ["postgres"]
    assert [p.name for p in filter_processes(procs, "", "running", "x")] == ["plex"]
    assert sort_processes(procs, "mem")[0].name == "plex"
    assert sort_processes(procs, "pid")[0].pid == 1
    assert sort_processes(procs, "name")[0].name == "kworker/0:1"


def test_apply_fields_validation(cfg):
    values = {f.widget_id: "" for f in ALL_FIELDS if f.kind in {"str", "list"}}
    values["set-cost-rate_per_kwh"] = "abc"
    _new, errors = apply_fields(cfg, values)
    assert any("not a valid" in e for e in errors)
    new, errors = apply_fields(cfg, {"set-power-psu_efficiency": "1.4", "set-alerts-enabled": False})
    assert new.power.psu_efficiency == 0.99 and new.alerts.enabled is False
    assert errors and cfg.power.psu_efficiency == 0.87  # original untouched


def test_bin_series():
    out = bin_series([(95.0, 10.0), (99.0, 20.0)], 0, 100, 10)
    assert len(out) == 10 and out[-1] == 15.0 and out[0] == 0.0
