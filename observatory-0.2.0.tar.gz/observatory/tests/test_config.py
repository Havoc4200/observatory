from pathlib import Path

import pytest

from observatory.config import (
    Config, config_from_dict, load_config, save_config, user_config_path, _coerce,
)


def test_defaults_are_sane():
    cfg = Config()
    assert cfg.general.refresh_interval == 2.0
    assert cfg.cost.rate_per_kwh == 0.15
    assert 0.5 <= cfg.power.psu_efficiency <= 0.99
    assert cfg.validate() == []


def test_roundtrip_save_and_load(tmp_path):
    cfg = Config()
    cfg.cost.rate_per_kwh = 0.231
    cfg.cost.currency_symbol = "€"
    cfg.power.spun_down_drives = ["sdc", "sdd"]
    cfg.alerts.enabled = False
    path = save_config(cfg, tmp_path / "c.toml")
    loaded = load_config(path)
    assert loaded.cost.rate_per_kwh == pytest.approx(0.231)
    assert loaded.cost.currency_symbol == "€"
    assert loaded.power.spun_down_drives == ["sdc", "sdd"]
    assert loaded.alerts.enabled is False
    assert loaded.source_path == path


def test_unknown_keys_and_sections_are_ignored(caplog):
    cfg = config_from_dict({"cost": {"rate_per_kwh": 0.3, "bogus": 1}, "nope": {"x": 1}})
    assert cfg.cost.rate_per_kwh == 0.3
    assert "unknown key" in caplog.text
    assert "unknown section" in caplog.text


def test_type_coercion_and_bad_values():
    cfg = config_from_dict({
        "general": {"refresh_interval": "3"},
        "alerts": {"enabled": "no", "cpu_spike_samples": "5"},
        "power": {"psu_efficiency": "not-a-number", "spun_down_drives": "sdb, sdc"},
    })
    assert cfg.general.refresh_interval == 3.0
    assert cfg.alerts.enabled is False
    assert cfg.alerts.cpu_spike_samples == 5
    assert cfg.power.psu_efficiency == 0.87  # bad value keeps default
    assert cfg.power.spun_down_drives == ["sdb", "sdc"]


def test_coerce_rejects_bool_for_numbers():
    with pytest.raises(ValueError):
        _coerce(True, 1.0)
    with pytest.raises(ValueError):
        _coerce("maybe", True)


def test_validate_clamps_out_of_range():
    cfg = Config()
    cfg.power.psu_efficiency = 1.5
    cfg.general.refresh_interval = 0.01
    cfg.power.platform_watts = -5
    warnings = cfg.validate()
    assert cfg.power.psu_efficiency == 0.99
    assert cfg.general.refresh_interval == 0.5
    assert cfg.power.platform_watts == -1.0
    assert len(warnings) == 3


def test_resolution_prefers_explicit_then_env_then_user(tmp_path, monkeypatch):
    user = user_config_path()
    user.parent.mkdir(parents=True)
    user.write_text('[cost]\nrate_per_kwh = 0.20\n')
    assert load_config().cost.rate_per_kwh == 0.20

    env_file = tmp_path / "env.toml"
    env_file.write_text('[cost]\nrate_per_kwh = 0.30\n')
    monkeypatch.setenv("OBSERVATORY_CONFIG", str(env_file))
    assert load_config().cost.rate_per_kwh == 0.30

    explicit = tmp_path / "explicit.toml"
    explicit.write_text('[cost]\nrate_per_kwh = 0.40\n')
    assert load_config(explicit).cost.rate_per_kwh == 0.40


def test_missing_explicit_path_returns_defaults_remembering_path(tmp_path):
    target = tmp_path / "new" / "cfg.toml"
    cfg = load_config(target)
    assert cfg.cost.rate_per_kwh == 0.15
    assert cfg.source_path == target


def test_corrupt_file_falls_back_to_defaults(tmp_path):
    bad = tmp_path / "bad.toml"
    bad.write_text("this is = = not toml")
    cfg = load_config(bad)
    assert cfg.cost.rate_per_kwh == 0.15


def test_resolved_db_path_respects_override(tmp_path):
    cfg = Config()
    cfg.storage.db_path = str(tmp_path / "x.db")
    assert cfg.resolved_db_path() == tmp_path / "x.db"


def test_resolved_db_path_defaults_to_user_dir_for_non_root(monkeypatch, tmp_path):
    monkeypatch.setattr("os.geteuid", lambda: 1000)
    cfg = Config()
    assert cfg.resolved_db_path() == Path(tmp_path / "xdg-data" / "observatory" / "observatory.db")
