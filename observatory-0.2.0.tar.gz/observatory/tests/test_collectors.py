import os
from collections import namedtuple

import pytest

from observatory.collectors.disks import (
    DiskCollector, classify_device, is_real_mount, scan_storage_devices, zfs_pool,
)
from observatory.collectors.docker import (
    DockerCollector, DockerError, cpu_counters, format_ports, health_from_status, memory_usage, network_totals,
)
from observatory.collectors.gpu import GpuCollector, parse_nvidia_smi
from observatory.collectors.network import NetworkCollector, is_virtual_interface
from observatory.collectors.processes import ProcessCollector, is_kernel_thread, kill_process
from observatory.collectors.sensors import classify_chip, cpu_package_temp, normalize
from observatory.collectors.system import SystemCollector, parse_cpu_model
from observatory.models import ProcessInfo, TempReading
from observatory.util.pci import parse_pci_ids

Shw = namedtuple("Shw", "label current high critical")


class TestSystem:
    def test_parse_cpu_model_x86(self):
        text = "processor\t: 0\nvendor_id\t: GenuineIntel\nmodel name\t: Intel(R) Core(TM)  i5-12500\n"
        assert parse_cpu_model(text) == "Intel(R) Core(TM) i5-12500"

    def test_parse_cpu_model_arm(self):
        text = "processor\t: 0\nBogoMIPS\t: 108.00\n\nHardware\t: BCM2835\nModel\t\t: Raspberry Pi 4 Model B Rev 1.4\n"
        assert parse_cpu_model(text) == "Raspberry Pi 4 Model B Rev 1.4"

    def test_live_collection(self):
        sc = SystemCollector()
        cpu = sc.cpu()
        assert 0 <= cpu.percent <= 100 and cpu.cores_logical >= 1
        mem = sc.memory()
        assert mem.total > 0 and 0 <= mem.percent <= 100
        assert sc.swap().total >= 0
        assert sc.load().cores >= 1
        assert sc.uptime() > 0


class TestSensors:
    def test_normalize_filters_and_names(self):
        raw = {
            "coretemp": [Shw("Package id 0", 55.0, 80.0, 100.0), Shw("Core 0", 52.0, 80.0, 100.0)],
            "nvme": [Shw("Composite", 38.9, 81.85, 84.85)],
            "acpitz": [Shw("", 0.0, None, None)],  # invalid → dropped
            "nouveau": [Shw("", 300.0, None, None)],  # glitch → dropped
        }
        readings = normalize(raw)
        names = {r.name for r in readings}
        assert names == {"coretemp:Package id 0", "coretemp:Core 0", "nvme:Composite"}
        nvme = next(r for r in readings if r.chip == "nvme")
        assert nvme.kind == "drive" and nvme.critical == pytest.approx(84.85)

    def test_classify_chip(self):
        assert classify_chip("k10temp") == "cpu"
        assert classify_chip("amdgpu") == "gpu"
        assert classify_chip("drivetemp") == "drive"
        assert classify_chip("nct6798") == "board"
        assert classify_chip("weird") == "other"

    def test_cpu_package_temp_prefers_package(self):
        readings = [TempReading("coretemp", "Core 0", 70, kind="cpu"),
                    TempReading("coretemp", "Package id 0", 65, kind="cpu")]
        assert cpu_package_temp(readings) == 65
        assert cpu_package_temp([]) is None


class TestGpu:
    def test_parse_nvidia_smi(self):
        out = "0, NVIDIA GeForce RTX 3060, 37, 2048, 12288, 61, 75.31, 170.00\n" \
              "1, Tesla P4, [N/A], 100, 7680, 40, [Not Supported], 75.00\n"
        gpus = parse_nvidia_smi(out)
        assert gpus[0].name == "NVIDIA GeForce RTX 3060"
        assert gpus[0].util_percent == 37 and gpus[0].power_w == pytest.approx(75.31)
        assert gpus[0].mem_total == 12288 * 1024 * 1024
        assert gpus[1].util_percent is None and gpus[1].power_w is None

    def test_amd_sysfs(self, tmp_path):
        card = tmp_path / "card0" / "device"
        hwmon = card / "hwmon" / "hwmon3"
        hwmon.mkdir(parents=True)
        (card / "vendor").write_text("0x1002\n")
        (card / "device").write_text("0x73ff\n")
        (card / "gpu_busy_percent").write_text("42\n")
        (card / "mem_info_vram_used").write_text(str(1024**3))
        (card / "mem_info_vram_total").write_text(str(8 * 1024**3))
        (hwmon / "temp1_input").write_text("51000\n")
        (hwmon / "power1_average").write_text("23000000\n")
        (tmp_path / "card0-HDMI-A-1").mkdir()
        collector = GpuCollector(sys_drm=tmp_path)
        collector._nvidia_bin = None
        gpus = collector.collect()
        assert len(gpus) == 1
        g = gpus[0]
        assert g.vendor == "AMD" and g.util_percent == 42 and g.temp_c == 51 and g.power_w == 23

    def test_pci_ids_parsing(self):
        text = "# comment\n10de  NVIDIA Corporation\n\t2504  GA106 [GeForce RTX 3060 Lite Hash Rate]\n" \
               "\t\t1234 5678  subsystem\n1002  Advanced Micro Devices, Inc. [AMD/ATI]\n\t73ff  Navi 23\nC 00  Unclassified\n"
        table = parse_pci_ids(text)
        assert table["10de"][1]["2504"].startswith("GA106")
        assert table["1002"][1]["73ff"] == "Navi 23"


class TestDisks:
    def test_is_real_mount(self):
        assert is_real_mount("/dev/sda1", "/", "ext4")
        assert is_real_mount("tank/data", "/tank/data", "zfs")
        assert not is_real_mount("tmpfs", "/tmp", "tmpfs")
        assert not is_real_mount("/dev/loop3", "/snap/core/1", "squashfs")
        assert not is_real_mount("/dev/sda1", "/var/lib/docker/overlay2/x", "ext4")
        assert zfs_pool("rpool/data/subvol-100-disk-0") == "rpool"

    def test_classify_device(self):
        assert classify_device("nvme0n1", False, False, "") == "nvme"
        assert classify_device("sda", True, False, "") == "hdd"
        assert classify_device("sdb", False, False, "") == "ssd"
        assert classify_device("sdc", True, False, "usb") == "usb"
        assert classify_device("vda", False, False, "") == "virtual"

    def test_scan_storage_devices(self, tmp_path):
        for name, rot, size, model in (("sda", "1", "15628053168", "WDC WD80EFAX"), ("nvme0n1", "0", "976773168", ""),
                                       ("loop0", "0", "100", "")):
            d = tmp_path / name
            (d / "queue").mkdir(parents=True)
            (d / "device").mkdir()
            (d / "queue" / "rotational").write_text(rot)
            (d / "removable").write_text("0")
            (d / "size").write_text(size)
            if model:
                (d / "device" / "model").write_text(model + "   \n")
        devices = {d.name: d for d in scan_storage_devices(tmp_path)}
        assert set(devices) == {"sda", "nvme0n1"}
        assert devices["sda"].kind == "hdd" and devices["sda"].model == "WDC WD80EFAX"
        assert devices["sda"].size_bytes == 15628053168 * 512
        assert devices["nvme0n1"].kind == "nvme"

    def test_live_usage_and_io(self):
        dc = DiskCollector()
        usage = dc.usage()
        assert any(d.mountpoint == "/" for d in usage) or usage == []
        dc.io()
        assert all(d.util_percent >= 0 for d in dc.io())


class TestNetwork:
    def test_virtual_detection_with_sysfs(self, tmp_path):
        (tmp_path / "eth0" / "device").mkdir(parents=True)
        (tmp_path / "br0").mkdir()
        assert not is_virtual_interface("eth0", tmp_path)
        assert is_virtual_interface("br0", tmp_path)
        assert is_virtual_interface("lo", tmp_path)
        assert is_virtual_interface("veth123", tmp_path / "missing")

    def test_live(self):
        nc = NetworkCollector()
        nc.collect()
        ifaces = nc.collect()
        assert any(i.name == "lo" for i in ifaces)


class TestProcesses:
    def test_collect_and_limit(self):
        pc = ProcessCollector()
        procs, total = pc.collect()
        assert total == len(procs) and any(p.pid == os.getpid() for p in procs)
        limited, total2 = pc.collect(limit=4)
        assert len(limited) <= 4 or total2 <= 4

    def test_kernel_thread(self):
        assert is_kernel_thread(ProcessInfo(2, "kthreadd", cmdline="[kthreadd]", rss=0))
        assert not is_kernel_thread(ProcessInfo(9, "bash", cmdline="/bin/bash", rss=1000))

    def test_kill_safety(self):
        assert kill_process(1)[0] is False
        assert kill_process(os.getpid())[0] is False
        ok, msg = kill_process(4_000_000)
        assert not ok and "no longer exists" in msg

    def test_kill_child(self):
        import subprocess
        child = subprocess.Popen(["sleep", "30"])
        ok, msg = kill_process(child.pid)
        assert ok and "SIGTERM" in msg
        assert child.wait(timeout=5) != 0


class TestDockerParsing:
    def test_health_and_ports(self):
        assert health_from_status("Up 3 hours (healthy)") == "healthy"
        assert health_from_status("Up 1 minute (health: starting)") == "starting"
        assert health_from_status("Up 2 days (unhealthy)") == "unhealthy"
        assert health_from_status("Exited (0) 2 days ago") == ""
        ports = [{"PrivatePort": 32400, "PublicPort": 32400, "Type": "tcp"},
                 {"PrivatePort": 32400, "PublicPort": 32400, "Type": "tcp"},
                 {"PrivatePort": 1900, "Type": "udp"}]
        assert format_ports(ports) == "32400->32400/tcp, 1900/udp"

    def test_memory_cpu_network(self):
        stats = {
            "memory_stats": {"usage": 500, "limit": 1000, "stats": {"inactive_file": 100}},
            "cpu_stats": {"cpu_usage": {"total_usage": 2000}, "system_cpu_usage": 10000, "online_cpus": 4},
            "networks": {"eth0": {"rx_bytes": 10, "tx_bytes": 20}, "eth1": {"rx_bytes": 1, "tx_bytes": 2}},
        }
        assert memory_usage(stats) == (400, 1000)
        assert cpu_counters(stats) == (2000, 10000, 4)
        assert network_totals(stats) == (11, 22)
        v1 = {"memory_stats": {"usage": 500, "limit": 0, "stats": {"total_inactive_file": 50}}}
        assert memory_usage(v1) == (450, 0)


class FakeDockerClient:
    def __init__(self):
        self.calls = []
        self.total = 1_000_000
        self.system = 100_000_000
        self.rx = 0

    def containers(self, all_=True):
        return [
            {"Id": "abc", "Names": ["/plex"], "Image": "plex", "State": "running", "Status": "Up 1 hour (healthy)",
             "Labels": {"com.docker.compose.project": "media"}, "Ports": []},
            {"Id": "def", "Names": ["/dead"], "Image": "alpine", "State": "exited", "Status": "Exited (1)",
             "Labels": {}, "Ports": []},
        ]

    def inspect(self, cid):
        return {"RestartCount": 2 if cid == "abc" else 0, "State": {"StartedAt": "2026-09-30T10:00:00Z"}}

    def stats(self, cid):
        self.total += 50_000_000
        self.system += 400_000_000
        self.rx += 1_000_000
        return {"cpu_stats": {"cpu_usage": {"total_usage": self.total}, "system_cpu_usage": self.system,
                              "online_cpus": 4},
                "memory_stats": {"usage": 200 * 1024**2, "limit": 1024**3, "stats": {"inactive_file": 0}},
                "networks": {"eth0": {"rx_bytes": self.rx, "tx_bytes": 0}}}

    def restart(self, cid):
        self.calls.append(("restart", cid))

    def start(self, cid):
        self.calls.append(("start", cid))

    def stop(self, cid):
        raise DockerError("cannot stop")


class TestDockerCollector:
    def test_collect_computes_rates(self):
        client = FakeDockerClient()
        collector = DockerCollector(client)  # type: ignore[arg-type]
        collector.collect()
        containers, available, error = collector.collect()
        assert available and error == ""
        plex = containers[0]
        assert plex.name == "plex" and plex.health == "healthy" and plex.compose_project == "media"
        assert plex.cpu_percent == pytest.approx(50 / 400 * 4 * 100)
        assert plex.mem_usage == 200 * 1024**2 and plex.mem_percent == pytest.approx(19.53, abs=0.01)
        assert plex.restart_count == 2
        assert containers[1].state == "exited" and containers[1].cpu_percent == 0
        collector.close()

    def test_unavailable_daemon(self):
        class Broken:
            def containers(self, all_=True):
                raise DockerError("Docker socket not found at /x")
        collector = DockerCollector(Broken())  # type: ignore[arg-type]
        containers, available, error = collector.collect()
        assert containers == [] and not available and "not found" in error
        collector.close()

    def test_actions(self):
        client = FakeDockerClient()
        collector = DockerCollector(client)  # type: ignore[arg-type]
        assert collector.act("restart", "abc")[0]
        assert client.calls == [("restart", "abc")]
        ok, msg = collector.act("stop", "abc")
        assert not ok and "cannot stop" in msg
        assert not collector.act("explode", "abc")[0]
        collector.close()

    def test_real_client_missing_socket(self, tmp_path):
        from observatory.collectors.docker import DockerClient
        client = DockerClient(str(tmp_path / "nope.sock"))
        with pytest.raises(DockerError, match="not found"):
            client.containers()
